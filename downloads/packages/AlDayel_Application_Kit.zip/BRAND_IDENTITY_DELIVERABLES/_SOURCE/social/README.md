# AlDayel Residential social source

`build_social.py` builds two different post layouts and five carousel pages. `property_content.json` is the default, explicitly blank content source. `social_manifest.json` lists live text fields, embedded image slots, and exact original logo source hashes.

Run from the delivery root with the original licensed Arabic font directory:

```bash
export ALDAYEL_FONT_DIR=/path/to/licensed-fonts
python _SOURCE/social/build_social.py
python _SOURCE/social/validate_social.py
```

Install the Python packages in `requirements-social.txt` and Inkscape/Fontconfig. The builder creates a temporary isolated Fontconfig file outside the delivery to use the licensed Arabic fonts and supplied PT Sans. It rejects fallback font resolution. No commercial raw font is embedded in the SVG or copied into this source folder.

Direct SVG editing is also supported; install the original fonts first. The full carousel source is `07_INSTAGRAM_CAROUSEL/Editable/AlDayel_Carousel_System.svg`, with five editable Inkscape pages.

The validator checks actual delivered SVG structure, live text fields, logo path identity, embedded image readability, native PNG dimensions, and Inkscape text bounds. Visual review must still be repeated after editing. `social_editability_qa.json` documents the completed replacement and QR tests; synthetic test fixtures were kept outside the deliverable.
