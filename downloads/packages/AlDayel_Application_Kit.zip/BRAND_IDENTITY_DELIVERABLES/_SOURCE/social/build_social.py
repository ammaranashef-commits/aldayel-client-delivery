#!/usr/bin/env python3
"""AlDayel Residential social application system.
All original logo paths remain unchanged. Text is live logical Arabic in SVG.
Replace content in property_content.json; real photographs are embedded without
stretching, using crop-to-frame. No property photograph or company fact is invented.
"""
from pathlib import Path
from xml.sax.saxutils import escape
from lxml import etree as ET
from PIL import Image, ImageDraw, ImageFont
from urllib.parse import urlsplit
import argparse, base64, copy, hashlib, io, json, mimetypes, os, re, subprocess, tempfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
BRAND=HERE.parent/'brand'
NS='http://www.w3.org/2000/svg'
INKSCAPE='http://www.inkscape.org/namespaces/inkscape'
SODIPODI='http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd'
XLINK='http://www.w3.org/1999/xlink'
INK='#1C3549'; PEARL='#F4F3EF'; MIST='#CCDDE4'; COPPER='#A96B53'
AR='Helvetica Neue LT Arabic'; EN='PT Sans'
W=1080; H=1350
# A transparent pixel is an editable image object, not a property photograph.
EMPTY_PNG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGNgYGBgAAAABQABpfZFQAAAAABJRU5ErkJggg=='

def esc(x):return escape(str(x),{'"':'&quot;'})

def font_file(bold=False):
    directory=os.environ.get('ALDAYEL_FONT_DIR')
    names=['HelveticaNeueLTArabic-Bold.otf' if bold else 'HelveticaNeueLTArabic-Roman.otf']
    if directory:
        for n in names:
            p=Path(directory)/n
            if p.is_file():return p
    family=f'{AR}:weight={"bold" if bold else "regular"}'
    p=Path(subprocess.check_output(['fc-match','-f','%{file}',family],text=True).strip())
    if p.is_file() and 'Helvetica' in p.name:return p
    raise FileNotFoundError('Install the licensed Helvetica Neue LT Arabic Roman/Bold fonts and set ALDAYEL_FONT_DIR.')

FONT_FILES={}
RENDER_ENV=None
FONT_TEMP=None

def configure_font_environment():
    """Use only the supplied official families for deterministic SVG rendering."""
    global RENDER_ENV,FONT_TEMP
    ar_files={False:font_file(False),True:font_file(True)}
    latin=ROOT/'03_FONTS/PT_Sans'
    if not (latin/'PTSans-Regular.ttf').is_file():raise FileNotFoundError('Keep the supplied 03_FONTS/PT_Sans folder in the delivery root.')
    FONT_TEMP=tempfile.TemporaryDirectory(prefix='aldayel-social-fonts-')
    tmp=Path(FONT_TEMP.name);(tmp/'cache').mkdir()
    dirs=sorted({str(p.parent.resolve()) for p in ar_files.values()}|{str(latin.resolve())})
    fc=tmp/'fonts.conf'
    fc.write_text('<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig>'+''.join('<dir>'+esc(p)+'</dir>' for p in dirs)+'<cachedir>'+esc(str(tmp/'cache'))+'</cachedir></fontconfig>')
    env=os.environ.copy();env['FONTCONFIG_FILE']=str(fc);env['FONTCONFIG_PATH']=str(tmp)
    for bold,path in ar_files.items():
        family=f'{AR}:weight={"bold" if bold else "regular"}'
        match=Path(subprocess.check_output(['fc-match','-f','%{file}',family],env=env,text=True).strip())
        if not match.is_file() or hashlib.sha256(match.read_bytes()).digest()!=hashlib.sha256(path.read_bytes()).digest():
            raise RuntimeError('Fontconfig did not resolve the exact licensed Arabic font.')
        FONT_FILES[bold]=path
    RENDER_ENV=env
    return env

def measure(value,size,bold=False):
    if bold not in FONT_FILES:FONT_FILES[bold]=font_file(bold)
    f=ImageFont.truetype(str(FONT_FILES[bold]),round(size))
    return f.getlength(str(value),direction='rtl')

def wrap(value,width,size,bold=False,max_lines=2):
    words=str(value).split();lines=[];line=''
    for word in words:
        cand=(line+' '+word).strip()
        if measure(cand,size,bold)<=width:line=cand
        else:
            if not line:raise ValueError(f'Unbreakable text exceeds its frame: {value}')
            lines.append(line);line=word
    if line:lines.append(line)
    if len(lines)>max_lines:raise ValueError(f'Text exceeds {max_lines} lines; shorten this field: {value}')
    return lines or ['']

def image_uri(path,config_dir):
    p=Path(path).expanduser()
    if not p.is_absolute():p=config_dir/p
    p=p.resolve()
    with Image.open(p) as im:
        im.verify()
    mime=mimetypes.guess_type(str(p))[0]
    if mime not in ('image/jpeg','image/png','image/webp'):raise ValueError('Use JPEG, PNG or WebP property photographs.')
    return 'data:'+mime+';base64,'+base64.b64encode(p.read_bytes()).decode()

class Canvas:
    def __init__(self,name,title,bg=PEARL):
        self.name=name;self.title=title;self.items=[];self.count=0;self.fields=[];self.images=[];self.logos=[]
        self.rect(0,0,W,H,bg,element_id='page-background')
    def uid(self,n):return f'{self.name}-{n}'
    def rect(self,x,y,w,h,fill,stroke=None,sw=1,element_id=None):
        st=f' stroke="{stroke}" stroke-width="{sw}"' if stroke else ''
        ident=f' id="{self.uid(element_id)}"' if element_id else ''
        self.items.append(f'<rect{ident} x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}"{st}/>')
    def line(self,x1,y1,x2,y2,color=MIST,sw=1):
        self.items.append(f'<path d="M{x1},{y1} L{x2},{y2}" fill="none" stroke="{color}" stroke-width="{sw}"/>')
    def text(self,value,x,y,size=32,color=INK,bold=False,rtl=True,anchor='start',field=None):
        if field and re.match(r'^(contact|price|area)(-|$)',field) and not re.search(r'[\u0600-\u06ff]',str(value)) and re.search(r'\d',str(value)):
            rtl=False;anchor='end'
        ident=f' id="{self.uid(field)}" data-field="{esc(field)}"' if field else ''
        self.items.append(f'<text{ident} x="{x}" y="{y}" font-family="{AR if rtl else EN}" font-size="{size}" font-weight="{700 if bold else 400}" fill="{color}" direction="{"rtl" if rtl else "ltr"}" unicode-bidi="embed" text-anchor="{anchor}" xml:lang="{"ar" if rtl else "en"}">{esc(value)}</text>')
        if field:self.fields.append({'id':self.uid(field),'field':field,'value':str(value),'size_px':size})
    def block(self,value,x,y,width,size=40,color=INK,bold=False,max_lines=2,leading=1.42,field=None):
        lines=wrap(value,width,size,bold,max_lines)
        for i,t in enumerate(lines):self.text(t,x,y+i*size*leading,size,color,bold,field=f'{field}-{i+1}' if field else None)
        return y+(len(lines)-1)*size*leading
    def logo(self,x,y,w=260,color='ink'):
        p=BRAND/f'logos/residential/aldayel-primary-ar-{color}.svg'
        root=ET.fromstring(p.read_bytes());vb=list(map(float,root.get('viewBox').split()));h=w*vb[3]/vb[2]
        self.count+=1;prefix=self.uid(f'logo-{self.count}-')
        paths_before=[(e.get('d'),e.get('transform')) for e in root.iter() if ET.QName(e).localname=='path']
        for el in root.iter():
            if el.get('id'):el.set('id',prefix+el.get('id'))
            for key,val in list(el.attrib.items()):
                if 'url(#' in val:el.set(key,val.replace('url(#','url(#'+prefix))
        paths_after=[(e.get('d'),e.get('transform')) for e in root.iter() if ET.QName(e).localname=='path']
        assert paths_before==paths_after and w>=240
        inner=''.join(ET.tostring(c,encoding='unicode') for c in root)
        self.items.append(f'<g id="{prefix}original" data-original-variant="primary-ar" transform="translate({x},{y}) scale({w/vb[2]}) translate({-vb[0]},{-vb[1]})">{inner}</g>')
        label_size=27;gap=h*.38
        self.text('السكني',x+w/2,y+h+gap+label_size*.82,label_size,PEARL if color=='pearl' else INK,anchor='middle',field='residential-descriptor')
        self.logos.append({'source':str(p.relative_to(ROOT)),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'width_px':w,'height_px':h,'clear_space_px':h/4,'descriptor_top_gap_px':gap,'geometry_unchanged':True,'uniform_scale':w/vb[2]})
        return h
    def photo(self,key,x,y,w,h,data,config_dir,label='صورة العقار'):
        self.count+=1;clip=self.uid(f'photo-clip-{self.count}');iid=self.uid('image-'+key)
        self.items.append(f'<g id="{self.uid("photo-frame-"+key)}" data-photo-slot="{key}">')
        self.rect(x,y,w,h,MIST)
        # Quiet placeholder labels are covered by a replacement photograph.
        self.line(x+24,y+24,x+75,y+24,INK,1.4);self.line(x+24,y+24,x+24,y+75,INK,1.4)
        self.line(x+w-24,y+h-24,x+w-75,y+h-24,INK,1.4);self.line(x+w-24,y+h-24,x+w-24,y+h-75,INK,1.4)
        size=34 if w>400 else 27
        self.text(label,x+w/2,y+h/2-8,size,INK,anchor='middle')
        self.text('أضف الصورة الأصلية',x+w/2,y+h/2+38,24,INK,anchor='middle')
        self.items.append(f'<defs><clipPath id="{clip}"><rect x="{x}" y="{y}" width="{w}" height="{h}"/></clipPath></defs>')
        path=data.get('images',{}).get(key,'')
        uri=image_uri(path,config_dir) if path else EMPTY_PNG
        self.items.append(f'<image id="{iid}" x="{x}" y="{y}" width="{w}" height="{h}" href="{uri}" xlink:href="{uri}" preserveAspectRatio="xMidYMid slice" clip-path="url(#{clip})"/>')
        self.items.append('</g>')
        self.images.append({'field':key,'id':iid,'frame':[x,y,w,h],'has_real_image':bool(path),'crop':'xMidYMid slice','editable_image_element':True})
    def qr(self,x,y,size,url):
        if url:
            u=urlsplit(url)
            if u.scheme not in ('https','http') or not u.netloc:raise ValueError('map_url must be a real HTTP(S) geographic URL, or empty.')
            import qrcode
            q=qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M,box_size=1,border=4);q.add_data(url);q.make(fit=True)
            m=q.get_matrix();s=size/len(m);commands=[]
            self.rect(x,y,size,size,PEARL)
            for yy,row in enumerate(m):
                for xx,on in enumerate(row):
                    if on:commands.append(f'M{x+xx*s:.4f},{y+yy*s:.4f}h{s:.4f}v{s:.4f}h{-s:.4f}z')
            self.items.append(f'<g id="{self.uid("map-qr")}" data-qr-payload="{esc(url)}"><path d="{"".join(commands)}" fill="{INK}"/></g>')
        else:
            self.rect(x,y,size,size,PEARL,INK,1.4,element_id='optional-qr-frame')
            self.text('QR',x+size/2,y+size*.49,38,INK,rtl=False,anchor='middle')
            self.text('اختياري',x+size/2,y+size*.72,23,INK,anchor='middle')
    def footer(self,n=None,dark=False,label='الدايل السكني'):
        color=PEARL if dark else INK
        self.line(64,1246,1016,1246,MIST,1)
        self.text(label,1016,1292,23,color)
        if n:self.text(f'{n:02d} / 05',64,1291,23,color,rtl=False)
        else:self.text('ALDAYEL / RESIDENTIAL',64,1291,20,color,rtl=False)
    def svg(self):
        return f'''<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="{NS}" xmlns:xlink="{XLINK}" xmlns:inkscape="{INKSCAPE}" width="1080px" height="1350px" viewBox="0 0 1080 1350"><title>{esc(self.title)}</title><desc>AlDayel Residential reusable social template. Original logo geometry preserved. All unprovided property and contact data are explicit editable placeholders; no fictional property image is used. Arabic font: Helvetica Neue LT Arabic Roman/Bold; Latin: PT Sans.</desc>{''.join(self.items)}</svg>'''


def post_sale(d,cd):
    c=Canvas('instagram-for-sale','الدايل السكني قالب منشور للبيع')
    c.logo(736,64,280)
    c.text('للبيع',350,145,68,bold=True,field='offer')
    c.text('عرض عقاري',350,200,28)
    c.photo('main',64,298,952,538,d,cd)
    c.block(d['title'],1016,931,952,53,bold=True,max_lines=1,field='title')
    c.block(d['location'],1016,993,952,33,max_lines=1,field='location')
    c.line(64,1032,1016,1032,INK,1)
    c.text('السعر',1016,1086,26)
    c.block(d['price'],1016,1150,440,48,bold=True,max_lines=1,field='price')
    c.text(d['currency'],1016,1193,27,field='currency')
    c.text('المساحة',485,1086,26)
    c.block(d['area']+' '+d['area_unit'],485,1150,420,40,bold=True,max_lines=1,field='area')
    c.text('للاستفسار',485,1202,28)
    c.text(d['contact'],340,1202,28,field='contact')
    c.footer();return c


def post_rent(d,cd):
    c=Canvas('instagram-for-rent','الدايل السكني قالب منشور للإيجار',INK)
    c.logo(756,64,260,'pearl')
    c.text('ALDAYEL',64,102,24,PEARL,rtl=False)
    c.text('RESIDENTIAL',64,137,24,PEARL,rtl=False)
    c.photo('main',64,282,540,776,d,cd)
    c.text('للإيجار',1016,375,70,PEARL,True,field='offer')
    c.block(d['title'],1016,471,350,40,PEARL,True,max_lines=2,field='title')
    c.text('الموقع',1016,629,26,MIST)
    c.block(d['location'],1016,679,350,32,PEARL,max_lines=2,field='location')
    c.line(665,775,1016,775,MIST,1)
    c.text('المساحة',1016,829,26,MIST)
    c.block(d['area'],1016,889,350,42,PEARL,True,max_lines=1,field='area')
    c.text(d['area_unit'],1016,932,28,MIST,field='area-unit')
    c.rect(64,1088,952,136,PEARL)
    c.text('السعر',990,1132,25)
    c.block(d['price']+' '+d['currency'],990,1188,465,39,INK,True,max_lines=1,field='price-currency')
    c.text('تواصل معنا',487,1132,25)
    c.block(d['contact'],487,1188,390,35,INK,True,max_lines=1,field='contact')
    c.footer(dark=True);return c


def carousel_cover(d,cd):
    c=Canvas('carousel-01-cover','الدايل السكني كاروسيل الغلاف')
    c.logo(756,64,260)
    c.text('عرض عقاري',64,102,27,rtl=True,anchor='end')
    c.text(d['offer'],1016,329,68,bold=True,field='offer')
    c.block(d['title'],1016,408,952,48,bold=True,max_lines=1,field='title')
    c.photo('main',64,464,952,646,d,cd)
    c.block(d['location'],1016,1194,952,36,max_lines=1,field='location')
    c.footer(1);return c


def carousel_information(d,cd):
    c=Canvas('carousel-02-information','الدايل السكني كاروسيل المعلومات الأساسية',INK)
    c.logo(756,64,260,'pearl')
    c.text('PROPERTY BRIEF',64,101,22,PEARL,rtl=False)
    c.text('تفاصيل العقار',1016,344,62,PEARL,True)
    cells=[('نوع العقار',d['property_type'],1016,474,420,'property-type'),('التصنيف',d['classification'],485,474,420,'classification'),('النشاط',d['activity'],1016,695,420,'activity'),('المساحة',d['area']+' '+d['area_unit'],485,695,420,'area')]
    for label,value,x,y,width,field in cells:
        c.text(label,x,y,29,MIST)
        c.block(value,x,y+72,width,42,PEARL,True,max_lines=2,field=field)
    c.line(64,620,1016,620,MIST,1)
    c.line(64,855,1016,855,MIST,1)
    c.text('السعر',1016,938,30,MIST)
    c.block(d['price'],1016,1054,952,76,PEARL,True,max_lines=1,field='price')
    c.text(d['currency'],1016,1125,35,PEARL,field='currency')
    c.footer(2,dark=True);return c


def carousel_features(d,cd):
    c=Canvas('carousel-03-features','الدايل السكني كاروسيل المواصفات')
    c.logo(756,64,260)
    c.text('PROPERTY FEATURES',64,101,22,rtl=False)
    c.text('مواصفات العقار',1016,344,62,bold=True)
    features=d.get('features',[])
    if len(features)>4:raise ValueError('The feature slide supports four concise features. Use extra slides for more.')
    for i,f in enumerate(features):
        y=483+i*180
        c.text(f'{i+1:02d}',64,y,38,rtl=False)
        c.block(f['title'],1016,y,815,43,bold=True,max_lines=1,field=f'feature-{i+1}-title')
        c.block(f['detail'],1016,y+65,815,31,max_lines=2,leading=1.4,field=f'feature-{i+1}-detail')
        if i<3:c.line(64,y+132,1016,y+132,MIST,1)
    c.footer(3);return c


def carousel_location(d,cd):
    c=Canvas('carousel-04-location','الدايل السكني كاروسيل الصور والموقع')
    c.logo(756,64,260)
    c.text('IMAGES / LOCATION',64,101,22,rtl=False)
    c.text('صور وموقع',1016,344,62,bold=True)
    c.photo('detail_1',64,411,566,373,d,cd,'صورة إضافية')
    c.photo('detail_2',660,411,356,373,d,cd,'صورة إضافية')
    c.text('العنوان',1016,882,30,bold=True)
    c.block(d['address'],1016,944,680,36,max_lines=2,field='address')
    c.qr(64,870,180,d.get('map_url',''))
    c.text('الموقع الجغرافي',1016,1106,29,bold=True)
    if d.get('map_url'):
        c.items.append(f'<a id="{c.uid("map-link")}" xlink:href="{esc(d["map_url"])}" target="_blank">')
        c.text('افتح الموقع أو امسح الرمز',1016,1163,31,field='map-link-label');c.items.append('</a>')
    else:c.text('[أضف رابط الموقع]',1016,1163,31,field='map-link-placeholder')
    c.footer(4);return c


def carousel_contact(d,cd):
    c=Canvas('carousel-05-contact','الدايل السكني كاروسيل التواصل',INK)
    c.logo(756,64,260,'pearl')
    c.text('LET’S TALK',64,101,22,PEARL,rtl=False)
    c.text('للاستفسار عن العقار',1016,344,60,PEARL,True)
    c.photo('main',64,446,412,622,d,cd)
    c.text('تواصل معنا',1016,591,49,PEARL,True)
    c.block(d['contact'],1016,700,460,43,PEARL,True,max_lines=2,field='contact')
    c.line(540,807,1016,807,MIST,1)
    c.text('الدايل السكني',1016,886,35,PEARL)
    c.block(d['location'],1016,960,460,30,MIST,max_lines=2,field='location')
    c.footer(5,dark=True);return c


def save_svg(c,path):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(c.svg(),encoding='utf-8')
def render(svg,png,scale=1):
    result=subprocess.run(['inkscape',str(svg),'--export-area-page',f'--export-filename={png}',f'--export-width={1080*scale}',f'--export-height={1350*scale}'],capture_output=True,text=True,env=RENDER_ENV)
    if result.returncode:raise RuntimeError(result.stderr)
    with Image.open(png) as im:assert im.size==(1080*scale,1350*scale)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--config',default=str(HERE/'property_content.json'));ap.add_argument('--output-root',default=str(ROOT));ap.add_argument('--skip-render',action='store_true');args=ap.parse_args()
    config=Path(args.config).resolve();d=json.loads(config.read_text());out=Path(args.output_root).resolve()
    # Resolve the commercial original, never silently substitute another Arabic font.
    configure_font_environment()
    slides=[carousel_cover(d,config.parent),carousel_information(d,config.parent),carousel_features(d,config.parent),carousel_location(d,config.parent),carousel_contact(d,config.parent)]
    sale=post_sale(d,config.parent);rent=post_rent(d,config.parent)
    entries=[(sale,out/'06_INSTAGRAM_POSTS/For_Sale/AlDayel_Instagram_For_Sale.svg'),(rent,out/'06_INSTAGRAM_POSTS/For_Rent/AlDayel_Instagram_For_Rent.svg')]
    for i,c in enumerate(slides,1):entries.append((c,out/f'07_INSTAGRAM_CAROUSEL/Editable/AlDayel_Carousel_{i:02d}.svg'))
    manifest=[]
    for c,path in entries:
        save_svg(c,path)
        if c in slides:png=out/f'07_INSTAGRAM_CAROUSEL/Exported_PNG/AlDayel_Carousel_{slides.index(c)+1:02d}.png'
        else:png=path.with_suffix('.png')
        png.parent.mkdir(parents=True,exist_ok=True)
        if not args.skip_render:render(path,png)
        manifest.append({'name':c.name,'svg':str(path.relative_to(out)),'png':str(png.relative_to(out)),'pixels':[W,H],'editable_text_fields':c.fields,'image_slots':c.images,'logos':c.logos})
    # A single native multi-page Inkscape source, with all text and image objects editable.
    groups=[];pages=[]
    for i,c in enumerate(slides):
        el=ET.fromstring(c.svg().encode());body=''.join(ET.tostring(x,encoding='unicode') for x in el if ET.QName(x).localname not in ('title','desc'))
        groups.append(f'<g id="{c.name}-artboard" transform="translate({i*W},0)">{body}</g>')
        pages.append(f'<inkscape:page x="{i*W}" y="0" width="1080" height="1350" inkscape:label="{i+1:02d}"/>')
    master=f'''<?xml version="1.0" encoding="UTF-8"?><svg xmlns="{NS}" xmlns:xlink="{XLINK}" xmlns:inkscape="{INKSCAPE}" xmlns:sodipodi="{SODIPODI}" width="5400px" height="1350px" viewBox="0 0 5400 1350"><title>AlDayel Residential five-page editable carousel system</title><sodipodi:namedview id="namedview">{''.join(pages)}</sodipodi:namedview>{''.join(groups)}</svg>'''
    (out/'07_INSTAGRAM_CAROUSEL/Editable/AlDayel_Carousel_System.svg').write_text(master)
    (out/'07_INSTAGRAM_CAROUSEL/Editable/property_content.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
    if not args.skip_render:
        gap=26;thumbw=324;thumbh=405
        sheet=Image.new('RGB',(5*thumbw+6*gap,thumbh+2*gap),PEARL)
        for i in range(5):
            im=Image.open(out/f'07_INSTAGRAM_CAROUSEL/Exported_PNG/AlDayel_Carousel_{i+1:02d}.png').convert('RGB');im.thumbnail((thumbw,thumbh),Image.Resampling.LANCZOS)
            # Right-to-left reading: first slide at the right.
            sheet.paste(im,(gap+(4-i)*(thumbw+gap),gap))
        sheet.save(out/'07_INSTAGRAM_CAROUSEL/AlDayel_Carousel_Overview.png')
    (out/'_SOURCE/social').mkdir(parents=True,exist_ok=True)
    (out/'_SOURCE/social/social_manifest.json').write_text(json.dumps({'brand':'AlDayel Residential','native_canvas':[1080,1350],'property_content_status':'explicit placeholders unless supplied via config','templates':manifest,'combined_master':'07_INSTAGRAM_CAROUSEL/Editable/AlDayel_Carousel_System.svg','qr_present':bool(d.get('map_url'))},ensure_ascii=False,indent=2))
    print(json.dumps({'templates':len(entries),'slides':len(slides),'output_root':str(out),'rendered':not args.skip_render}))

if __name__=='__main__':main()
