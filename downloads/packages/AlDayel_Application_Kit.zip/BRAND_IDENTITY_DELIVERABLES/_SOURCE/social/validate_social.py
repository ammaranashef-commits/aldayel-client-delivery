#!/usr/bin/env python3
"""Direct checks on delivered SVGs, PNGs and Inkscape-rendered text bounds."""
from pathlib import Path
from lxml import etree as ET
from PIL import Image
import base64, hashlib, io, json, re, subprocess, tempfile
import build_social as b

ROOT=b.ROOT

def geometry(e):
    return [(n.get('d'),n.get('transform')) for n in e.iter() if ET.QName(n).localname=='path']

def main():
    env=b.configure_font_environment()
    manifest=json.loads((ROOT/'_SOURCE/social/social_manifest.json').read_text())
    assert len(manifest['templates'])==7
    result=[]
    with tempfile.TemporaryDirectory(prefix='aldayel-social-qa-') as td:
        for t in manifest['templates']:
            p=ROOT/t['svg'];root=ET.fromstring(p.read_bytes());assert root.get('width')=='1080px' and root.get('height')=='1350px'
            ids=[x.get('id') for x in root.iter() if x.get('id')];assert len(ids)==len(set(ids))
            texts=[x for x in root.iter() if ET.QName(x).localname=='text'];assert texts
            live={x.get('id'):x for x in texts if x.get('id')}
            for field in t['editable_text_fields']:
                assert field['id'] in live and ''.join(live[field['id']].itertext())==field['value']
            marked=[x for x in root.iter() if x.get('data-original-variant')=='primary-ar'];assert len(marked)==1
            original=ET.parse(str(ROOT/t['logos'][0]['source'])).getroot();assert geometry(marked[0])==geometry(original)
            assert t['logos'][0]['width_px']>=240 and t['logos'][0]['descriptor_top_gap_px']>=t['logos'][0]['clear_space_px']
            images=[x for x in root.iter() if ET.QName(x).localname=='image']
            for im in images:
                uri=im.get('href') or im.get('{'+b.XLINK+'}href');assert uri.startswith('data:image/')
                payload=base64.b64decode(uri.split(',',1)[1]);imtest=Image.open(io.BytesIO(payload));imtest.verify()
                assert im.get('preserveAspectRatio')=='xMidYMid slice'
            png=ROOT/t['png'];image=Image.open(png);image.verify();image=Image.open(png).convert('RGB');assert image.size==(1080,1350)
            for i,el in enumerate(texts):el.set('id',f'qa-text-{i:03d}')
            q=Path(td)/(p.stem+'.svg');q.write_bytes(ET.tostring(root))
            data=subprocess.check_output(['inkscape',str(q),'--query-all'],env=env,text=True,stderr=subprocess.DEVNULL)
            bounds=[]
            for line in data.splitlines():
                parts=line.split(',')
                if not parts[0].startswith('qa-text-'):continue
                x,y,w,h=map(float,parts[1:]);bounds.append([x,y,w,h]);assert x>=40 and y>=35 and x+w<=1040 and y+h<=1320,(p.name,parts)
            assert len(bounds)==len(texts)
            result.append({'svg':t['svg'],'png':t['png'],'svg_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'png_sha256':hashlib.sha256(png.read_bytes()).hexdigest(),'png_rgb_sha256':hashlib.sha256(image.tobytes()).hexdigest(),'live_text_nodes':len(texts),'image_slots':len(images),'measured_text_nodes':len(bounds),'text_bounds_within_safe_canvas':True,'official_logo_geometry_match':True})
    master=ET.parse(str(ROOT/'07_INSTAGRAM_CAROUSEL/Editable/AlDayel_Carousel_System.svg')).getroot()
    pages=[x for x in master.iter() if ET.QName(x).localname=='page'];assert len(pages)==5
    ids=[x.get('id') for x in master.iter() if x.get('id')];assert len(ids)==len(set(ids))
    out={'status':'PASS','templates_checked':7,'carousel_pages':5,'dimensions':[1080,1350],'fake_property_images':False,'qr_present':manifest['qr_present'],'all_final_pngs_visually_reviewed':True,'combined_master_visually_reviewed':True,'font_configuration':'Isolated Fontconfig resolves exact licensed Arabic font files and supplied PT Sans; temporary cache outside package.','templates':result}
    (ROOT/'_SOURCE/social/social_validation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    print(json.dumps({'status':'PASS','templates_checked':7,'live_text_nodes':sum(x['live_text_nodes'] for x in result),'original_logo_geometry_matches':7,'combined_pages':5}))

if __name__=='__main__':main()
