"""Build native, editable RTL Word stationery for AlDayel Residential.
No raw commercial font is embedded or redistributed. Install the licensed
Helvetica Neue LT Arabic Roman/Bold and supplied PT Sans before rebuilding.
"""
from pathlib import Path
import argparse, json, subprocess, hashlib, re, copy, io
from urllib.parse import urlparse
from PIL import Image
from lxml import etree
from docx import Document
from docx.shared import Mm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
ASSETS=HERE/'assets'
BRAND=ROOT/'_SOURCE/brand'
LOGO=BRAND/'logos/residential/aldayel-primary-ar-ink.svg'
INK='1C3549'; PEARL='F4F3EF'; MIST='CCDDE4'; COPPER='A96B53'
AR='Helvetica Neue LT Arabic'; EN='PT Sans'
W=178
COUNTER=100
PARA_MAX_SIZES={}


def attr(node,name,value):node.set(qn(name),str(value));return node

def elm(name, **attrs):
    e=OxmlElement(name)
    for k,v in attrs.items():e.set(qn(k) if ":" in k else k,str(v))
    return e

def font(run,size=11,bold=False,color=INK,rtl=True,latin=False):
    run.font.name=EN if latin else AR;run.font.size=Pt(size);run.bold=bold;run.font.color.rgb=RGBColor.from_string(color)
    paragraph=run._parent
    if hasattr(paragraph,'_p'):
        maximum=max(PARA_MAX_SIZES.get(paragraph._p,0),size);PARA_MAX_SIZES[paragraph._p]=maximum
        paragraph.paragraph_format.line_spacing=Pt(maximum*1.5+1)
    rp=run._element.get_or_add_rPr();rf=rp.get_or_add_rFonts()
    for k in ['ascii','hAnsi','eastAsia','cs']:rf.set(qn('w:'+k),EN if latin else AR)
    for tag,val in [('w:szCs',str(int(size*2))),('w:bCs','1' if bold else '0'),('w:rtl','1' if rtl else '0')]:
        old=rp.find(qn(tag))
        if old is not None:rp.remove(old)
        rp.append(elm(tag,**{'w:val':val}))
    lang=rp.find(qn('w:lang'))
    if lang is None:lang=elm('w:lang');rp.append(lang)
    lang.set(qn('w:val'),'en-US' if latin else 'ar-KW');lang.set(qn('w:bidi'),'ar-KW')
    return run

def pformat(p,before=0,after=0,line=1.15,rtl=True,align=None,keep=False):
    PARA_MAX_SIZES[p._p]=0
    pf=p.paragraph_format;pf.space_before=Pt(before);pf.space_after=Pt(after);pf.line_spacing=line;pf.keep_together=True;pf.keep_with_next=keep
    p.alignment=align if align is not None else (WD_ALIGN_PARAGRAPH.RIGHT if rtl else WD_ALIGN_PARAGRAPH.LEFT)
    pp=p._p.get_or_add_pPr();old=pp.find(qn('w:bidi'))
    if old is not None:pp.remove(old)
    bidi=elm('w:bidi',**{'w:val':'1' if rtl else '0'});sp=pp.find(qn('w:spacing'));pp.insert(list(pp).index(sp) if sp is not None else 0,bidi)
    jc=pp.find(qn('w:jc'))
    if jc is not None and (align is None or (rtl and align==WD_ALIGN_PARAGRAPH.RIGHT) or (not rtl and align==WD_ALIGN_PARAGRAPH.LEFT)):jc.set(qn('w:val'),'start')
    return p

def text(p,s,size=11,bold=False,color=INK,rtl=True,latin=False):return font(p.add_run(s),size,bold,color,rtl,latin)

def control(p,key,value,size=11,bold=False,color=INK,rtl=True,latin=False):
    global COUNTER
    if not re.search(r'[\u0600-\u06ff]',value) and any(ch.isalnum() for ch in value):
        rtl=False;latin=True
        if not p.text.strip():pformat(p,rtl=False,align=WD_ALIGN_PARAGRAPH.RIGHT)
    run=text(p,value,size,bold,color,rtl,latin)
    p._p.remove(run._r);sdt=elm('w:sdt');pr=elm('w:sdtPr');pr.append(elm('w:alias',**{'w:val':key}));pr.append(elm('w:tag',**{'w:val':key}));COUNTER+=1;pr.append(elm('w:id',**{'w:val':COUNTER}));pr.append(elm('w:text'));sdt.append(pr);cont=elm('w:sdtContent');cont.append(run._r);sdt.append(cont);p._p.append(sdt);return sdt

def set_cell(cell,fill=None,pad=0,bottom_border=False):
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
    pr=cell._tc.get_or_add_tcPr();m=pr.find(qn('w:tcMar'))
    if m is None:m=elm('w:tcMar');pr.append(m)
    for side in ['top','left','bottom','right']:
        e=elm('w:'+side,**{'w:w':str(round(pad/25.4*1440)),'w:type':'dxa'});m.append(e)
    if fill:pr.append(elm('w:shd',**{'w:fill':fill,'w:val':'clear'}))
    bs=elm('w:tcBorders')
    for side in ['top','left','bottom','right']:
        bs.append(elm('w:'+side,**{'w:val':'single' if bottom_border and side=='bottom' else 'nil','w:sz':'4','w:color':MIST}))
    pr.append(bs)
    for p in cell.paragraphs:pformat(p)

def table(container,widths,rtl=True):
    t=container.add_table(rows=1,cols=len(widths)) if hasattr(container,'sections') or hasattr(container,'_tc') else container.add_table(rows=1,cols=len(widths),width=Mm(sum(widths)))
    t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    pr=t._tbl.tblPr;pr.append(elm('w:tblLayout',**{'w:type':'fixed'}));pr.append(elm('w:tblInd',**{'w:w':'0','w:type':'dxa'}))
    if rtl:pr.append(elm('w:bidiVisual',**{'w:val':'1'}))
    bs=elm('w:tblBorders')
    for side in ['top','left','bottom','right','insideH','insideV']:bs.append(elm('w:'+side,**{'w:val':'nil'}))
    pr.append(bs)
    for i,w in enumerate(widths):t.columns[i].width=Mm(w);t.rows[0].cells[i].width=Mm(w);set_cell(t.rows[0].cells[i])
    trp=t.rows[0]._tr.get_or_add_trPr();trp.append(elm('w:cantSplit'))
    return t

def spacer(doc,pt=3):
    p=doc.add_paragraph();pformat(p,line=1);p.paragraph_format.space_after=Pt(0);p.paragraph_format.space_before=Pt(0);text(p,'',pt);p.paragraph_format.line_spacing=Pt(pt);return p

def export_svg(svg,png,width):
    subprocess.run(['inkscape',str(svg),'--export-type=png','--export-filename='+str(png),'--export-width='+str(width)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)

def asset_setup():
    ASSETS.mkdir(exist_ok=True,parents=True)
    logo_png=ASSETS/'AlDayel_Primary_Ink_2400.png'
    if not logo_png.exists():export_svg(LOGO,logo_png,2400)
    for name,w,h in [('main',178,62),('detail',87,32)]:
        svg=ASSETS/f'Photo_Placeholder_{name}.svg';png=svg.with_suffix('.png')
        # Neutral artwork is deliberately not an invented property photograph.
        svg.write_text(f'''<svg xmlns="http://www.w3.org/2000/svg" width="{w}mm" height="{h}mm" viewBox="0 0 {w} {h}"><rect width="{w}" height="{h}" fill="#{MIST}"/><rect x="0.25" y="0.25" width="{w-.5}" height="{h-.5}" fill="none" stroke="#{INK}" stroke-opacity=".16" stroke-width=".25"/><path d="M{w/2-3},{h/2}h6M{w/2},{h/2-3}v6" stroke="#{INK}" stroke-width=".45"/><path d="M5,10V5H10M{w-10},5h5v5M5,{h-10}v5h5M{w-10},{h-5}h5v-5" stroke="#{INK}" stroke-width=".3" fill="none"/></svg>''')
        if not png.exists():export_svg(svg,png,1780 if name=='main' else 870)


def photo(p,key,path,width,height):
    pformat(p,line=1,rtl=False,align=WD_ALIGN_PARAGRAPH.CENTER)
    src=Path(path);run=p.add_run();shape=run.add_picture(str(src),width=Mm(width),height=Mm(height))
    for side in ['distL','distR','distT','distB']:shape._inline.set(side,'0')
    with Image.open(src) as im:iw,ih=im.size
    ia=iw/ih;fa=width/height
    if abs(ia-fa)>.00001:
        # Crop in DrawingML; original pixels are preserved. No raster retouching.
        if ia>fa:frac=(1-fa/ia)/2;attrs={'l':str(round(frac*100000)),'r':str(round(frac*100000))}
        else:frac=(1-ia/fa)/2;attrs={'t':str(round(frac*100000)),'b':str(round(frac*100000))}
        fill=run._r.find('.//'+qn('pic:blipFill'));rect=elm('a:srcRect')
        for k,v in attrs.items():rect.set(k,v)
        fill.insert(1,rect)
    dp=shape._inline.docPr;dp.set('name',key);dp.set('descr',key+' — use Change Picture; preserve the frame size and use Crop > Fill.')
    return run


def base_doc(kind):
    d=Document();s=d.sections[0];s.page_width=Mm(210);s.page_height=Mm(297);s.top_margin=Mm(48);s.bottom_margin=Mm(19);s.left_margin=Mm(16);s.right_margin=Mm(16);s.header_distance=Mm(13);s.footer_distance=Mm(11)
    normal=d.styles['Normal'];normal.font.name=AR;normal.font.size=Pt(11);normal.font.color.rgb=RGBColor.from_string(INK)
    for style in ['Normal','Title','Heading 1','Heading 2','Caption']:
        st=d.styles[style];st.font.name=AR;st.font.color.rgb=RGBColor.from_string(INK);rf=st.element.get_or_add_rPr().get_or_add_rFonts()
        for a in list(rf.attrib):
            if 'Theme' in a or 'theme' in a:del rf.attrib[a]
        for tag in ['w:pBdr']:
            for old in st.element.findall('.//'+qn(tag)):old.getparent().remove(old)
        for old in st.element.findall('.//'+qn('w:rPr')+'/'+qn('w:spacing')):old.getparent().remove(old)
        for k in ['ascii','hAnsi','eastAsia','cs']:rf.set(qn('w:'+k),AR)
    d.styles['Title'].font.size=Pt(20);d.styles['Title'].font.bold=True
    settings=d.settings.element;settings.append(elm('w:doNotAutoHyphenate'))
    # Header is editable text plus a discrete PNG derived from the original vector logo.
    h=s.header;hp=h.paragraphs[0];pformat(hp);hp.paragraph_format.line_spacing=Pt(1);hp.paragraph_format.space_after=Pt(0)
    t=table(h,[58,120]);c0,c1=t.rows[0].cells
    p=c0.paragraphs[0];pformat(p,rtl=False,align=WD_ALIGN_PARAGRAPH.RIGHT)
    r=p.add_run();logo_shape=r.add_picture(str(ASSETS/'AlDayel_Primary_Ink_2400.png'),width=Mm(50))
    for side in ['distL','distR','distT','distB']:logo_shape._inline.set(side,'0')
    p=c0.add_paragraph();pformat(p,before=14,rtl=False,align=WD_ALIGN_PARAGRAPH.CENTER);p.paragraph_format.left_indent=Mm(8);text(p,'السكني',8)
    p=c1.paragraphs[0];pformat(p,rtl=False,align=WD_ALIGN_PARAGRAPH.LEFT);text(p,'ALDAYEL RESIDENTIAL',9,rtl=False,latin=True)
    p=c1.add_paragraph();pformat(p,rtl=False,align=WD_ALIGN_PARAGRAPH.LEFT,before=4);text(p,'CORRESPONDENCE' if kind=='letterhead' else 'PROPERTY DETAILS',7.5,rtl=False,latin=True)
    # Only verified brand identity appears in the footer.
    f=s.footer.paragraphs[0];pformat(f,align=WD_ALIGN_PARAGRAPH.RIGHT)
    pp=f._p.get_or_add_pPr();b=elm('w:pBdr');b.append(elm('w:top',**{'w:val':'single','w:sz':'3','w:space':'10','w:color':MIST}));pp.append(b)
    text(f,'الدايل السكني',8);text(f,'   |   ',8,rtl=False,latin=True);text(f,'AlDayel Residential',8,rtl=False,latin=True)
    d.core_properties.title='الدايل السكني '+('ورقة المراسلات الرسمية' if kind=='letterhead' else 'نموذج عرض عقار')
    d.core_properties.subject='Editable branded template';d.core_properties.author='AlDayel Residential';d.core_properties.keywords='AlDayel, residential, RTL, editable template'
    d.core_properties.comments='Native editable text and replaceable image objects. No company contact or property facts are invented.'
    return d


def v(data,key,blank=False,default=None):
    if key in data and data[key] not in (None,''):return str(data[key])
    if default is not None:return default
    labels={'property_type':'نوع العقار','classification':'التصنيف','activity':'النشاط','address':'العنوان','area':'المساحة','area_unit':'وحدة القياس','price':'السعر','currency':'العملة','contact':'رقم التواصل','title':'عنوان العقار','reference':'رقم المرجع','date':'التاريخ','recipient':'اسم الجهة','subject':'عنوان المراسلة','body':'نص المراسلة','signatory':'الاسم والصفة','location_url':'رابط الموقع الجغرافي'}
    return '....................' if blank else '['+labels.get(key,key)+']'


def letterhead(blank=False,data=None,out=None):
    data=data or {};d=base_doc('letterhead')
    t=table(d,[89,89]);c0,c1=t.rows[0].cells
    for cell,label,key in [(c0,'التاريخ','date'),(c1,'المرجع','reference')]:
        p=cell.paragraphs[0];pformat(p);text(p,label+'  ',9,bold=True);control(p,key,v(data,key,blank),10)
    spacer(d,21)
    if not blank:
        p=d.add_paragraph();pformat(p,after=14);text(p,'السادة ',11.5);control(p,'recipient',v(data,'recipient'),11.5);text(p,' المحترمون',11.5)
    p=d.add_paragraph();pformat(p,after=18);text(p,'الموضوع  ',12,bold=True);control(p,'subject',v(data,'subject',blank),12,bold=True)
    if blank:
        p=d.add_paragraph();pformat(p,line=1.65);control(p,'body','',11.5)
    else:
        p=d.add_paragraph();pformat(p,after=16,line=1.65);text(p,'تحية طيبة وبعد',11.5)
        p=d.add_paragraph();pformat(p,after=16,line=1.65);control(p,'body',v(data,'body'),11.5)
        p=d.add_paragraph();pformat(p,before=24,after=12);text(p,'وتفضلوا بقبول التحية',11.5)
        p=d.add_paragraph();pformat(p);control(p,'signatory',v(data,'signatory'),11.5,bold=True)
    out=Path(out or ROOT/'02_LETTERHEAD/Editable_DOCX'/('AlDayel_Letterhead_Blank.docx' if blank else 'AlDayel_Letterhead_Editable.docx'));out.parent.mkdir(parents=True,exist_ok=True);d.save(out);return out


def field(cell,label,key,value,big=False,blank=False):
    set_cell(cell,pad=2.1,bottom_border=True)
    p=cell.paragraphs[0];pformat(p,after=2);text(p,label,8.5,bold=True)
    p=cell.add_paragraph();pformat(p,line=1.15);control(p,key,value,15 if big else 10.5,bold=big)


def real_link(p,url):
    p.paragraph_format.line_spacing=Pt(16)
    u=urlparse(url)
    if u.scheme not in ('http','https') or not u.netloc:raise ValueError('location_url must be a real HTTP(S) destination supplied by the user')
    rid=p.part.relate_to(url,RT.HYPERLINK,is_external=True);h=elm('w:hyperlink',**{'r:id':rid});r=elm('w:r');rp=elm('w:rPr');rf=elm('w:rFonts',**{'w:ascii':AR,'w:hAnsi':AR,'w:cs':AR});rp.append(rf);rp.append(elm('w:color',**{'w:val':INK}));rp.append(elm('w:sz',**{'w:val':'20'}));rp.append(elm('w:szCs',**{'w:val':'20'}));rp.append(elm('w:rtl',**{'w:val':'1'}));rp.append(elm('w:u',**{'w:val':'single'}));r.append(rp);tx=elm('w:t');tx.text='فتح الموقع الجغرافي';r.append(tx);h.append(r);p._p.append(h)


def property_sheet(blank=False,data=None,out=None):
    data=data or {};d=base_doc('property')
    main_height=54 if data.get('location_url') and data.get('show_qr') else 62
    detail_height=28 if data.get('location_url') and data.get('show_qr') else 32
    target=Path(out or ROOT/'04_PROPERTY_SPEC_SHEET/Editable_DOCX'/('AlDayel_Property_Sheet_Blank.docx' if blank else 'AlDayel_Property_Sheet_Editable.docx'))
    target.parent.mkdir(parents=True,exist_ok=True)
    t=table(d,[130,48]);c0,c1=t.rows[0].cells
    p=c0.paragraphs[0];p.style=d.styles['Title'];pformat(p,after=0);text(p,'عرض عقار',20,True)
    p=c0.add_paragraph();pformat(p,after=0);control(p,'title',v(data,'title',blank),11)
    p=c1.paragraphs[0];pformat(p,after=2);text(p,'نوع العرض',8.5)
    p=c1.add_paragraph();pformat(p);control(p,'offer_type',str(data.get('offer_type','للبيع')),15,True)
    spacer(d,7)
    p=d.add_paragraph();pformat(p,line=1,after=0);photo(p,'main_photo',data.get('main_photo',ASSETS/'Photo_Placeholder_main.png'),178,main_height)
    p=d.add_paragraph();pformat(p,after=3);text(p,'الصورة الرئيسية',7.5)
    t=table(d,[89,89]);c0,c1=t.rows[0].cells
    field(c0,'السعر','price_currency',v(data,'price',blank)+' '+v(data,'currency',blank),True)
    field(c1,'المساحة','area_measurement',v(data,'area',blank)+' '+v(data,'area_unit',blank),True)
    spacer(d,3)
    t=table(d,[59.33,59.33,59.34]);
    for cell,label,key in zip(t.rows[0].cells,['نوع العقار','التصنيف','النشاط'],['property_type','classification','activity']):field(cell,label,key,v(data,key,blank))
    spacer(d,4)
    p=d.add_paragraph();pformat(p,after=2);text(p,'العنوان',8.5,True)
    p=d.add_paragraph();pformat(p,after=4,line=1.15);control(p,'address',v(data,'address',blank),10.5)
    p=d.add_paragraph();pformat(p,after=2);text(p,'المواصفات',10.5,True)
    specs=data.get('specifications') or (['..............................']*3 if blank else ['[المواصفة الأولى]','[المواصفة الثانية]','[المواصفة الثالثة]'])
    for i,spec in enumerate(specs):
        p=d.add_paragraph();pformat(p,after=0,line=1.15);text(p,'•  ',10);control(p,'specification_'+str(i+1),str(spec),10)
    spacer(d,5)
    t=table(d,[87,4,87]);c0,space,c1=t.rows[0].cells
    for i,c in enumerate([c0,c1],1):
        p=c.paragraphs[0];pformat(p,line=1);photo(p,'detail_photo_'+str(i),data.get('detail_photo_'+str(i),ASSETS/'Photo_Placeholder_detail.png'),87,detail_height)
        p=c.add_paragraph();pformat(p);text(p,'صورة إضافية '+str(i)+'  ·  اختيارية',7.5)
    spacer(d,4)
    t=table(d,[89,89]);c0,c1=t.rows[0].cells
    p=c0.paragraphs[0];pformat(p,after=2);text(p,'للاستفسار',8.5,True)
    p=c0.add_paragraph();pformat(p);control(p,'contact',v(data,'contact',blank),12,True)
    if data.get('location_url') and data.get('show_qr'):
        import qrcode
        u=str(data['location_url']);parsed=urlparse(u)
        if parsed.scheme not in ('http','https') or not parsed.netloc:raise ValueError('A confirmed HTTP(S) location_url is required for QR generation')
        qr=qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M,box_size=12,border=4);qr.add_data(u);qr.make(fit=True)
        qr_path=target.with_suffix('.qr.png');qr.make_image(fill_color='#'+INK,back_color='white').save(qr_path)
        c1._tc.remove(c1.paragraphs[0]._p)
        inner=table(c1,[64,25]);ct,cq=inner.rows[0].cells
        for empty in c1.paragraphs:
            if not empty.text:pformat(empty,line=1);empty.paragraph_format.line_spacing=Pt(1);text(empty,'',1)
        p=ct.paragraphs[0];pformat(p,after=2);text(p,'الموقع الجغرافي',8.5,True)
        p=ct.add_paragraph();pformat(p);real_link(p,u)
        p=cq.paragraphs[0];photo(p,'location_qr',qr_path,22,22)
    else:
        p=c1.paragraphs[0];pformat(p,after=2);text(p,'الموقع الجغرافي',8.5,True)
        p=c1.add_paragraph();pformat(p)
        if data.get('location_url'):real_link(p,str(data['location_url']))
        else:control(p,'location_url',v(data,'location_url',blank),9.5)
    out=Path(out or ROOT/'04_PROPERTY_SPEC_SHEET/Editable_DOCX'/('AlDayel_Property_Sheet_Blank.docx' if blank else 'AlDayel_Property_Sheet_Editable.docx'));out.parent.mkdir(parents=True,exist_ok=True);d.save(out);return out


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data',type=Path);ap.add_argument('--property-output',type=Path);a=ap.parse_args();asset_setup()
    if a.data:
        data=json.loads(a.data.read_text());print(property_sheet(data=data,out=a.property_output));return
    for blank in [False,True]:print(letterhead(blank));print(property_sheet(blank))
if __name__=='__main__':main()
