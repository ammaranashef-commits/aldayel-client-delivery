"""Assemble verified application previews and package the final delivery.

Thumbnail assembly only: no retouching, generated photographs or upscaling of
image assets. Font binaries remain external where redistribution is restricted.
"""
from pathlib import Path
import argparse
import hashlib
import html
import json
import os
import subprocess
import zipfile
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
INK, PEARL, MIST = '#1C3549', '#F4F3EF', '#CCDDE4'

GROUPS = [
    ('المكتب والمراسلات', [
        ('ورقة مراسلات قابلة للتعبئة', '02_LETTERHEAD/Preview/AlDayel_Letterhead_Editable.png'),
        ('ورقة مراسلات فارغة', '02_LETTERHEAD/Preview/AlDayel_Letterhead_Blank.png'),
        ('نموذج عرض عقار', '04_PROPERTY_SPEC_SHEET/Preview/AlDayel_Property_Sheet_Editable.png'),
        ('نموذج عقار فارغ', '04_PROPERTY_SPEC_SHEET/Preview/AlDayel_Property_Sheet_Blank.png'),
    ]),
    ('اللافتات العقارية', [
        ('لافتة للبيع', '05_SIGNAGE/FOR_SALE/AlDayel_For_Sale_PREVIEW_RGB.png'),
        ('لافتة للإيجار', '05_SIGNAGE/FOR_RENT/AlDayel_For_Rent_PREVIEW_RGB.png'),
    ]),
    ('المنشورات والشعار والخطوط', [
        ('منشور للبيع', '06_INSTAGRAM_POSTS/For_Sale/AlDayel_Instagram_For_Sale.png'),
        ('منشور للإيجار', '06_INSTAGRAM_POSTS/For_Rent/AlDayel_Instagram_For_Rent.png'),
        ('عائلة الشعار الأصلية', '01_LOGO/Preview/AlDayel_Logo_Family_48.png'),
        ('الخطوط الرسمية', '03_FONTS/AlDayel_Official_Font_Specimen.png'),
    ]),
    ('كاروسيل عقاري من خمس شرائح', [
        ('01 · الغلاف', '07_INSTAGRAM_CAROUSEL/Exported_PNG/AlDayel_Carousel_01.png'),
        ('02 · المعلومات', '07_INSTAGRAM_CAROUSEL/Exported_PNG/AlDayel_Carousel_02.png'),
        ('03 · المواصفات', '07_INSTAGRAM_CAROUSEL/Exported_PNG/AlDayel_Carousel_03.png'),
        ('04 · الصور والموقع', '07_INSTAGRAM_CAROUSEL/Exported_PNG/AlDayel_Carousel_04.png'),
        ('05 · التواصل', '07_INSTAGRAM_CAROUSEL/Exported_PNG/AlDayel_Carousel_05.png'),
    ]),
]


def font(size, bold=False):
    filename = 'HelveticaNeueLTArabic-Bold.otf' if bold else 'HelveticaNeueLTArabic-Roman.otf'
    configured = os.environ.get('ALDAYEL_FONT_DIR')
    path = Path(configured) / filename if configured else Path(subprocess.check_output(
        ['fc-match', '-f', '%{file}', 'Helvetica Neue LT Arabic:weight=' + ('bold' if bold else 'regular')],
        text=True).strip())
    if not path.is_file() or path.name != filename:
        raise RuntimeError('Install the original licensed fonts or set ALDAYEL_FONT_DIR.')
    return ImageFont.truetype(str(path), size)


def build_previews():
    preview = ROOT / '08_PREVIEWS'
    preview.mkdir(exist_ok=True)
    width, height = 2400, 3860
    sheet = Image.new('RGB', (width, height), PEARL)
    draw = ImageDraw.Draw(sheet)
    draw.text((2290, 80), 'تطبيقات الهوية السكنية', font=font(68, True), fill=INK, anchor='ra', direction='rtl')
    draw.text((2290, 180), 'الدايل السكني · حزمة التطبيقات الرسمية', font=font(35), fill=INK, anchor='ra', direction='rtl')
    draw.text((110, 105), 'ALDAYEL RESIDENTIAL', font=ImageFont.truetype(str(ROOT/'03_FONTS/PT_Sans/PTSans-Regular.ttf'), 32), fill=INK)
    y = 285
    row_heights = [850, 900, 900, 720]
    for (heading, items), row_height in zip(GROUPS, row_heights):
        draw.text((2290, y), heading, font=font(42, True), fill=INK, anchor='ra', direction='rtl')
        top = y + 95
        gap, full = 32, 2180
        count = len(items)
        cell_width = (full - gap * (count - 1)) // count
        image_height = row_height - 160
        for index, (title, rel) in enumerate(items):
            x = 110 + (count - 1 - index) * (cell_width + gap)
            source = ROOT / rel
            if not source.is_file():
                raise FileNotFoundError(source)
            with Image.open(source) as im:
                image = im.convert('RGB')
                image.thumbnail((cell_width, image_height), Image.Resampling.LANCZOS)
                px = x + (cell_width - image.width) // 2
                py = top + (image_height - image.height) // 2
                sheet.paste(image, (px, py))
                draw.rectangle((px, py, px+image.width-1, py+image.height-1), outline=MIST, width=1)
            draw.text((x+cell_width/2, top+image_height+18), title, font=font(25), fill=INK, anchor='ma', direction='rtl')
        y += row_height
    sheet.save(preview/'AlDayel_Application_Kit_Contact_Sheet.png', optimize=True)
    (preview/'preview-index.json').write_text(json.dumps(GROUPS, ensure_ascii=False, indent=2))
    markdown = ['# معاينات حزمة التطبيقات', '', 'افتح أي رابط لعرض المعاينة بالحجم الكامل. الملفات المعروضة قوالب للتعبئة؛ أماكن الصور والبيانات غير المؤكدة مقصودة.', '', '![لوحة التطبيقات](AlDayel_Application_Kit_Contact_Sheet.png)', '']
    for heading, items in GROUPS:
        markdown += ['## ' + heading, '']
        markdown += [f'- [{title}](../{rel})' for title, rel in items]
        markdown += ['']
    markdown += ['[معاينة الكاروسيل وحده](../07_INSTAGRAM_CAROUSEL/AlDayel_Carousel_Overview.png)', '', '[العودة إلى دليل الحزمة](../README.md)', '']
    (preview/'README.md').write_text('\n'.join(markdown))
    build_gallery()
    print('Built one comprehensive contact sheet and local gallery.')


def build_gallery():
    blocks = []
    for heading, items in GROUPS:
        cards = ''.join(f'<a class="card" href="{html.escape(rel)}"><img loading="lazy" src="{html.escape(rel)}" alt="{html.escape(title)}"><span>{html.escape(title)}</span></a>' for title, rel in items)
        blocks.append(f'<section><h2>{html.escape(heading)}</h2><div class="grid n{len(items)}">{cards}</div></section>')
    actions = [
        ('Word · ورقة المراسلات', '02_LETTERHEAD/Editable_DOCX/AlDayel_Letterhead_Editable.docx'),
        ('Word · مراسلة فارغة', '02_LETTERHEAD/Editable_DOCX/AlDayel_Letterhead_Blank.docx'),
        ('Word · عرض عقار', '04_PROPERTY_SPEC_SHEET/Editable_DOCX/AlDayel_Property_Sheet_Editable.docx'),
        ('Word · عقار فارغ', '04_PROPERTY_SPEC_SHEET/Editable_DOCX/AlDayel_Property_Sheet_Blank.docx'),
        ('PDF · لافتة للبيع', '05_SIGNAGE/FOR_SALE/AlDayel_For_Sale_PRINT_TEMPLATE_CMYK.pdf'),
        ('PDF · لافتة للإيجار', '05_SIGNAGE/FOR_RENT/AlDayel_For_Rent_PRINT_TEMPLATE_CMYK.pdf'),
    ]
    buttons = ''.join(f'<a href="{rel}">{title}</a>' for title, rel in actions)
    page = '''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>الدايل السكني — حزمة التطبيقات</title><style>
    *{box-sizing:border-box}body{margin:0;background:#F4F3EF;color:#1C3549;font-family:"Helvetica Neue LT Arabic",Tahoma,Arial,sans-serif;line-height:1.9}main{max-width:1440px;margin:auto;padding:50px 32px}h1{font-size:34px;margin:0}p{max-width:980px}h2{margin:42px 0 20px;font-size:24px}.actions{display:flex;flex-wrap:wrap;gap:12px;margin:30px 0}.actions a{background:#1C3549;color:#F4F3EF;padding:12px 18px;text-decoration:none}.grid{display:grid;gap:20px;grid-template-columns:repeat(4,1fr)}.n2{grid-template-columns:repeat(2,1fr)}.n5{grid-template-columns:repeat(5,1fr)}.card{color:inherit;text-decoration:none;display:flex;flex-direction:column;align-items:center;padding:12px;border:1px solid #CCDDE4}.card img{width:100%;height:360px;object-fit:contain}.card span{padding-top:15px}footer{border-top:1px solid #CCDDE4;margin-top:45px;padding-top:20px;font-size:14px}@media(max-width:800px){.grid,.n2,.n5{grid-template-columns:repeat(2,1fr)}.card img{height:260px}}@media(max-width:480px){main{padding:28px 16px}.grid,.n2,.n5{grid-template-columns:1fr}}
    </style></head><body><main><h1>الدايل السكني</h1><p>حزمة التطبيقات الرسمية. اختر ملفًا للتعديل أو انقر المعاينة لتكبيرها. ثبّت الخط العربي الأصلي قبل تحرير Word وSVG، واستبدل الصور والحقول ببياناتك المعتمدة قبل نشر إعلان.</p><div class="actions">'''+buttons+'</div>'+''.join(blocks)+'''<footer>المعاينات لا تستبدل ملفات الطباعة. اقرأ README.md وتعليمات كل مجموعة للخطوط والنزف والألوان. هذه بوابة محلية تعمل بعد فك ضغط الحزمة؛ لا تحتاج إلى اتصال لعرض الملفات.</footer></main></body></html>'''
    (ROOT/'OPEN_FIRST.html').write_text(page)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def package():
    files = sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc' and p.name not in ('DELIVERY_MANIFEST.json', 'SHA256SUMS.txt'))
    manifest = {'brand': 'AlDayel Residential', 'delivery': 'Brand Identity Application Kit', 'date': '2026-11-05', 'files': [{'path':str(p.relative_to(ROOT)), 'bytes':p.stat().st_size, 'sha256':sha(p)} for p in files]}
    (ROOT/'DELIVERY_MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    (ROOT/'SHA256SUMS.txt').write_text(''.join(f'{x["sha256"]}  {x["path"]}\n' for x in manifest['files']))
    archive = ROOT.parent/'BRAND_IDENTITY_DELIVERABLES.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in files+[ROOT/'DELIVERY_MANIFEST.json', ROOT/'SHA256SUMS.txt']:
            z.write(p, 'BRAND_IDENTITY_DELIVERABLES/'+str(p.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.infolist()) == len(files)+2
    print(json.dumps({'zip':str(archive), 'bytes':archive.stat().st_size, 'sha256':sha(archive), 'files':len(files)+2}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--previews', action='store_true')
    parser.add_argument('--package', action='store_true')
    args = parser.parse_args()
    if args.previews:
        build_previews()
    if args.package:
        package()
