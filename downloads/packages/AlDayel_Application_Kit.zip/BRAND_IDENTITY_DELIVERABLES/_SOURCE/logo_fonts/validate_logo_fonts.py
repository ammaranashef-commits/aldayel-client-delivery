"""Validate every exported logo/size and create contact proofs from actual PDFs."""
from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E
from PIL import Image,ImageDraw,ImageFont
import fitz
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'01_LOGO';m=json.loads((OUT/'LOGO_MANIFEST.json').read_text());colors=['ink','black','white','pearl','mist','copper'];variants=['primary-ar','primary-en','secondary-ar','secondary-en','wordmark','icon','submark-ar','submark-en']
font=ImageFont.truetype(str(ROOT/'03_FONTS/PT_Sans/PTSans-Regular.ttf'),24);small=ImageFont.truetype(str(ROOT/'03_FONTS/PT_Sans/PTSans-Regular.ttf'),18)
sheet=Image.new('RGB',(2400,3210),'#F4F3EF');dr=ImageDraw.Draw(sheet);dr.text((36,22),'ALDAYEL / EXPORTED VECTOR PDF PROOF',font=font,fill='#1C3549')
checks=[];alphas={};fail=[]
for record in m['records']:
 v=record['variant'];c=record['color'];svg=ROOT/record['svg'];E.parse(svg)
 pdf=ROOT/record['pdf'];d=fitz.open(pdf);pg=d[0];assert len(d)==1 and not pg.get_images(full=True)
 assert len(pg.get_drawings())==record['pdf_vector_drawings']
 pix=pg.get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=True);im=Image.frombytes('RGBA',(pix.width,pix.height),pix.samples)
 x=colors.index(c)*400;y=125+variants.index(v)*380;bg='#1C3549' if c in ['white','pearl','mist'] else '#F4F3EF';dr.rectangle((x+15,y,x+385,y+320),fill=bg)
 im.thumbnail((350,300));sheet.paste(im,(x+200-im.width//2,y+160-im.height//2),im);dr.text((x+25,y+332),v,font=small,fill='#1C3549')
 dr.text((x+28,74),c.upper()+'  '+record['hex'],font=small,fill='#1C3549')
 bbox=[]
 for f in record['png']:
  p=ROOT/f['path'];im=Image.open(p);im.load();assert im.mode=='RGBA' and list(im.size)==f['pixels'];assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
  a=im.getchannel('A');ash=hashlib.sha256(a.tobytes()).hexdigest();key=(v,max(im.size))
  if key not in alphas:alphas[key]=ash
  else:assert alphas[key]==ash,(v,c,'color variant shape differs')
  box=a.getbbox();assert box;edge=[box[0],box[1],im.width-box[2],im.height-box[3]]
  # Original viewport uses 0.5 source-unit overscan; this export changes only the
  # outer canvas to the exact H/4 ink-space margin, allowing <=1px raster rounding.
  ink_h=record['ink_bounds_source_units'][3]*im.height/record['canvas_viewbox'][3]
  expected=ink_h/4
  assert min(edge)>=expected-2,(p.name,edge,expected)
  bbox.append({'px':im.size,'alpha_bounds':box,'minimum_transparent_margin_px':min(edge),'expected_H_over_4_px':round(expected,3)})
 checks.append({'variant':v,'color':c,'pdf_opened':True,'svg_opened':True,'png_files_opened':3,'alpha_shape_matches_other_colors':True,'pdf_vector_only':True,'bounds':bbox})
sheet.save(OUT/'Preview/AlDayel_Logo_Vector_PDF_Proof_48.png')
fd=fitz.open(ROOT/'03_FONTS/AlDayel_Official_Font_Specimen.pdf');assert len(fd)==1
families=[x[3] for x in fd[0].get_fonts(full=True)];assert any('HelveticaNeueLTArabic-Bold' in x for x in families) and any('HelveticaNeueLTArabic-Roman' in x for x in families)
for x in fd[0].get_fonts(full=True):assert fd.extract_font(x[0])[3]
fontfiles=list((ROOT/'03_FONTS').rglob('*.ttf'))+list((ROOT/'03_FONTS').rglob('*.otf'));assert len(fontfiles)==4 and all('PTSans' in x.name for x in fontfiles)
result={'status':'PASS','logo_variants':8,'colors':6,'svg_opened':48,'pdf_opened':48,'png_opened':144,'original_ai_unchanged':len(m['original_ai']),'no_original_eps_available':not m['original_eps_in_archive'],'source_geometry_preserved':all(x['geometry_unchanged'] for x in m['records']),'font_specimen_pdf_sha256':hashlib.sha256((ROOT/'03_FONTS/AlDayel_Official_Font_Specimen.pdf').read_bytes()).hexdigest(),'font_specimen_fonts_embedded':True,'commercial_raw_fonts_distributed':False,'checks':checks}
(OUT/'LOGO_TECHNICAL_VALIDATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
