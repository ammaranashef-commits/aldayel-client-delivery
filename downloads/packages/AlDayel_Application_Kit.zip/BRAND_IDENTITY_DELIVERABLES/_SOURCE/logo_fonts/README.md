# Rebuilding the logo and font kit

Run from any working directory:

```bash
python _SOURCE/logo_fonts/build_logos.py --workers 2
python _SOURCE/logo_fonts/build_font_specimen.py
python _SOURCE/logo_fonts/validate_logo_fonts.py
```

Install Inkscape, PyMuPDF and Pillow. Install the licensed original Arabic fonts and the bundled four PT Sans files before rebuilding the font specimen. The SVG source references the real family names; no substitute font is silently embedded.

Original AI files are already delivered unchanged. To re-extract them from the original archive, add `--original-archive /path/to/Branding_Assets_AlDayel.zip` to the logo command. Without that option the builder keeps the supplied AI files on disk; the production delivery manifest records their original hashes.

Source logos and provenance are read from `../brand/logos/`. Only SVG fill values and the outer canvas are changed. Each PNG size is rendered independently from its vector source. The transparent canvas contains H/4 protection on every side; the actual ink proportions remain unchanged.

The technical validator opens all SVG/PDF/PNG files, verifies image dimensions, alpha-channel geometry across color variants, clear-space margins, vector-only logo PDFs and embedded specimen fonts. Contact proof sheets are assembled only from the exported files.
