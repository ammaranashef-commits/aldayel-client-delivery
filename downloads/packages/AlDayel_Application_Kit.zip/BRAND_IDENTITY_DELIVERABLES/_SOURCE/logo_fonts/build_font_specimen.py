"""Create the approved Arabic/Latin type specimen; requires licensed fonts installed."""
from pathlib import Path
import shutil,json,subprocess,html,hashlib
import fitz
# Stop rather than silently producing a specimen with a fallback font.
for weight,expected in [('regular','HelveticaNeueLTArabic-Roman.otf'),('bold','HelveticaNeueLTArabic-Bold.otf')]:
    actual=subprocess.check_output(['fc-match','-f','%{file}',f'Helvetica Neue LT Arabic:weight={weight}'],text=True).strip()
    if Path(actual).name!=expected:raise RuntimeError(f'Install licensed {expected} before rebuilding the specimen; fallback detected.')
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'03_FONTS';OUT.mkdir(parents=True,exist_ok=True)
FONT_DIR=OUT/'PT_Sans'
FONT_DIR.mkdir(exist_ok=True)
SOURCE=ROOT/'03_FONTS/PT_Sans'
# Font binaries remain in their licensed delivery folder; no remote fetch.
for p in SOURCE.glob('PTSans-*'):
 if p.is_file() and p.resolve()!=(FONT_DIR/p.name).resolve():shutil.copy2(p,FONT_DIR/p.name)
if (SOURCE/'license-evidence').exists() and SOURCE.resolve()!=FONT_DIR.resolve():shutil.copytree(SOURCE/'license-evidence',FONT_DIR/'license-evidence',dirs_exist_ok=True)
INK='#1C3549';PEARL='#F4F3EF';MIST='#CCDDE4';COPPER='#A96B53'
parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="210mm" height="297mm" viewBox="0 0 794 1123"><rect width="794" height="1123" fill="{PEARL}"/>']
def ar(t,x,y,size=20,bold=False):
 # Inkscape/Pango honors SVG rtl direction with the start anchor at the right edge.
 parts.append(f'<text x="{x}" y="{y}" fill="{INK}" font-family="Helvetica Neue LT Arabic" font-size="{size}" font-weight="{700 if bold else 400}" direction="rtl" unicode-bidi="embed" text-anchor="start">{html.escape(t)}</text>')
def en(t,x,y,size=16,bold=False,italic=False):parts.append(f'<text x="{x}" y="{y}" fill="{INK}" font-family="PT Sans" font-size="{size}" font-weight="{700 if bold else 400}" font-style="{"italic" if italic else "normal"}">{html.escape(t)}</text>')
en('ALDAYEL / RESIDENTIAL',64,60,14)
ar('الخطوط الرسمية',730,119,37,True)
ar('نموذج استخدام الأوزان والحروف والأرقام',730,155,18)
en('ARABIC / HELVETICA NEUE LT ARABIC',64,220,15)
ar('العربية',730,220,18,True)
ar('مساحة للقراءة وتفاصيل واضحة',730,285,37,True)
en('75 Bold',64,280,15)
ar('نص عربي واضح بتباعد طبيعي بين السطور.',730,337,25)
en('55 Roman',64,335,15)
ar('أ ب ت ث ج ح خ د ذ ر ز س ش ص ض ط ظ ع غ',730,393,24)
ar('ف ق ك ل م ن هـ و ي',730,434,24)
ar('٠١٢٣٤٥٦٧٨٩',730,480,26)
en('0123456789',64,480,25)
parts.append(f'<rect x="64" y="518" width="666" height="1" fill="{MIST}"/>')
en('LATIN / PT SANS',64,567,15)
en('Residential property',64,630,35,True)
en('Regular  |  Space, light and considered details.',64,678,21)
en('Bold  |  Clear information for every property.',64,719,21,True)
en('Italic  |  Architectural notes and captions.',64,760,21,False,True)
en('Bold Italic  |  Selected emphasis.',64,801,21,True,True)
en('ABCDEFGHIJKLMNOPQRSTUVWXYZ',64,855,22)
en('abcdefghijklmnopqrstuvwxyz  0123456789',64,892,22)
parts.append(f'<rect x="64" y="935" width="666" height="1" fill="{MIST}"/>')
ar('Roman للنصوص، وBold للعناوين والتأكيد.',730,977,18)
ar('يُستخدم المائل للإنجليزية فقط، دون ميل مصطنع للعربية.',730,1010,18)
ar('ملفات الخط العربي التجارية تتطلب ترخيصًا محليًا للتحرير.',730,1043,16)
parts.append('</svg>')
svg=Path(__file__).parent/'AlDayel_Font_Specimen.svg';svg.write_text(''.join(parts))
pdf=OUT/'AlDayel_Official_Font_Specimen.pdf';png=OUT/'AlDayel_Official_Font_Specimen.png'
subprocess.run(['inkscape',str(svg),'--export-area-page','--export-type=pdf','--export-filename='+str(pdf)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
doc=fitz.open(pdf);assert len(doc)==1;doc[0].get_pixmap(dpi=200,alpha=False).save(png)
print(json.dumps({'pdf':str(pdf),'pages':len(doc),'preview_px':[doc[0].get_pixmap(dpi=200).width,doc[0].get_pixmap(dpi=200).height]}))
