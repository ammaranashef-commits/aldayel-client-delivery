"""Export original AlDayel logo paths with measured H/4 transparent margins.
No traced, redrawn, resampled or re-proportioned artwork is used.
Requires Inkscape, Pillow and PyMuPDF. Run from any working directory.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,hashlib,subprocess,xml.etree.ElementTree as ET,shutil,zipfile,argparse
import fitz
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[2]
BRAND=ROOT/'_SOURCE/brand'
OUT=ROOT/'01_LOGO'
SVG='http://www.w3.org/2000/svg'
COLORS={'ink':'#1C3549','black':'#000000','white':'#FFFFFF','pearl':'#F4F3EF','mist':'#CCDDE4','copper':'#A96B53'}
VARIANTS=['primary-ar','primary-en','secondary-ar','secondary-en','wordmark','icon','submark-ar','submark-en']
pro={x['variant']:x for x in json.loads((BRAND/'logos/original/provenance.json').read_text())}
for p in ['Original_Colors/Archive_Originals','Monochrome','Transparent_PNG','Vector','Preview']:(OUT/p).mkdir(exist_ok=True,parents=True)

def sha(b):return hashlib.sha256(b).hexdigest()
def geometry(r):
    keys=['d','transform','x','y','width','height','points','x1','y1','x2','y2','cx','cy','r','rx','ry','href','{http://www.w3.org/1999/xlink}href']
    return [(e.tag,{k:e.get(k) for k in keys if e.get(k) is not None}) for e in r.iter() if e.tag.split('}')[-1] in ['path','use','polygon','polyline','rect','circle','ellipse','line','g']]

def export(job):
    variant,color=job;p=pro[variant]
    source=BRAND/f'logos/residential/aldayel-{variant}-ink.svg'
    r=ET.fromstring(source.read_bytes());before=geometry(r)
    orig=json.loads((BRAND/f'logos/original/aldayel-{variant}-geometry.json').read_text())
    w,h=p['logo_width'],p['logo_height'];x0,y0,*_=map(float,r.get('viewBox').split());safe=h/4
    box=[x0+.5-safe,y0+.5-safe,w+2*safe,h+2*safe]
    r.set('viewBox',' '.join(f'{x:.9f}' for x in box));r.set('width',f'{box[2]:.9f}');r.set('height',f'{box[3]:.9f}')
    r.set('aria-label',f'AlDayel {variant} {color}; original vectors with H/4 clear space')
    for e in r.iter():
        if e.get('fill') and e.get('fill').lower()=='#1c3549':e.set('fill',COLORS[color])
    title=r.find(f'{{{SVG}}}title')
    if title is not None:title.text=f'AlDayel {variant} / {color} / original geometry'
    assert before==geometry(r)
    filebase=f'AlDayel_{variant}_{color}'
    folder=OUT/('Monochrome' if color in ['black','white'] else ('Original_Colors' if color=='ink' else 'Vector'))
    svg=folder/(filebase+'.svg');pdf=folder/(filebase+'.pdf')
    svg.write_bytes(ET.tostring(r,encoding='utf-8',xml_declaration=True))
    subprocess.run(['inkscape',str(svg),'--export-area-page','--export-type=pdf','--export-filename='+str(pdf)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    d=fitz.open(pdf);assert len(d)==1;assert not d[0].get_images(full=True);assert len(d[0].get_drawings())>0
    paths=len(d[0].get_drawings());d.close()
    rows=[]
    for size in [2000,4000,8000]:
        png=OUT/'Transparent_PNG'/color/f'{filebase}_{size}px.png';png.parent.mkdir(exist_ok=True,parents=True)
        side='width' if box[2]>=box[3] else 'height'
        subprocess.run(['inkscape',str(svg),'--export-area-page','--export-type=png','--export-background-opacity=0',f'--export-{side}={size}','--export-filename='+str(png)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        im=Image.open(png);assert max(im.size)==size;assert im.mode=='RGBA';alpha=im.getchannel('A');assert alpha.getextrema()==(0,255)
        bbox=alpha.getbbox();assert bbox and min(bbox[:2])>0 and bbox[2]<im.width and bbox[3]<im.height
        rows.append({'path':str(png.relative_to(ROOT)),'pixels':list(im.size),'alpha':True,'sha256':sha(png.read_bytes())})
    return {'variant':variant,'color':color,'hex':COLORS[color],'svg':str(svg.relative_to(ROOT)),'pdf':str(pdf.relative_to(ROOT)),'source_svg_sha256':sha(source.read_bytes()),'original_geometry_sha256':orig['geometry_sha256'],'geometry_unchanged':True,'safe_margin_source_units':safe,'ink_bounds_source_units':[x0+.5,y0+.5,w,h],'canvas_viewbox':box,'pdf_vector_drawings':paths,'pdf_raster_images':0,'png':rows}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--original-archive');ap.add_argument('--workers',type=int,default=2);args=ap.parse_args()
    records=list(ThreadPoolExecutor(max_workers=args.workers).map(export,[(v,c) for v in VARIANTS for c in COLORS]))
    original=[]
    if args.original_archive:
        with zipfile.ZipFile(args.original_archive) as z:
            for v in VARIANTS:
                p=pro[v];rel='Branding Assets - AlDayel Real Estate/Visual identity/'+p['source_relative_to_identity'];data=z.read(rel);assert sha(data)==p['source_sha256']
                dst=OUT/'Original_Colors/Archive_Originals'/f'AlDayel_{v}_ORIGINAL_UNCHANGED.ai';dst.write_bytes(data)
                original.append({'variant':v,'file':str(dst.relative_to(ROOT)),'source_archive_path':rel,'sha256':sha(data),'unchanged':True})
            eps=[i.filename for i in z.infolist() if i.filename.lower().endswith('.eps') and '/Logos/' in i.filename and not i.filename.startswith('__MACOSX/') and not Path(i.filename).name.startswith('._')]
    else:
        eps=[]
        for v in VARIANTS:
            p=pro[v];dst=OUT/'Original_Colors/Archive_Originals'/f'AlDayel_{v}_ORIGINAL_UNCHANGED.ai'
            if dst.exists():
                data=dst.read_bytes();assert sha(data)==p['source_sha256']
                original.append({'variant':v,'file':str(dst.relative_to(ROOT)),'source_archive_path':'Branding Assets - AlDayel Real Estate/Visual identity/'+p['source_relative_to_identity'],'sha256':sha(data),'unchanged':True})
    result={'logo_variants':8,'colors':6,'svg_count':48,'pdf_count':48,'png_count':144,'clear_space':'X=H/4, measured from actual ink bounds; transparent canvas includes X on each edge','original_geometry':'Every path, use reference and transform is byte-identical in its attribute value to the approved original-derived source SVG. Only fills and outer viewport dimensions change.','residential_default':'primary-ar in ink; residential descriptor remains a separately editable text element with gap >=H/4 in application templates. It is not fused into the official master logo.','records':records,'original_ai':original,'original_eps_in_archive':eps}
    (OUT/'LOGO_MANIFEST.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    # Contact sheets compose exported assets; they do not retouch artwork.
    fontpath=ROOT/'03_FONTS/PT_Sans/PTSans-Regular.ttf'
    if not fontpath.exists():fontpath=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
    font=ImageFont.truetype(str(fontpath),24);small=ImageFont.truetype(str(fontpath),18)
    sheet=Image.new('RGB',(2400,3210),'#F4F3EF');dr=ImageDraw.Draw(sheet)
    dr.text((36,22),'ALDAYEL / ORIGINAL LOGO FAMILY',font=font,fill='#1C3549')
    for col,(color,hx) in enumerate(COLORS.items()):
        x=col*400;dr.text((x+28,74),color.upper()+'  '+hx,font=small,fill='#1C3549')
        for row,v in enumerate(VARIANTS):
            y=125+row*380;dark=color in ['white','pearl','mist'];bg='#1C3549' if dark else '#F4F3EF'
            dr.rectangle((x+15,y,x+385,y+320),fill=bg)
            im=Image.open(OUT/'Transparent_PNG'/color/f'AlDayel_{v}_{color}_2000px.png').convert('RGBA');im.thumbnail((350,300));sheet.paste(im,(x+200-im.width//2,y+160-im.height//2),im)
            dr.text((x+25,y+332),v,font=small,fill='#1C3549')
    sheet.save(OUT/'Preview/AlDayel_Logo_Family_48.png')
    print(json.dumps({'svg':48,'pdf':48,'png':144,'original_ai':len(original),'eps':len(eps)}))
