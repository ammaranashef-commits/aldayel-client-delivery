# معاينات حزمة التطبيقات

افتح أي رابط لعرض المعاينة بالحجم الكامل. الملفات المعروضة قوالب للتعبئة؛ أماكن الصور والبيانات غير المؤكدة مقصودة.

![لوحة التطبيقات](AlDayel_Application_Kit_Contact_Sheet.png)

## المكتب والمراسلات

- [ورقة مراسلات قابلة للتعبئة](../02_LETTERHEAD/Preview/AlDayel_Letterhead_Editable.png)
- [ورقة مراسلات فارغة](../02_LETTERHEAD/Preview/AlDayel_Letterhead_Blank.png)
- [نموذج عرض عقار](../04_PROPERTY_SPEC_SHEET/Preview/AlDayel_Property_Sheet_Editable.png)
- [نموذج عقار فارغ](../04_PROPERTY_SPEC_SHEET/Preview/AlDayel_Property_Sheet_Blank.png)

## اللافتات العقارية

- [لافتة للبيع](../05_SIGNAGE/FOR_SALE/AlDayel_For_Sale_PREVIEW_RGB.png)
- [لافتة للإيجار](../05_SIGNAGE/FOR_RENT/AlDayel_For_Rent_PREVIEW_RGB.png)

## المنشورات والشعار والخطوط

- [منشور للبيع](../06_INSTAGRAM_POSTS/For_Sale/AlDayel_Instagram_For_Sale.png)
- [منشور للإيجار](../06_INSTAGRAM_POSTS/For_Rent/AlDayel_Instagram_For_Rent.png)
- [عائلة الشعار الأصلية](../01_LOGO/Preview/AlDayel_Logo_Family_48.png)
- [الخطوط الرسمية](../03_FONTS/AlDayel_Official_Font_Specimen.png)

## كاروسيل عقاري من خمس شرائح

- [01 · الغلاف](../07_INSTAGRAM_CAROUSEL/Exported_PNG/AlDayel_Carousel_01.png)
- [02 · المعلومات](../07_INSTAGRAM_CAROUSEL/Exported_PNG/AlDayel_Carousel_02.png)
- [03 · المواصفات](../07_INSTAGRAM_CAROUSEL/Exported_PNG/AlDayel_Carousel_03.png)
- [04 · الصور والموقع](../07_INSTAGRAM_CAROUSEL/Exported_PNG/AlDayel_Carousel_04.png)
- [05 · التواصل](../07_INSTAGRAM_CAROUSEL/Exported_PNG/AlDayel_Carousel_05.png)

[معاينة الكاروسيل وحده](../07_INSTAGRAM_CAROUSEL/AlDayel_Carousel_Overview.png)

[العودة إلى دليل الحزمة](../README.md)
