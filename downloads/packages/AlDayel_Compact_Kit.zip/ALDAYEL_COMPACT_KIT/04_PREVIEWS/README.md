# معاينة الحزمة المختصرة

![المعاينة](AlDayel_Compact_Overview.png)

- [الشعار الأساسي](../01_LOGO/AlDayel_Logo_Primary_2000px.png)
- [ورقة بيع العقار](../02_PROPERTY_SHEET/AlDayel_Property_Sale.png)
- [لافتة للبيع](../03_SIGNAGE/FOR_SALE/AlDayel_For_Sale_PREVIEW_RGB.png)
- [لافتة للإيجار](../03_SIGNAGE/FOR_RENT/AlDayel_For_Rent_PREVIEW_RGB.png)

[تعليمات الحزمة](../README.md)
