"""Assemble compact application previews and a checksummed ZIP.
Previews are thumbnails of actual final exports; artwork is not retouched.
"""
from pathlib import Path
import argparse, hashlib, html, json, subprocess, zipfile
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
ITEMS = [
    ('الشعار الأساسي', '01_LOGO/AlDayel_Logo_Primary_2000px.png'),
    ('ورقة بيع العقار', '02_PROPERTY_SHEET/AlDayel_Property_Sale.png'),
    ('لافتة للبيع', '03_SIGNAGE/FOR_SALE/AlDayel_For_Sale_PREVIEW_RGB.png'),
    ('لافتة للإيجار', '03_SIGNAGE/FOR_RENT/AlDayel_For_Rent_PREVIEW_RGB.png'),
]

def previews():
    dest = ROOT / '04_PREVIEWS'
    dest.mkdir(exist_ok=True)
    fp = subprocess.check_output(['fc-match','-f','%{file}','Helvetica Neue LT Arabic:weight=bold'],text=True).strip()
    if Path(fp).name != 'HelveticaNeueLTArabic-Bold.otf':
        raise RuntimeError('Install the licensed original Arabic font before building this preview.')
    canvas = Image.new('RGB',(1800,1760),'#F4F3EF')
    draw = ImageDraw.Draw(canvas)
    draw.text((1710,60),'الدايل · الحزمة المختصرة',fill='#1C3549',font=ImageFont.truetype(fp,53),anchor='ra',direction='rtl')
    cells = [(100,200,760,650),(940,200,760,650),(100,1050,760,532),(940,1050,760,532)]
    for (label,rel),(x,y,w,h) in zip(ITEMS,cells):
        im = Image.open(ROOT/rel).convert('RGBA')
        im.thumbnail((w,h),Image.Resampling.LANCZOS)
        pos = (x+(w-im.width)//2,y+(h-im.height)//2)
        canvas.paste(im,pos,im)
        draw.text((x+w/2,y+h+25),label,fill='#1C3549',font=ImageFont.truetype(fp,29),anchor='ma',direction='rtl')
    canvas.save(dest/'AlDayel_Compact_Overview.png',optimize=True)
    lines=['# معاينة الحزمة المختصرة','','![المعاينة](AlDayel_Compact_Overview.png)','']
    lines += [f'- [{title}](../{rel})' for title,rel in ITEMS]
    lines += ['','[تعليمات الحزمة](../README.md)','']
    (dest/'README.md').write_text('\n'.join(lines))
    links=[('Word · ورقة بيع العقار','02_PROPERTY_SHEET/AlDayel_Property_Sale.docx'),('PDF · ورقة بيع العقار','02_PROPERTY_SHEET/AlDayel_Property_Sale.pdf'),('الشعار · PNG 8000','01_LOGO/AlDayel_Logo_Primary_8000px.png'),('PDF · لافتة للبيع','03_SIGNAGE/FOR_SALE/AlDayel_For_Sale_PRINT_TEMPLATE_CMYK.pdf'),('PDF · لافتة للإيجار','03_SIGNAGE/FOR_RENT/AlDayel_For_Rent_PRINT_TEMPLATE_CMYK.pdf')]
    buttons=''.join(f'<a href="{url}">{html.escape(label)}</a>' for label,url in links)
    cards=''.join(f'<a class="card" href="{url}"><img src="{url}" alt="{label}"><span>{label}</span></a>' for label,url in ITEMS)
    page='''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>الدايل — الحزمة المختصرة</title><style>*{box-sizing:border-box}body{margin:0;background:#F4F3EF;color:#1C3549;font-family:"Helvetica Neue LT Arabic",Tahoma,Arial,sans-serif;line-height:1.9}main{max-width:1250px;margin:auto;padding:40px 24px}h1{font-size:30px}.links{display:flex;flex-wrap:wrap;gap:12px;margin:30px 0}.links a{padding:10px 16px;background:#1C3549;color:#F4F3EF;text-decoration:none}.grid{display:grid;grid-template-columns:1fr 1fr;gap:25px}.card{display:flex;flex-direction:column;align-items:center;text-decoration:none;color:inherit;padding:20px;border:1px solid #CCDDE4}.card img{width:100%;height:400px;object-fit:contain}.card span{padding-top:16px}@media(max-width:650px){.grid{grid-template-columns:1fr}.card img{height:330px}}</style></head><body><main><h1>الدايل — الحزمة المختصرة</h1><p>الشعار الأساسي، ورقة بيع عقار بصورة واحدة أسفل المعلومات، ولافتتا البيع والإيجار.</p><div class="links">'''+buttons+'</div><div class="grid">'+cards+'''</div><p>ثبّت الخط الأصلي قبل تحرير Word أو SVG، واستبدل حقول البيانات والصورة بمعلوماتك المعتمدة. تعليمات الاستخدام والطباعة في README.md.</p></main></body></html>'''
    (ROOT/'OPEN_FIRST.html').write_text(page)

def package():
    files=sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name not in ('MANIFEST.json','SHA256SUMS.txt'))
    entries=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
    (ROOT/'MANIFEST.json').write_text(json.dumps({'files':entries},ensure_ascii=False,indent=2))
    (ROOT/'SHA256SUMS.txt').write_text(''.join(f'{e["sha256"]}  {e["path"]}\n' for e in entries))
    output=ROOT.parent/'ALDAYEL_COMPACT_KIT.zip'
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files+[ROOT/'MANIFEST.json',ROOT/'SHA256SUMS.txt']:
            z.write(p,ROOT.name+'/'+str(p.relative_to(ROOT)))
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None
        for e in entries:
            assert hashlib.sha256(z.read(ROOT.name+'/'+e['path'])).hexdigest()==e['sha256']
    print(json.dumps({'zip':str(output),'bytes':output.stat().st_size,'entries':len(entries)+2,'sha256':hashlib.sha256(output.read_bytes()).hexdigest()}))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--previews',action='store_true');ap.add_argument('--package',action='store_true');args=ap.parse_args()
    if args.previews:previews()
    if args.package:package()
