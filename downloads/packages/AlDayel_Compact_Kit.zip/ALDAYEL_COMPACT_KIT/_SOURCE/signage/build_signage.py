"""Build original-logo AlDayel signage with native editable Arabic.
The print PDFs use outline text, exact approved CMYK values, real 3 mm bleed,
and the approved-reference Artifex SWOP ICC output intent. No PDF/X certification.
Run with licensed Helvetica Neue LT Arabic Roman/Bold installed via fontconfig.
"""
from pathlib import Path
import argparse, copy, hashlib, html, json, os, re, shutil, subprocess, tempfile
import xml.etree.ElementTree as ET
from pypdf import PdfReader, PdfWriter
from pypdf.generic import (ArrayObject, ContentStream, DecodedStreamObject,
    DictionaryObject, FloatObject, NameObject, NumberObject, TextStringObject)
import fitz

ROOT=Path(__file__).resolve().parents[2]
SOURCE=Path(__file__).resolve().parent
BRAND=ROOT/'_SOURCE/brand'
SVG='http://www.w3.org/2000/svg'
INKSCAPE='http://www.inkscape.org/namespaces/inkscape'
ET.register_namespace('',SVG);ET.register_namespace('inkscape',INKSCAPE)
COLORS={'ink':'#1C3549','pearl':'#F4F3EF','mist':'#CCDDE4','copper':'#A96B53'}
CMYK={'ink':(.98,.76,.47,.60),'pearl':(.03,.03,.05,0),'mist':(.19,.07,.07,0),'copper':(.27,.65,.75,.13)}
PT_PER_MM=72/25.4

def run(args):
    r=subprocess.run([str(x) for x in args],check=True,text=True,capture_output=True)
    return r.stdout

def tag(name,attrs=None,text=None):
    e=ET.Element('{'+SVG+'}'+name,{k:str(v) for k,v in (attrs or {}).items()})
    if text is not None:e.text=text
    return e

def txt(parent,ident,text,x,y,size,color,weight=400,arabic=True,anchor='middle'):
    family='Helvetica Neue LT Arabic' if arabic else 'PT Sans'
    e=tag('text',{'id':ident,'x':x,'y':y,'fill':color,'font-family':family,
        'font-weight':weight,'font-size':size,'text-anchor':anchor,
        'direction':'rtl' if arabic else 'ltr','unicode-bidi':'plaintext'},text)
    parent.append(e);return e

def original_logo(color,x,y,width):
    p=BRAND/f'logos/aldayel-primary-ar-{color}.svg'
    root=ET.parse(p).getroot();_,_,vw,vh=map(float,root.attrib['viewBox'].split())
    root.attrib.update({'id':'official-original-logo','x':str(x),'y':str(y),
        'width':str(width),'height':str(width*vh/vw),'preserveAspectRatio':'xMidYMid meet'})
    return root,p,width*vh/vw

def qr_group(parent,data,fg,bg):
    g=tag('g',{'id':'optional-qr','aria-label':'Optional geographic QR placement'});parent.append(g)
    x,y,s=55,550,78
    url=data.get('geographic_url','').strip()
    if url:
        from urllib.parse import urlparse
        if urlparse(url).scheme not in ('https','http') or not urlparse(url).netloc:raise ValueError('Supply a valid confirmed geographic HTTPS URL')
        try:import qrcode
        except ImportError:raise RuntimeError('Install qrcode only when a real URL is provided. No QR is generated for blank data.')
        q=qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M,box_size=1,border=4);q.add_data(url);q.make(fit=True)
        m=q.get_matrix();pitch=s/len(m)
        # Always dark modules on the approved light substrate with a 4-module quiet zone.
        g.append(tag('rect',{'x':x,'y':y,'width':s,'height':s,'fill':COLORS['pearl']}))
        for row,line in enumerate(m):
            for col,on in enumerate(line):
                if on:g.append(tag('rect',{'x':x+col*pitch,'y':y+row*pitch,'width':pitch,'height':pitch,'fill':COLORS['ink']}))
        txt(g,'qr-label','موقع العقار',x+s/2,y+s+16,10,fg)
    elif data.get('show_optional_qr_placeholder',True):
        g.append(tag('rect',{'x':x,'y':y,'width':s,'height':s,'fill':'none','stroke':fg,'stroke-width':.8}))
        txt(g,'qr-placeholder','QR',x+s/2,y+42,18,fg,400,False)
        txt(g,'qr-optional','اختياري',x+s/2,y+61,10,fg)
        txt(g,'qr-label','رابط الموقع',x+s/2,y+s+16,10,fg)
    else:parent.remove(g)

def make_svg(kind,data):
    rent=kind=='FOR_RENT';bg=COLORS['ink'] if rent else COLORS['pearl'];fg=COLORS['pearl'] if rent else COLORS['ink']
    root=tag('svg',{'version':'1.1','width':'1006mm','height':'706mm','viewBox':'-3 -3 1006 706',
        'role':'img','aria-label':'AlDayel '+('For Rent' if rent else 'For Sale')+' editable signage'})
    root.append(tag('title',text=('الدايل — لافتة للإيجار' if rent else 'الدايل — لافتة للبيع')))
    root.append(tag('desc',text='Native editable Arabic type, original logo paths preserved. Trim1000x700mm, real3mm bleed. Phone and geographic URL remain blank until confirmed.'))
    root.append(tag('rect',{'id':'bleed-background','x':-3,'y':-3,'width':1006,'height':706,'fill':bg}))
    header=tag('g',{'id':'brand-header'});root.append(header)
    logo,p,lh=original_logo('pearl' if rent else 'ink',660,50,290);header.append(logo)
    txt(header,'brand-latin-1','ALDAYEL',55,85,17,fg,400,False,'start')
    heading=tag('g',{'id':'headline-placement'});root.append(heading)
    txt(heading,'main-headline','للإيجار' if rent else 'للبيع',500,450,300,fg,700,True)
    footer=tag('g',{'id':'contact-panel'});root.append(footer)
    footer.append(tag('rect',{'id':'contact-background','x':-3,'y':535,'width':1006,'height':168,'fill':fg}))
    txt(footer,'contact-label','للاستفسار',945,565,18,bg,400,True,'start')
    phone=data.get('phone','').strip().translate(str.maketrans('٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹','01234567890123456789'))
    if phone and not re.fullmatch(r'[+0-9 ()\-]+',phone):raise ValueError('Phone field accepts digits, +, spaces, parentheses and hyphens only.')
    txt(footer,'contact-value',phone or 'أضف رقم التواصل',945,626,54 if phone else 46,bg,700,not bool(phone),'end' if phone else 'start')
    qr_group(footer,data,bg,fg)
    # This nonprinting layer makes the trim/safe geometry inspectable in vector editors.
    guides=tag('g',{'id':'print-guides','display':'none',f'{{{INKSCAPE}}}groupmode':'layer',f'{{{INKSCAPE}}}label':'NONPRINTING Trim and50mm safety'});root.append(guides)
    guides.append(tag('rect',{'x':0,'y':0,'width':1000,'height':700,'fill':'none','stroke':COLORS['copper'],'stroke-width':.5}))
    guides.append(tag('rect',{'x':50,'y':50,'width':900,'height':600,'fill':'none','stroke':COLORS['mist'],'stroke-width':.5}))
    return root,{'logo_source':str(p.relative_to(ROOT)),'logo_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'logo_display_mm':[290,lh],'minimum_safe_mm':50,'logo_bottom_mm':50+lh,'required_x_mm':lh/4}

def write(root,path):ET.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)

def fit_headline(root,path):
    write(root,path)
    line=run(['inkscape',path,'--query-id=main-headline','--query-all'])
    # query-all coordinates are viewport CSS px; the print svg origin has 3mm bleed.
    match=next((s.split(',') for s in line.splitlines() if s.startswith('main-headline,')),None)
    if not match:raise RuntimeError('Could not measure original-font headline')
    x,y,w,h=map(float,match[1:]);factor=min(840/(w*25.4/96),238/(h*25.4/96))
    e=next(e for e in root.iter() if e.get('id')=='main-headline');e.set('font-size',str(300*factor))
    write(root,path)
    line=run(['inkscape',path,'--query-id=main-headline','--query-all'])
    vals=next(s.split(',') for s in line.splitlines() if s.startswith('main-headline,'));x,y,w,h=map(float,vals[1:])
    # Center actual ink, not font metrics, in the allotted large headline field.
    cx=(x+w/2)*25.4/96-3;cy=(y+h/2)*25.4/96-3
    g=next(e for e in root.iter() if e.get('id')=='headline-placement');g.set('transform',f'translate({500-cx:.8f},{350-cy:.8f})')
    return {'font_size_mm':float(e.get('font-size')),'ink_width_mm':w*25.4/96,'ink_height_mm':h*25.4/96,'ink_center_mm':[500,350]}

def cmyk_pdf(rgb_path,out_path,icc_path):
    reader=PdfReader(rgb_path);writer=PdfWriter();writer.clone_document_from_reader(reader)
    known={tuple(int(COLORS[n][i:i+2],16)/255 for i in (1,3,5)):v for n,v in CMYK.items()};known[(0,0,0)]=(0,0,0,1);known[(1,1,1)]=(0,0,0,0)
    paints=[]
    def convert(stream):
        c=ContentStream(stream,writer)
        for operands,op in c.operations:
            if op in (b'rg',b'RG'):
                rgb=tuple(float(v) for v in operands)
                nearest=min(known,key=lambda v:sum(abs(a-b) for a,b in zip(v,rgb)))
                if max(abs(a-b) for a,b in zip(nearest,rgb))>0.00005:raise ValueError(f'Unapproved RGB paint in exported vector PDF: {rgb}')
                vals=known[nearest];paints.append(vals)
                operands[:]=[FloatObject(v) for v in vals]
        c.operations=[(operands,b'k' if op==b'rg' else b'K' if op==b'RG' else op) for operands,op in c.operations]
        return c
    visited=set()
    def forms(resources):
        resources=resources.get_object()
        for ref in resources.get('/XObject',{}).get_object().values() if '/XObject' in resources else []:
            x=ref.get_object();ident=id(x)
            if ident in visited:continue
            visited.add(ident)
            if x.get('/Subtype')=='/Form':
                conv=convert(x);x.set_data(conv.get_data())
                if '/Resources' in x:forms(x['/Resources'])
    for pg in writer.pages:
        pg.replace_contents(convert(pg.get_contents()))
        if '/Resources' in pg:forms(pg['/Resources'])
        media=[0,0,1006*PT_PER_MM,706*PT_PER_MM];trim=[3*PT_PER_MM,3*PT_PER_MM,1003*PT_PER_MM,703*PT_PER_MM]
        for box,vals in [('/MediaBox',media),('/CropBox',media),('/BleedBox',media),('/TrimBox',trim)]:pg[NameObject(box)]=ArrayObject([FloatObject(v) for v in vals])
    icc=DecodedStreamObject();icc.set_data(Path(icc_path).read_bytes());icc[NameObject('/N')]=NumberObject(4);icc[NameObject('/Alternate')]=NameObject('/DeviceCMYK');ir=writer._add_object(icc)
    oi=DictionaryObject({NameObject('/Type'):NameObject('/OutputIntent'),NameObject('/S'):NameObject('/GTS_PDFX'),NameObject('/OutputConditionIdentifier'):TextStringObject('Artifex CMYK SWOP Profile'),NameObject('/RegistryName'):TextStringObject('http://www.color.org'),NameObject('/Info'):TextStringObject('Approved identity reference profile; printer-specific proof required. Not a certified PDF/X master.'),NameObject('/DestOutputProfile'):ir})
    writer._root_object[NameObject('/OutputIntents')]=ArrayObject([writer._add_object(oi)])
    writer.add_metadata({'/Title':out_path.stem,'/Author':'AlDayel','/Subject':'1000x700mm vector signage template with3mm bleed; complete confirmed contact data before production.','/Creator':'AlDayel editable SVG/Inkscape pipeline','/Keywords':'AlDayel, CMYK, vector, 3mm bleed, template'})
    with out_path.open('wb') as f:writer.write(f)
    return {'exact_cmyk_paints':sorted(set(paints)),'output_intent':'Artifex CMYK SWOP Profile','icc_sha256':hashlib.sha256(Path(icc_path).read_bytes()).hexdigest()}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--config',default=str(SOURCE/'signage-data.json'));ap.add_argument('--output-root',default=str(ROOT));a=ap.parse_args()
    outroot=Path(a.output_root).resolve();data=json.loads(Path(a.config).read_text())
    assert data['trim_mm']==[1000,700] and data['bleed_mm']==3,'This tested edition uses1000x700mm trim with3mm bleed.'
    icc=Path(os.environ.get('ALDAYEL_CMYK_ICC','/usr/share/color/icc/ghostscript/default_cmyk.icc'))
    if not icc.is_file():raise FileNotFoundError('Provide Artifex CMYK SWOP profile via ALDAYEL_CMYK_ICC')
    from PIL import ImageCms
    if ImageCms.getProfileName(ImageCms.getOpenProfile(str(icc))).strip()!='Artifex CMYK SWOP Profile':raise ValueError('This edition uses the approved Artifex SWOP reference separations; a different printer profile requires an explicit prepress color conversion.')
    for weight in ('regular','bold'):
        selected=run(['fc-match',f'Helvetica Neue LT Arabic:weight={weight}','-f','%{family}|%{file}'])
        if not selected.startswith('Helvetica Neue LT Arabic|'):raise RuntimeError('Install the licensed original Arabic font. No substitution is permitted.')
        if weight=='bold' and 'Bold' not in selected:raise RuntimeError('The real Bold face is required; synthetic bold is not accepted.')
    for weight in ('regular','bold'):
        selected=run(['fc-match',f'PT Sans:weight={weight}','-f','%{family}|%{file}'])
        if not selected.startswith('PT Sans|'):raise RuntimeError('Install the provided PT Sans family before exporting; no Latin font substitution is permitted.')
    records=[]
    with tempfile.TemporaryDirectory(prefix='aldayel-signage-') as td:
        td=Path(td)
        for kind in ('FOR_SALE','FOR_RENT'):
            out=outroot/'03_SIGNAGE'/kind;out.mkdir(exist_ok=True,parents=True)
            stem='AlDayel_For_Sale' if kind=='FOR_SALE' else 'AlDayel_For_Rent'
            root,proof=make_svg(kind,data)
            fit=fit_headline(root,td/f'{kind}-layout.svg')
            editable=out/f'{stem}_EDITABLE.svg';write(root,editable)
            rgb=td/f'{kind}-rgb.pdf'
            run(['inkscape',editable,'--export-area-page','--export-text-to-path',f'--export-filename={rgb}'])
            pdf=out/f'{stem}_PRINT_TEMPLATE_CMYK.pdf';colorproof=cmyk_pdf(rgb,pdf,icc)
            # Preview is a separate RGB trim export, not a press master or an upscaled bitmap.
            prev=copy.deepcopy(root);prev.set('width','1000mm');prev.set('height','700mm');prev.set('viewBox','0 0 1000 700')
            preview_svg=td/f'{kind}-trim.svg';write(prev,preview_svg)
            preview=out/f'{stem}_PREVIEW_RGB.png'
            run(['inkscape',preview_svg,'--export-area-page','--export-width=3000',f'--export-filename={preview}'])
            doc=fitz.open(pdf);pg=doc[0]
            rd=PdfReader(pdf);ct=ContentStream(rd.pages[0].get_contents(),rd);rgbops=[op.decode() for vals,op in ct.operations if op in (b'rg',b'RG')]
            record={'variant':kind,'editable_svg':str(editable.relative_to(outroot)),'print_pdf':str(pdf.relative_to(outroot)),'preview_png':str(preview.relative_to(outroot)),
                'trim_mm':[1000,700],'media_mm':[1006,706],'bleed_mm':3,'svg_live_text_nodes':len(ET.parse(editable).findall('.//{'+SVG+'}text')),'pdf_pages':len(doc),'pdf_images':len(pg.get_images()),'pdf_fonts':len(pg.get_fonts()),'pdf_vector_paths':len(pg.get_drawings()),'remaining_rgb_operators':rgbops,'proof':proof,'headline':fit,'color':colorproof,'phone_confirmed':bool(data.get('phone')),'geographic_url_supplied':bool(data.get('geographic_url')),
                'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (editable,pdf,preview)}}
            records.append(record)
            print(json.dumps({'variant':kind,'paths':record['pdf_vector_paths'],'images':record['pdf_images'],'native_text':record['svg_live_text_nodes']},ensure_ascii=False))
    (outroot/'03_SIGNAGE/signage-production-check.json').write_text(json.dumps({'status':'structural_pass_pending_visual_review','records':records},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
