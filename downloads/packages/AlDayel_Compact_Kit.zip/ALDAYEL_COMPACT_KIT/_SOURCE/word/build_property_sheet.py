"""Native editable A4 AlDayel property sheet: one field per row, one bottom photo."""
from pathlib import Path
import argparse,json,re,subprocess
from urllib.parse import urlparse
from PIL import Image
from docx import Document
from docx.shared import Mm,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
ASSETS=HERE/'assets'
AR='Helvetica Neue LT Arabic'; EN='PT Sans'; INK='1C3549'; MIST='CCDDE4'
MAXIMUM={};CONTROL_ID=200

def el(tag,**kw):
 e=OxmlElement(tag)
 for k,v in kw.items():e.set(qn(k) if ':' in k else k,str(v))
 return e

def para(p,before=0,after=0,rtl=True,align=None):
 MAXIMUM[p._p]=0;f=p.paragraph_format;f.space_before=Pt(before);f.space_after=Pt(after);f.line_spacing=1;f.keep_together=True;f.keep_with_next=False
 p.alignment=align if align is not None else (WD_ALIGN_PARAGRAPH.RIGHT if rtl else WD_ALIGN_PARAGRAPH.LEFT)
 pr=p._p.get_or_add_pPr();old=pr.find(qn('w:bidi'))
 if old is not None:pr.remove(old)
 pos=pr.find(qn('w:spacing'));pr.insert(list(pr).index(pos) if pos is not None else 0,el('w:bidi',**{'w:val':'1' if rtl else '0'}))
 jc=pr.find(qn('w:jc'))
 if jc is not None and (align is None or (rtl and align==WD_ALIGN_PARAGRAPH.RIGHT) or (not rtl and align==WD_ALIGN_PARAGRAPH.LEFT)):jc.set(qn('w:val'),'start')
 return p

def run(p,value,size=11,bold=False,latin=False,rtl=True):
 r=p.add_run(value);r.font.name=EN if latin else AR;r.font.size=Pt(size);r.font.bold=bold;r.font.color.rgb=RGBColor.from_string(INK)
 m=max(MAXIMUM.get(p._p,0),size);MAXIMUM[p._p]=m;p.paragraph_format.line_spacing=Pt(m*1.5+1)
 pr=r._r.get_or_add_rPr();rf=pr.get_or_add_rFonts()
 for k in ['ascii','hAnsi','eastAsia','cs']:rf.set(qn('w:'+k),EN if latin else AR)
 for k,v in [('szCs',round(size*2)),('bCs','1' if bold else '0'),('rtl','1' if rtl else '0')]:
  old=pr.find(qn('w:'+k))
  if old is not None:pr.remove(old)
  pr.append(el('w:'+k,**{'w:val':v}))
 pr.append(el('w:lang',**{'w:val':'en-US' if latin else 'ar-KW','w:bidi':'ar-KW'}));return r

def field(p,key,value,size=11,bold=False):
 global CONTROL_ID
 latin=not bool(re.search(r'[\u0600-\u06ff]',value)) and any(c.isalnum() for c in value)
 if latin:para(p,rtl=False,align=WD_ALIGN_PARAGRAPH.RIGHT)
 r=run(p,value,size,bold,latin,not latin);p._p.remove(r._r)
 s=el('w:sdt');pr=el('w:sdtPr');CONTROL_ID+=1
 for tag,val in [('alias',key),('tag',key),('id',CONTROL_ID)]:pr.append(el('w:'+tag,**{'w:val':val}))
 pr.append(el('w:text'));s.append(pr);c=el('w:sdtContent');c.append(r._r);s.append(c);p._p.append(s)

def spacing(doc,points=3):
 p=para(doc.add_paragraph());p.paragraph_format.line_spacing=Pt(points);run(p,'',1);p.paragraph_format.line_spacing=Pt(points)

def image(p,path,w,h=None,name='photo'):
 para(p,rtl=False,align=WD_ALIGN_PARAGRAPH.CENTER)
 r=p.add_run();shape=r.add_picture(str(path),width=Mm(w),height=Mm(h) if h else None)
 for k in ['distL','distR','distT','distB']:shape._inline.set(k,'0')
 shape._inline.docPr.set('name',name);shape._inline.docPr.set('descr','Separate editable image object; Change Picture, then Crop > Fill.')
 if h:
  with Image.open(path) as im:iw,ih=im.size
  ia=iw/ih;fa=w/h
  if abs(ia-fa)>.00001:
   attrs={'l':(1-fa/ia)/2,'r':(1-fa/ia)/2} if ia>fa else {'t':(1-ia/fa)/2,'b':(1-ia/fa)/2}
   crop=el('a:srcRect')
   for k,v in attrs.items():crop.set(k,str(round(v*100000)))
   r._r.find('.//'+qn('pic:blipFill')).insert(1,crop)
 return shape

def link(p,url):
 u=urlparse(url)
 if u.scheme not in ('http','https') or not u.netloc:raise ValueError('Supply a confirmed HTTP(S) property location URL')
 rid=p.part.relate_to(url,RT.HYPERLINK,is_external=True)
 rr=run(p,'فتح الموقع الجغرافي',11);rr.font.underline=True;p._p.remove(rr._r);h=el('w:hyperlink',**{'r:id':rid});h.append(rr._r);p._p.append(h)

def setup_assets():
 ASSETS.mkdir(exist_ok=True,parents=True)
 svg=ASSETS/'Photo_Placeholder.svg';png=ASSETS/'Photo_Placeholder.png'
 svg.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="178mm" height="96mm" viewBox="0 0 178 96"><rect width="178" height="96" fill="#{MIST}"/><rect x=".25" y=".25" width="177.5" height="95.5" fill="none" stroke="#{INK}" stroke-width=".25" stroke-opacity=".2"/><path d="M85 48h8M89 44v8M6 12V6H12M166 6h6v6M6 84v6h6M166 90h6v-6" fill="none" stroke="#{INK}" stroke-width=".4"/></svg>')
 subprocess.run(['inkscape',str(svg),'--export-filename='+str(png),'--export-width=1780'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)

def build(data=None,out=None):
 data=data or {};setup_assets();d=Document();sec=d.sections[0]
 sec.page_width=Mm(210);sec.page_height=Mm(297);sec.left_margin=sec.right_margin=Mm(16);sec.top_margin=Mm(38);sec.bottom_margin=Mm(16);sec.header_distance=Mm(12);sec.footer_distance=Mm(10)
 for name in ['Normal','Title','Heading 1','Caption']:
  st=d.styles[name];st.font.name=AR;st.font.color.rgb=RGBColor.from_string(INK);st.font.size=Pt(11)
  pr=st.element.get_or_add_rPr();rf=pr.get_or_add_rFonts()
  for k in list(rf.attrib):
   if 'theme' in k.lower():del rf.attrib[k]
  for k in ['ascii','hAnsi','eastAsia','cs']:rf.set(qn('w:'+k),AR)
  for x in st.element.findall('.//'+qn('w:pBdr'))+st.element.findall('.//'+qn('w:rPr')+'/'+qn('w:spacing')):x.getparent().remove(x)
 h=sec.header.paragraphs[0];para(h,rtl=False,align=WD_ALIGN_PARAGRAPH.RIGHT)
 r=h.add_run();sh=r.add_picture(str(ASSETS/'AlDayel_Primary_Ink_2400.png'),width=Mm(50))
 for k in ['distL','distR','distT','distB']:sh._inline.set(k,'0')
 sh._inline.docPr.set('name','original_logo');sh._inline.docPr.set('descr','Original approved AlDayel logo; geometry unchanged.')
 f=sec.footer.paragraphs[0];para(f,rtl=False,align=WD_ALIGN_PARAGRAPH.LEFT);run(f,'ALDAYEL',7.5,latin=True,rtl=False)
 title=para(d.add_paragraph(),after=5);title.style=d.styles['Title'];field(title,'ad_title',str(data.get('ad_title','عرض عقار للبيع')),18,True)
 labels=[('نوع العرض','offer_type','للبيع'),('نوع العقار','property_type','[نوع العقار]'),('التصنيف','classification','[التصنيف]'),('النشاط','activity','[النشاط]'),('العنوان','address','[العنوان]'),('المساحة','area_measurement',str(data.get('area','[المساحة]'))+' '+str(data.get('area_unit','[وحدة القياس]'))),('السعر','price_currency',str(data.get('price','[السعر]'))+' '+str(data.get('currency','[العملة]'))),('رقم التواصل','contact','[رقم التواصل]'),('الموقع الجغرافي','location_url','[رابط الموقع الجغرافي]')]
 t=d.add_table(rows=len(labels),cols=2);t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False;t.columns[0].width=Mm(35);t.columns[1].width=Mm(143)
 tp=t._tbl.tblPr;tp.append(el('w:bidiVisual',**{'w:val':'1'}));tp.append(el('w:tblLayout',**{'w:type':'fixed'}));tp.append(el('w:tblInd',**{'w:w':'0','w:type':'dxa'}))
 for row,(label,key,default) in zip(t.rows,labels):
  row._tr.get_or_add_trPr().append(el('w:cantSplit'))
  for j,c in enumerate(row.cells):
   c.width=Mm(35 if j==0 else 143);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER;pr=c._tc.get_or_add_tcPr();m=el('w:tcMar')
   for side in ['top','bottom','left','right']:m.append(el('w:'+side,**{'w:w':str(50 if side in ['top','bottom'] else (0 if side=='right' else 80)),'w:type':'dxa'}))
   pr.append(m);b=el('w:tcBorders')
   for side in ['top','left','bottom','right']:b.append(el('w:'+side,**{'w:val':'single' if side=='bottom' else 'nil','w:sz':'3','w:color':MIST}))
   pr.append(b)
  p=para(row.cells[0].paragraphs[0]);run(p,label,10,True)
  p=para(row.cells[1].paragraphs[0]);value=str(data.get(key,default))
  if key=='location_url' and data.get(key):link(p,value)
  else:field(p,key,value,11.5 if key in ['area_measurement','price_currency','contact'] else 11,bold=key in ['area_measurement','price_currency'])
 spacing(d,5)
 p=para(d.add_paragraph(),after=1);run(p,'المواصفات',10.5,True)
 for i,s in enumerate(data.get('specifications') or ['[المواصفة الأولى]','[المواصفة الثانية]','[المواصفة الثالثة]'],1):
  p=para(d.add_paragraph());run(p,'•  ',10.5);field(p,'specification_'+str(i),str(s),10.5)
 p=para(d.add_paragraph(),before=3,after=2);run(p,'صورة العقار',10.5,True)
 p=d.add_paragraph();image(p,Path(data.get('photo',ASSETS/'Photo_Placeholder.png')),178,96,'property_photo')
 d.core_properties.title='الدايل نموذج عرض عقار للبيع';d.core_properties.subject='Editable A4 property template';d.core_properties.author='AlDayel';d.core_properties.keywords='AlDayel, property, RTL, editable'
 d.core_properties.comments='Native text controls and one independently replaceable property photograph. Unconfirmed information remains empty placeholders.'
 target=Path(out or ROOT/'02_PROPERTY_SHEET/AlDayel_Property_Sale.docx');target.parent.mkdir(exist_ok=True,parents=True);d.save(target);return target

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--data',type=Path);ap.add_argument('--output',type=Path);a=ap.parse_args();print(build(json.loads(a.data.read_text()) if a.data else None,a.output))
