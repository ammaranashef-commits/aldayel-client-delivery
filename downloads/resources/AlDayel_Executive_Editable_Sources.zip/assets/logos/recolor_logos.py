#!/usr/bin/env python3
"""Create color-only derivatives from original logo paths and verify geometry.
Usage: python recolor_logos.py --hex '#193F46' --name deep-teal
No geometry, transforms, glyph shapes, source proportions or source letterforms change.
"""
from pathlib import Path
import argparse,hashlib,json,re,xml.etree.ElementTree as ET
import fitz
BASE=Path(__file__).resolve().parent
ET.register_namespace('','http://www.w3.org/2000/svg');ET.register_namespace('xlink','http://www.w3.org/1999/xlink');ET.register_namespace('inkscape','http://www.inkscape.org/namespaces/inkscape')
def geom(root):
 return [{'tag':e.tag.split('}')[-1],**{k:v for k,v in sorted(e.attrib.items()) if k not in ('fill','stroke','class','style')}} for e in root.iter() if e.tag.split('}')[-1] in ('path','use')]
def digest(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def run(color,name):
 assert re.fullmatch(r'#[0-9A-Fa-f]{6}',color), 'Use a six-digit HEX color'
 assert re.fullmatch(r'[a-z0-9-]+',name), 'Use an ASCII lower-case color filename'
 dst=BASE/'residential'/name;dst.mkdir(parents=True,exist_ok=True)
 report=[]
 for item in json.loads((BASE/'original'/'provenance.json').read_text()):
  src=BASE/'original'/item['svg_file'];root=ET.parse(src).getroot();before=geom(root)
  for e in root.iter():
   if e.get('fill')=='#231f20':e.set('fill',color)
  after=geom(root);assert before==after and digest(after)==item['geometry_sha256']
  out=dst/f'aldayel-{item["variant"]}-{name}.svg';out.write_bytes(ET.tostring(root,encoding='utf-8',xml_declaration=True))
  assert digest(geom(ET.parse(out).getroot()))==item['geometry_sha256']
  svg=fitz.open(out);pdf=fitz.open(stream=svg.convert_to_pdf(),filetype='pdf');pdf.save(out.with_suffix('.pdf'))
  scale=1600/max(pdf[0].rect.width,pdf[0].rect.height);pdf[0].get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=True).save(out.with_suffix('.png'))
  report.append({'file':str(out.relative_to(BASE)),'hex':color,'geometry_sha256':digest(after),'source_geometry_sha256':item['geometry_sha256'],'geometry_unchanged':True})
 (dst/'recolor-validation.json').write_text(json.dumps(report,indent=2))
 return report
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--hex',required=True);p.add_argument('--name',required=True);a=p.parse_args();print(json.dumps(run(a.hex,a.name),indent=2))
