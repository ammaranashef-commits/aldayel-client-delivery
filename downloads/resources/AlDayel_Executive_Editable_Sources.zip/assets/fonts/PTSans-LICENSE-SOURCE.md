# PT Sans license provenance

## Scope

These four supplied PT Sans fonts retain their original, unmodified binaries. Their embedded name table states:

> Copyright © 2009 ParaType Ltd. All rights reserved.

> ParaType Ltd grants you the right to use, copy, modify this font and distribute modified and unmodified copies of the font by any means, including placing on Web servers for free downloading, embedding in documents and Web pages, bundling with commercial and non commercial products, if it does not conflict with the ParaType Free Font License placed on www.paratype.com/public/pt_openlicense_eng.asp.

Their nameID 14 is `http://www.paratype.com/public/pt_openlicense_eng.asp`.

## Sources and access status

Retrieved 2026-10-19. Exact UTC retrieval time, font identities and SHA-256 values are recorded in `license-evidence/PTSans-license-provenance.json`.

- Original official URL: http://www.paratype.com/public/pt_openlicense_eng.asp . HTTP and HTTPS requests now redirect to https://www.paratype.com/eula (HTTP 200), returning a generic JavaScript application shell rather than the historical license text. The shell is saved as evidence. The historical official license was **not recovered directly from ParaType**.
- Official alternate: https://www.paratype.ru/public/pt_openlicense_eng.asp returned HTTP 503. This endpoint did not supply a usable license.
- Preserved third-party mirror: https://www.fontsquirrel.com/license/PT-Sans (HTTP 200), explicitly headed **Paratype PT Sans Free Font License**, with copyright 2009 ParaType Ltd. and reserved names PT Sans / ParaType. This is the license block, excluding page navigation.
- Font Squirrel distribution: https://www.fontsquirrel.com/fonts/download/pt-sans (HTTP 200), ZIP member `Paratype PT Sans Free Font License.txt`. That verbatim member is saved in `license-evidence/PTSans-LICENSE.mirror-original.txt`. The page HTML is saved alongside it.

The mirror ZIP contains ParaType PT Sans version 2.005, while the user's supplied files identify as 13.0d3e2. The mirror fonts and supplied fonts have **identical copyright, license-description and license-URL metadata (nameIDs 0, 13, 14)**. This corroborates the ParaType Free Font License identity; it does not prove binary equivalence or direct recovery from the original publisher. Mirror font binaries were not copied into the deliverable.

## Included notice

`PTSans-LICENSE.txt` contains the entire mirrored license text. The mirror has doubled HTML entities; only those entities have been decoded for readability and a final newline added. No license clause is rewritten or omitted. The raw original is retained for byte-level verification.

The license requires distribution of the copyright notice and license with the font software. It permits use, embedding, copying and redistribution subject to its conditions. No SIL Open Font License has been substituted: the supplied fonts explicitly identify the ParaType Free Font License, and the Google Fonts 2010 OFL notice corresponds to a different release.

Direct publication-source verification of the historical license remains unavailable because the legacy official endpoint no longer returns that text. This limitation is retained rather than silently treating a mirror as a direct official source.
