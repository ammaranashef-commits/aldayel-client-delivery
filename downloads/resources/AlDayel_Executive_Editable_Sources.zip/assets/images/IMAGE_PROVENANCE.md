# Architectural imagery provenance

Both images were created specifically for this identity guide with OpenAI image generation on 19 October 2026. They are original conceptual scenes and **do not depict or document actual AlDayel properties, completed projects, or available inventory**.

Suggested Arabic caption/disclosure: «مشهد تصوّري مولّد لشرح التوجّه البصري؛ لا يمثّل مشروعًا فعليًا للدايل.»

| File | Format and size | Subject |
| --- | --- | --- |
| concept_residential_exterior.png | RGB PNG, 1536 × 1024 px, landscape 3:2 | Contemporary Gulf residential courtyard exterior, pale limestone, restrained planting, morning light. |
| concept_residential_interior.png | RGB PNG, 1536 × 1024 px, landscape 3:2 | Contemporary residential living room with linen, stone, warm timber and planted courtyard. |

Visual review completed: both images have no people, readable text, signage, logos, or watermarks. The actual AlDayel logo was never supplied to the image generator. No image editing or synthetic brand mark generation was performed.

These 1536 × 1024 px assets are suitable for screen proofs and medium-size editorial placements. At 300 ppi, native reproduction is approximately 130 × 87 mm; larger placements have a lower effective resolution and should be evaluated at final print size. Do not represent these files as supplied photography of the brand's real property portfolio.
