# Executive architecture plates

Three new conceptual images generated specifically for the AlDayel Residential executive brand book on 19 October 2026 using OpenAI image generation. They do **not** document actual AlDayel properties, projects or inventory. No original logo was given to the generator. All three are text-free, brand-free images. Any visible AlDayel mark must be added separately in the editable layout from the approved vector assets.

## Native resolution

Each original is **1122 × 1402 px**, portrait approximately 4:5. The tool returned this native size despite the brief requesting higher resolution. At 240 × 300 mm full-page reproduction, effective resolution is **118.7 ppi**. There has been no resampling, sharpening or pixel editing. These are strong screen-first editorial plates; a collector-edition print run needs an actual-size proof and printer acceptance or replacement with commissioned high-resolution photography. Merely exporting the PDF/previews at 300 dpi does not improve the source photographs.

## Visual review and placement

### concept-entrance-portrait.png

Credible front-on limestone villa entrance, vertical window reveals, recessed dark timber door, restrained arid planting, single coherent side-light, normal domestic scale. Entire frame inspected at native dimensions. No floating structural elements, malformed window lines, generated text or unrelated logo found. Frontal plaque is a useful intentional application surface.

- Natural full-page crop: keep the entire 4:5 frame. A centered cover fit requires negligible clipping.
- Blank blue plaque approximate inner bounds: **x = 638–756; y = 804–849 px**. The outer shadow extends beyond this and must remain unobstructed.
- Use the true logo as a flat frontal vector application, centered within the inner plaque with appropriate clear space. Do not perspective-transform, distort, redraw or generate the logo. Keep the artificial sun shadow outside the plaque intact.
- A severe vertical crop would remove the planting and pavement that establish scale. Avoid stretching.

### concept-courtyard-portrait.png

Architectural narrative through a shaded colonnade, a believable stone pier and beam system, sunlit olive tree courtyard, coherent wall and floor joints. Natural surface and foliage variation. Inspected native image individually; no obvious perspective/structural defect, text or unwanted brand. The scene is compositionally distinct from the entrance and interior.

- Preferred crop: full image. Broad shaded left pier is deliberate foreground framing; the bright center provides depth. Do not overcrop the left pillar or bottom ground plane.
- Good for an independent architectural plate or paired with a quiet pearl text page. Do not split the olive tree trunk across the binding.
- Keep editorial text outside the scene where possible; the photo's dappled lighting makes overprinted text less legible.

### concept-interior-portrait.png

Warm residential living room seen from a doorway, natural woven linen and rug, plausible armchair legs/table support/window mullions, soft side-light, gently uneven cushions and throw. No generated lettering, logos or implausible reflections detected. Slight domestic imperfection keeps the scene from feeling like a symmetrical product catalogue.

- Preferred crop: full image. A modest top/bottom trim is safe; protect the near chair legs and foreground doorway to retain depth.
- Suitable for a full-width image at approximately 190 × 237 mm or a smaller editorial inset; around 149.8 ppi at 190 mm width.
- All book and cup surfaces are blank/unbranded. No company facts should be inferred from this scene.

The originals remain in `/workspace/generated_images/`; precise source paths, checksums and native dimensions are in `provenance.json`. Original creative briefs are in `generation-prompts.json`.


### concept-cover-detail-portrait.png

Fourth independent composition reserved for cover: a close limestone colonnade and doorway detail with quiet diagonal light, subtle blue sky sliver and a small olive foreground branch. No full building, plaque or repeated view. Inspected at native dimensions; coherent wall depth, credible soffit, straight stone joints, no text/logo or obvious deformation. Keep entire4:5 frame; restrained145×180mmplacement has196.6ppi effective resolution. No pixel edits or upsampling. Copied to new executive delivery assets/images.
