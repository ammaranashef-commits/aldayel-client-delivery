"""Render actual exported PDF pages and physically correct RTL spread proofs.
Pillow is used only to assemble PDF proof sheets, never to retouch image assets.
"""
from pathlib import Path
import argparse,json
import fitz
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--dpi',type=int,default=200);a=p.parse_args()
pdf=fitz.open(ROOT/'AlDayel_Residential_Brand_Book_EXECUTIVE_20P.pdf');assert len(pdf)==20
out=ROOT/'previews';(out/'pages').mkdir(exist_ok=True,parents=True);(out/'spreads').mkdir(exist_ok=True,parents=True)
thumbs=[]
for n,pg in enumerate(pdf,1):
    pix=pg.get_pixmap(matrix=fitz.Matrix(a.dpi/72,a.dpi/72),alpha=False)
    pix.save(out/f'pages/page-{n:02d}.png')
    im=Image.open(out/f'pages/page-{n:02d}.png').convert('RGB');im.thumbnail((360,450));thumbs.append(im.copy())
font=ImageFont.truetype(str(ROOT/'assets/fonts/PTSans-Regular.ttf'),22)
# Logical page contact sheet: each row reads right-to-left.
contact=Image.new('RGB',(5*390+30,4*505+30),'#d9d9d6');d=ImageDraw.Draw(contact)
for n,im in enumerate(thumbs):
    col=4-(n%5);row=n//5;x=30+col*390;y=30+row*505;contact.paste(im,(x,y));d.text((x+5,y+457),f'{n+1:02d}',font=font,fill='#1C3549')
contact.save(out/'AlDayel_Executive_20P_Contact_Sheet.jpg',quality=95)
spreadmap=[]
for even in range(2,20,2):
    left=Image.open(out/f'pages/page-{even+1:02d}.png').convert('RGB');right=Image.open(out/f'pages/page-{even:02d}.png').convert('RGB')
    w,h=left.size;spread=Image.new('RGB',(w*2+4,h),'#ada9a4');spread.paste(left,(0,0));spread.paste(right,(w+4,0));name=f'spread-{even:02d}-{even+1:02d}-RTL.jpg';spread.save(out/'spreads'/name,quality=94)
    spreadmap.append({'right_page':even,'left_page':even+1,'file':name})
(out/'spread-order.json').write_text(json.dumps({'binding':'right','covers':[1,20],'spreads':spreadmap},indent=2))
print(f'Rendered20 pages at{a.dpi}dpi and9 RTL spreads')
