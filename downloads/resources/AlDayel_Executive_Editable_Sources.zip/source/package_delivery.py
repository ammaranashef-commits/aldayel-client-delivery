"""Package editable sources and produce exact delivery-file checksums."""
from pathlib import Path
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent.parent
EXCLUDED={'__pycache__','.DS_Store'}
def eligible(p):return p.is_file() and not any(x in EXCLUDED for x in p.parts) and p.suffix not in ('.pyc','.blend1')
def archive_eligible(p):
    # Keep all editable inputs and assets. Rebuildable HTML/PDF exports remain
    # in the repository but need not be duplicated in the source-only ZIP.
    rel=p.relative_to(ROOT)
    return eligible(p) and str(rel) not in ('source/executive.html','source/validation.html') and not (rel.parts[0]=='applications' and p.suffix=='.pdf')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
archive=ROOT/'AlDayel_Executive_20P_Editable_Sources.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for folder in ['source','assets','applications','motion','references','quality']:
        for p in sorted((ROOT/folder).rglob('*')):
            if archive_eligible(p):z.write(p,str(p.relative_to(ROOT)))
    z.writestr('READ_ME_FIRST.txt','AlDayel Residential — Executive20P editable source package.\nStart with source/README-executive.ar.md.\nThe commercial Arabic font binaries are intentionally not redistributed. Install the licensed originals and set ALDAYEL_FONT_DIR.\nGenerated book/report HTML and application PDF exports are omitted from this source ZIP; editable code, SVG inputs, textures and all used assets are included. All exports are also available separately in the repository.\nBuild the main PDF before rebuilding its validation report. To run the full preservation validator, also download the separately delivered full PREMIUM_FINAL guide into the package root.\n')
assert archive.stat().st_size<100_000_000,'Archive exceeds the single-file repository budget; split sources before publishing.'
files=[]
for p in sorted(ROOT.rglob('*')):
    if eligible(p) and p.name not in ('SHA256SUMS.txt','DELIVERY_MANIFEST.json'):
        files.append({'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)})
manifest={'edition':'AlDayel Residential / Executive20P','main_pdf':'AlDayel_Residential_Brand_Book_EXECUTIVE_20P.pdf','page_count':20,'trim_mm':[240,300],'binding':'right','full_guide_preserved':True,'files':files}
(ROOT/'DELIVERY_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(ROOT/'SHA256SUMS.txt').write_text('\n'.join(f"{x['sha256']}  {x['path']}" for x in files)+'\n')
print(json.dumps({'files':len(files),'source_zip_bytes':archive.stat().st_size,'total_bytes':sum(x['bytes'] for x in files)}))
