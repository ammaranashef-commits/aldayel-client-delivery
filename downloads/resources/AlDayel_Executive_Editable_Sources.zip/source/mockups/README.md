# AlDayel Residential — physical concept renders

These are **conceptual applications**, not printer-ready production files or manufacturing specifications.

## What is original

The logo print texture embeds the supplied `aldayel-primary-ar` SVG geometry, including its original inherited Arabic descriptor, without redrawing or replacing any part. Residential identification (`السكني`) is a separate typographic line outside the original logo. Its shaping uses the supplied Helvetica Neue LT Arabic Roman font.

The architecture frame motif, materials, lighting, object arrangements, and 3D objects are newly constructed for this residential direction. All scenes are procedural Blender scenes. No AI image generation or external stock mockup was used for these renders.

## Deliverables

- `mockup_stationery.blend`: A4 letterhead, envelope, thick business cards, copper pen, stone surface.
- `mockup_packaging.blend`: paper shopping bag, paper handles, rigid presentation box, welcome card.
- `mockup_cups.blend`: close-up pearl and ink takeaway cups plus an enlarged branded card detail.
- `mockup_packaging_welcome.blend`: alternate welcome-set camera, for a distinct closing application spread.
- `textures/*.svg`: editable print-surface layouts with embedded original SVG logos.
- `textures/outlined/*.svg`: matching layouts with the separate residential label converted to paths for font-independent reproduction.
- `textures/*.png`: rasterized print textures, also packed into each `.blend` for portability.
- `render_mockups.py`: procedural source for all three scenes; Blender 4.3.2.
- `build_textures.py`: SVG layout and rasterization source; requires Inkscape and the supplied Arabic font.
- Final 2400 × 1500 px renders: `../../assets/images/mockup_stationery.png`, `../../assets/images/mockup_packaging.png`, `../../assets/images/mockup_cups.png`, and `../../assets/images/mockup_packaging_welcome.png`.

## Premium refinement

All original SVG, outlined SVG, and PNG print textures remain byte-identical to the previous final delivery. The paper, ink and copper surface colours are unchanged. Lighting-dependent appearance in a render is separate from the authoritative flat colour specification.

The premium scenes replace the orthographic camera with a 70 mm perspective lens, soften the daylight and retain tonal detail in light stock. The letterhead now fits inside the frame. Fine paper bump replaces the coarser surface treatment. Unnecessary stone decoration was removed from the stationery scene. Bag side walls are real inward-folded gussets; its handle eyelets are quieter and the ribbon wraps continuously. Cup lids have recessed centres, stepped molded edges and real through-cut drinking/vent apertures rather than dark surface dots. Original planar textures fit their native aspect ratios, removing small geometric compression caused by the old edge offsets.

Native Cycles denoising uses the original albedo and normal passes to suppress Monte Carlo grain without inventing or redrawing any print artwork. These are still deliberately constructed 3D application concepts, not photographs of manufactured products.

## Regeneration

The `.blend` scenes are fully packed and can be rendered directly without rebuilding their textures.

```bash
blender -b mockup_stationery.blend -t 3 -o /tmp/stationery -F PNG -f 1
blender -b mockup_packaging.blend -t 3 -o /tmp/packaging -F PNG -f 1
blender -b mockup_cups.blend -t 3 -o /tmp/cups -F PNG -f 1
blender -b mockup_packaging_welcome.blend -t 3 -o /tmp/welcome -F PNG -f 1
```

To rebuild all procedural objects and render all three scenes from source:

```bash
blender -b -t 3 -P render_mockups.py
blender -b -t 3 -P render_mockups.py -- welcome
```

If changing a print layout, regenerate its textures first with `ALDAYEL_FONT_DIR=/path/to/supplied/fonts python build_textures.py`. The directory must contain the original Helvetica Neue LT Arabic Roman font. Existing `.blend` files and `textures/outlined` variants do not require that font to display.

Use the official Blender 4.3.2 build (or a compatible newer build) with OpenImageDenoise support. The final source uses 96 Cycles samples for stationery/welcome and 64 for packaging/cups, 2400 × 1500 output, accurate albedo/normal-guided denoising, and three CPU threads. Some distribution Blender builds omit the denoiser; the script falls back to a raw render in those builds. For a clean output use an official build, or increase samples substantially. Optional environment overrides are `ALDAYEL_RENDER_WIDTH`, `ALDAYEL_SAMPLES`, `ALDAYEL_RENDER_THREADS`, and `ALDAYEL_OUTPUT_DIR`. The authoritative flat palette remains `assets/design-tokens.json`.

The 90 × 54 mm stationery cards carry a 45 mm primary mark. The closer detail card uses a 63 mm primary mark, and the cup marks are approximately 52 mm wide at the scene's nominal scale. All refer to the full original logo, with a separate residential line. In a photograph, projected logo pixel sizes depend on the camera framing; these are not standalone digital logo placements.

Do not infer final paper stock, dimensions, ink separation, foil behavior, trim tolerances, bag capacity, or structural suitability from these concept renders. Final print artwork and fabrication specifications require a supplier-specific production pass.
