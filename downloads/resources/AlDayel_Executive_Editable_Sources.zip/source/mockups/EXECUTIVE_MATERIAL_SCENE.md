# Executive material study

This portrait still life is a newly composed Blender scene for the 20-page executive edition. It combines the approved shopping bag, rigid presentation box, paper cup, two die-cut stickers and welcome card. The bag is modeled with folded side gussets and cord handles; the cup has a closed molded lid with actual through-cut drinking and ventilation openings.

Branding is drawn from the existing vector-origin print textures in `textures/`. The die-cut sticker artwork is rasterized directly from `../../applications/stickers.svg` at 3,600 pixels wide and UV-mapped to the original circular boundaries. No logo geometry or letterform is reconstructed. Print perspective and cup curvature result from 3D geometry. There is no post-render raster retouching.

## Rebuild

```bash
ALDAYEL_EXEC_WIDTH=3200 ALDAYEL_EXEC_SAMPLES=64 \
blender -b -t 4 -P executive_material_scene.py
```

The generator finds the delivery root relative to its own directory. It imports the approved shared functions in `render_mockups.py`. Inkscape is needed only to regenerate `textures/executive_stickers.png`; the packed `.blend` can render independently from the generator without Inkscape. Blender 4.3.2 with OpenImageDenoise was used for the delivered render.

The master `.blend` packs all five print textures. The output is native 3,200 × 4,000 pixels, approximately 387 ppi at 210 mm wide and 339 ppi at 240 mm wide. This is a concept visualization. Manufacturing dielines, physical stock, coatings, final dimensions and tolerances require the print supplier's production specifications.

## Editorial use

The portrait composition leaves a calm upper field and grounds the objects in the lower two thirds. It is intended to be used once as the material-experience plate on page 19. Keep the aspect ratio; do not stretch. If cropped, check both bag handles, the cup foot and the rigid-box corners. Avoid putting captions over printed logos.
