"""AlDayel Executive — original-vector material still life.

Run with official Blender 4.3+: blender -b -t 4 -P executive_material_scene.py
Preview: ALDAYEL_EXEC_WIDTH=1000 ALDAYEL_EXEC_SAMPLES=24 blender ...
Final: 3200 x 4000 native pixels, physically modelled studio objects.
All branding comes from the approved source textures and stickers.svg.
No raster image retouching, generated logos, or synthetic type.
"""
from pathlib import Path
import bpy, importlib.util, os, sys, math, subprocess, json, hashlib
from mathutils import Vector

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
WIDTH = int(os.environ.get('ALDAYEL_EXEC_WIDTH', '3200'))
SAMPLES = int(os.environ.get('ALDAYEL_EXEC_SAMPLES', '64'))
OUT = Path(os.environ.get('ALDAYEL_EXEC_OUTPUT', str(ROOT/'assets/images/executive-material-scene.png')))
# Import the audited shared geometry library without running its four scenes.
old_argv = sys.argv[:]
sys.argv = ['render_mockups.py', '--', 'executive-library']
spec = importlib.util.spec_from_file_location('approved_mockups', HERE/'render_mockups.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
sys.argv = old_argv
m.save_render = lambda name: None
m.packaging(welcome=False)
scene = bpy.context.scene
# Ground all modeled objects on z=0 rather than retaining the older study's
# small display offsets. Also separate the box's back-left corner from the bag.
bpy.data.objects['Limestone studio surface'].location.z += .015
for ob in bpy.data.objects:
    if ob.name.startswith(('Rigid presentation box', 'Presentation lid exact-logo print', 'Ribbon ')):
        ob.location.x += .10
scene.render.resolution_x=WIDTH;scene.render.resolution_y=round(WIDTH*1.25)
scene.cycles.samples=SAMPLES
scene.cycles.adaptive_min_samples=min(32,SAMPLES)
scene.cycles.adaptive_threshold=.006 if WIDTH>=2800 else .025
scene.render.threads=int(os.environ.get('ALDAYEL_EXEC_THREADS','4'))
# Use the calm physical material scheme of the approved scenes, with a
# slightly more directional window to reveal manufactured paper edges.
for name in ['Quiet neutral bounce','Gentle rear separation']:
    bpy.data.objects[name].data.energy = 110 if 'bounce' in name else 100
key=bpy.data.objects['Broad daylight window'];key.data.size=5.5;key.data.energy=1100
key.location=(-4.5,-4.2,8)
key.rotation_euler=(Vector((0,0,1.5))-key.location).to_track_quat('-Z','Y').to_euler()
scene.view_settings.exposure=-.75
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.7
bpy.data.materials['Fine limestone studio surface'].node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=m.rgba('#E8E3D8')
# Keep the approved bag and box; reposition the small welcome card so that
# its edge is actually supported by the surface and it reads in the foreground.
for name in ['Welcome card','Welcome card exact-logo print']:
    ob=bpy.data.objects[name];ob.location.x=-2.0;ob.location.y=-2.1;ob.rotation_euler.z=math.radians(-8);ob.location.z-=.0135
# One paper cup at a coherent physical scale, with an actual through-cut drinking aperture.
# Original cup study used 40 mm per scene unit; this scene uses 100 mm/unit.
existing=set(bpy.data.objects)
lid=m.material('Executive matte pearl molded lid','#F4F3EF',.72,noise=.0004)
dark=m.material('Executive deep lid openings','#202830',.95)
m.cup_body('Executive pearl cup',0,0,'cup_pearl')
m.cup_lid('Executive pearl cup lid',0,0,lid,dark)
m.torus('Executive cup rolled foot',(0,0,.075),.72,.022,bpy.data.materials['Warm uncoated cotton paper'])
for ob in set(bpy.data.objects)-existing:
    # Geometry is already in local coordinates around the world origin.
    ob.scale=(.50,.50,.50)
    ob.location.x=ob.location.x*.50-.15
    ob.location.y=ob.location.y*.50-3.02
    ob.location.z=ob.location.z*.50-.0265
    # Rotate the UV-mapped body print to face the camera, uniformly with cup.
    if ob.name=='Executive pearl cup':ob.rotation_euler.z=math.radians(1)
# Render original all-vector approved sticker artwork as a source texture.
# This is vector rasterization, not photo editing. UV cutouts below use the
# exact circles in that source sheet and leave their paths unmodified.
sticker_source=ROOT/'applications/stickers.svg'
sticker_texture=HERE/'textures/executive_stickers.png'
if not sticker_texture.exists():
    subprocess.run(['inkscape',str(sticker_source),'--export-width=3600',f'--export-filename={sticker_texture}'],check=True,stdout=subprocess.DEVNULL)
sm=m.material('Approved sticker artwork — exact SVG paths','#FFFFFF',.88,noise=.0004)
sp=sm.node_tree.nodes.get('Principled BSDF')
t=sm.node_tree.nodes.new('ShaderNodeTexImage');t.image=bpy.data.images.load(str(sticker_texture));t.interpolation='Linear'
sm.node_tree.links.new(t.outputs['Color'],sp.inputs['Base Color'])
# 145 x 80 mm release liner with two die-cut labels, placed at the front left.
# The labels retain the 58 mm diameter of the approved source sample.
pearl=bpy.data.materials['Warm uncoated cotton paper']
sx,sy=-2.60,-1.05;ang=math.radians(-11)
def tr(x,y,z):return (sx+math.cos(ang)*x-math.sin(ang)*y,sy+math.sin(ang)*x+math.cos(ang)*y,z)
m.box('Sticker release liner',tr(0,0,.009),(1.46,.79,.018),pearl,.006,-11)
# Original centers: (36,38) and (104,38), original radius 29, SVG 180 x 110.
for idx,(dx,cx) in enumerate([(-.35,36),(.35,104)]):
    x,y,z=tr(dx,0,.021)
    bpy.ops.mesh.primitive_cylinder_add(vertices=128,radius=.29,depth=.003,location=(x,y,z))
    edge=bpy.context.object;edge.name=f'Die-cut label {idx+1} edge';edge.data.materials.append(pearl)
    verts=[(0,0,0)]+[(.29*math.cos(2*math.pi*i/128),.29*math.sin(2*math.pi*i/128),0) for i in range(128)]
    faces=[(0,i+1,(i+1)%128+1) for i in range(128)]
    me=bpy.data.meshes.new(f'Approved die-cut label {idx+1}');me.from_pydata(verts,[],faces);me.update()
    ob=bpy.data.objects.new(f'Approved die-cut label {idx+1} print',me);bpy.context.collection.objects.link(ob)
    ob.location=(x,y,z+.0016);ob.rotation_euler.z=ang
    uv=me.uv_layers.new(name='Exact source SVG circular crop')
    for poly in me.polygons:
        for li in poly.loop_indices:
            v=me.vertices[me.loops[li].vertex_index].co
            uv.data[li].uv=((cx+v.x*100)/180,1-(38-v.y*100)/110)
    me.materials.append(sm)
# Remove the old landscape camera and build a real long-lens portrait framing.
for ob in list(bpy.data.objects):
    if ob.type=='CAMERA':bpy.data.objects.remove(ob,do_unlink=True)
cam=m.camera((5,-13,8),(-.2,-.40,1.9),8.8)
cam.data.lens=70
# Sensor fit horizontal keeps the portrait width explicit and predictable.
cam.data.sensor_fit='HORIZONTAL'
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB'
scene.render.filepath=str(OUT)
OUT.parent.mkdir(parents=True,exist_ok=True)
scene['design_provenance']='Original AlDayel vector artwork mapped to physical paper geometry. Concept still life, not manufactured products.'
scene['native_resolution']=f'{WIDTH} x {round(WIDTH*1.25)}'
# Pack textures and keep a portable master beside this generator.
bpy.ops.file.make_paths_relative();bpy.ops.file.pack_all()
if OUT.is_relative_to(ROOT):
    scene.render.filepath='//../../'+str(OUT.relative_to(ROOT))
bpy.ops.wm.save_as_mainfile(filepath=str(HERE/'executive_material_scene.blend'))
bpy.ops.render.render(write_still=True)
notes={
 'asset':str(OUT.relative_to(ROOT)) if OUT.is_relative_to(ROOT) else str(OUT),
 'native_pixels':[WIDTH,round(WIDTH*1.25)],
 'method':'Blender Cycles path-traced physically modelled studio still life; exact approved vector-origin print textures; no post-render raster editing.',
 'effective_ppi_at_210mm_width':round(WIDTH/(210/25.4),2),
 'effective_ppi_at_240mm_width':round(WIDTH/(240/25.4),2),
 'objects':['Folded paper shopping bag with cord handles','Rigid presentation box with fitted lid','Molded-lid paper cup','Two original die-cut label designs on release liner','Original-logo welcome card'],
 'source_logo_geometry':'Unmodified approved paths, uniformly mapped within the original texture aspect ratios; natural perspective on physical surfaces.',
 'source_textures':[str((HERE/'textures'/f'{n}.png').relative_to(ROOT)) for n in ['bag','box','card_ink','cup_pearl','executive_stickers']],
 'sticker_source_sha256':hashlib.sha256(sticker_source.read_bytes()).hexdigest(),
 'concept_only':True,
 'render_samples':SAMPLES,
 'ground_contact':'Limestone upper face z=0; cup rolled foot, bag and box bottom at z=0; release liner and card bottom at z=0; box separated from bag by positive clearance.',
 'remaining_limitations':['Visual concept; actual dielines, stock, coatings and manufacturing tolerances require supplier production approval.']
}
(HERE/'executive_material_scene_notes.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2))
print('EXECUTIVE MATERIAL SCENE COMPLETE:',OUT)
