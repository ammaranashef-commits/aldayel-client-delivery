"""Verify portable, packed mockup scenes. Run inside Blender, without rendering."""
from pathlib import Path
import bpy, json
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view

HERE=Path(__file__).resolve().parent
records=[]
bpy.context.preferences.filepaths.save_version=0
for name in ['mockup_stationery','mockup_packaging','mockup_cups','mockup_packaging_welcome']:
    p=HERE/f'{name}.blend'
    if not p.exists():
        records.append({'scene':p.name,'exists':False})
        continue
    bpy.ops.wm.open_mainfile(filepath=str(p))
    bpy.context.scene.render.filepath=f'//../../assets/images/{name}.png'
    bpy.ops.file.make_paths_relative()
    bpy.ops.file.pack_all()
    images=[]
    for im in bpy.data.images:
        if im.type=='IMAGE' and im.source=='FILE':
            images.append({'name':im.name,'filepath':im.filepath,'relative':im.filepath.startswith('//'),'packed':bool(im.packed_file),'pixels':list(im.size)})
    assert all(i['relative'] and i['packed'] for i in images), images
    s=bpy.context.scene
    projected=[]
    for ob in s.objects:
        if ob.type not in ['MESH','CURVE'] or ob.name=='Limestone studio surface':continue
        pts=[world_to_camera_view(s,s.camera,ob.matrix_world@Vector(v)) for v in ob.bound_box]
        bounds=[min(p.x for p in pts),min(p.y for p in pts),max(p.x for p in pts),max(p.y for p in pts)]
        assert bounds[0]>=0 and bounds[1]>=0 and bounds[2]<=1 and bounds[3]<=1,(ob.name,bounds)
        projected.append({'object':ob.name,'normalized_bounds':bounds})
    framing_margin=min(min(r['normalized_bounds'][0],r['normalized_bounds'][1],1-r['normalized_bounds'][2],1-r['normalized_bounds'][3]) for r in projected)
    planar_checks=[]
    for ob in s.objects:
        if ob.type!='MESH' or len(ob.data.polygons)!=1:continue
        for material in ob.data.materials:
            if not material or not material.name.startswith('Original vector print / '):continue
            tex=next(n.image for n in material.node_tree.nodes if n.type=='TEX_IMAGE')
            spans=[max(v.co[k] for v in ob.data.vertices)-min(v.co[k] for v in ob.data.vertices) for k in range(3)]
            plane_aspect=spans[0]/(spans[1] or spans[2])
            source_aspect=tex.size[0]/tex.size[1]
            error=abs(plane_aspect/source_aspect-1)
            assert error<1e-6,(ob.name,error)
            planar_checks.append({'object':ob.name,'texture':tex.name,'source_aspect':source_aspect,'plane_aspect':plane_aspect,'relative_error':error})
    records.append({'scene':p.name,'exists':True,'texture_dependencies':images,'render_pixels':[s.render.resolution_x,s.render.resolution_y],'samples':s.cycles.samples,'denoising':s.cycles.use_denoising,'denoiser':s.cycles.denoiser,'denoising_passes':s.cycles.denoising_input_passes,'view_transform':s.view_settings.view_transform,'camera_type':s.camera.data.type,'camera_lens_mm':s.camera.data.lens,'planar_texture_aspect_checks':planar_checks,'all_bounding_boxes_inside_frame':True,'minimum_frame_margin_percent':100*framing_margin,'render_output':s.render.filepath,'packed_and_relative':True})
    bpy.ops.wm.save_as_mainfile(filepath=str(p))
(HERE/'scene-portability-check.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
print(json.dumps({'verified_scenes':len(records),'all_packed_and_relative':all(r.get('packed_and_relative') for r in records)}))
