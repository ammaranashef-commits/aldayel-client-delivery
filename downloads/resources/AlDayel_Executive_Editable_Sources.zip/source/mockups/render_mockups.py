"""AlDayel concept mockups. Run: blender -b -t 3 -P render_mockups.py

Physically modelled objects and exact source vector print textures. No AI redraw.
The scene is a visual concept, not a printer dieline or manufacturing specification.
"""
from pathlib import Path
import bpy, math, sys, os
from mathutils import Vector

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p / 'assets/logos/residential').is_dir())
IMAGES = Path(os.environ.get('ALDAYEL_OUTPUT_DIR', str(ROOT / 'assets/images')))
IMAGES.mkdir(exist_ok=True, parents=True)
MODE = sys.argv[sys.argv.index('--')+1] if '--' in sys.argv else 'both'
RENDER_WIDTH = int(os.environ.get('ALDAYEL_RENDER_WIDTH', '2400'))
RENDER_SAMPLES = int(os.environ.get('ALDAYEL_SAMPLES', '96'))

def rgba(h):
    c=[int(h[i:i+2],16)/255 for i in (1,3,5)]
    return tuple(v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in c)+(1,)

def material(name,color,rough=.65,metal=0,noise=0):
    m=bpy.data.materials.new(name); m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=rgba(color)
    p.inputs['Roughness'].default_value=rough
    p.inputs['Metallic'].default_value=metal
    p.inputs['Specular IOR Level'].default_value=.12 if metal==0 else .5
    if noise:
        n=m.node_tree.nodes.new('ShaderNodeTexNoise');n.inputs['Scale'].default_value=360
        n.inputs['Detail'].default_value=2;n.inputs['Roughness'].default_value=.7
        b=m.node_tree.nodes.new('ShaderNodeBump');b.inputs['Strength'].default_value=.12;b.inputs['Distance'].default_value=noise
        m.node_tree.links.new(n.outputs['Fac'],b.inputs['Height']);m.node_tree.links.new(b.outputs['Normal'],p.inputs['Normal'])
    return m

def print_mat(name):
    m=material('Original vector print / '+name,'#FFFFFF',.84,noise=.0008)
    p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Specular IOR Level'].default_value=.08
    t=m.node_tree.nodes.new('ShaderNodeTexImage');t.image=bpy.data.images.load(str(HERE/'textures'/f'{name}.png'))
    t.interpolation='Linear'
    m.node_tree.links.new(t.outputs['Color'],p.inputs['Base Color'])
    return m

def box(name,loc,scale,mat,bevel=.02,rot=0):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc)
    o=bpy.context.object;o.name=name;o.dimensions=scale
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.rotation_euler.z=math.radians(rot)
    if bevel:
        m=o.modifiers.new('Soft manufactured edges','BEVEL');m.width=bevel;m.segments=3
        n=o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
    o.data.materials.append(mat)
    return o

def print_top(name,x,y,z,w,h,mat,rot=0):
    # Fit the complete source texture without the subtle anisotropic stretch
    # introduced by subtracting an equal trim distance from both dimensions.
    tex=next(n.image for n in mat.node_tree.nodes if n.type=='TEX_IMAGE')
    aspect=tex.size[0]/tex.size[1]
    if w/h>aspect:w=h*aspect
    else:h=w/aspect
    verts=[(-w/2,-h/2,0),(w/2,-h/2,0),(w/2,h/2,0),(-w/2,h/2,0)]
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],[(0,1,2,3)]);mesh.update()
    o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);o.location=(x,y,z);o.rotation_euler.z=math.radians(rot)
    uv=mesh.uv_layers.new(name='Source print placement')
    for i,val in enumerate([(0,0),(1,0),(1,1),(0,1)]):uv.data[i].uv=val
    mesh.materials.append(mat)
    return o

def print_front(name,x,y,z,w,h,mat):
    tex=next(n.image for n in mat.node_tree.nodes if n.type=='TEX_IMAGE')
    aspect=tex.size[0]/tex.size[1]
    if w/h>aspect:w=h*aspect
    else:h=w/aspect
    verts=[(-w/2,0,-h/2),(w/2,0,-h/2),(w/2,0,h/2),(-w/2,0,h/2)]
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],[(0,1,2,3)]);mesh.update()
    o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);o.location=(x,y,z)
    uv=mesh.uv_layers.new(name='Source print placement')
    for i,val in enumerate([(0,0),(1,0),(1,1),(0,1)]):uv.data[i].uv=val
    mesh.materials.append(mat)
    return o

def rod(name,p1,p2,r,mat):
    p1,p2=Vector(p1),Vector(p2);v=p2-p1
    bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=r,depth=v.length,location=(p1+p2)/2)
    o=bpy.context.object;o.name=name;o.rotation_euler=v.to_track_quat('Z','Y').to_euler();o.data.materials.append(mat)
    for f in o.data.polygons:f.use_smooth=True
    b=o.modifiers.new('Rounded edges','BEVEL');b.width=.01;b.segments=3
    return o

def rope(name,points,r,mat):
    c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=32;c.bevel_depth=r;c.bevel_resolution=5
    s=c.splines.new('BEZIER');s.bezier_points.add(len(points)-1)
    for p,co in zip(s.bezier_points,points):p.co=co;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
    o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);o.data.materials.append(mat)
    return o

def area(name,loc,power,size,color,target=(0,0,0),shape='DISK'):
    d=bpy.data.lights.new(name,'AREA');d.energy=power;d.shape=shape;d.size=size;d.color=color
    o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
    return o

def init():
    bpy.context.preferences.filepaths.save_version=0
    bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
    s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=RENDER_SAMPLES
    # Official Blender builds include OpenImageDenoise. Keep a documented raw
    # fallback for distribution builds without a denoising backend.
    try:
        s.cycles.denoiser='OPENIMAGEDENOISE'
        s.cycles.use_denoising=True
        s.cycles.denoising_input_passes='RGB_ALBEDO_NORMAL'
        s.cycles.denoising_prefilter='ACCURATE'
    except (TypeError,ValueError):
        s.cycles.use_denoising=False
    s.cycles.use_adaptive_sampling=True;s.cycles.adaptive_threshold=.008;s.cycles.adaptive_min_samples=64
    s.cycles.max_bounces=8;s.cycles.diffuse_bounces=4;s.cycles.glossy_bounces=4
    s.render.threads_mode='FIXED';s.render.threads=int(os.environ.get('ALDAYEL_RENDER_THREADS','3'))
    s.render.resolution_x=RENDER_WIDTH;s.render.resolution_y=round(RENDER_WIDTH*5/8);s.render.resolution_percentage=100
    s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB'
    s.view_settings.view_transform='Standard';s.view_settings.look='None';s.view_settings.exposure=-.8
    s.world.color=(.2,.2,.2)
    s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.9,.93,1,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.5
    mats={
      'pearl':material('Warm uncoated cotton paper','#F4F3EF',.86,noise=.0008),
      'ink':material('Matte uncoated ink paper','#1C3549',.84,noise=.0008),
      'mist':material('Uncoated mist paper','#CCDDE4',.86,noise=.0008),
      'copper':material('Brushed copper','#A96B53',.32,.65),
      'linen':material('Fine limestone studio surface','#DCD9D0',.95,noise=.0012),
      'handle':material('Natural paper cord','#C7B49A',.96,noise=.003),
    }
    box('Limestone studio surface',(0,0,-.19),(200,200,.35),mats['linen'],.02)
    area('Broad daylight window',(-4,-3,9),950,7,(1,.98,.94))
    area('Quiet neutral bounce',(5,1,6),180,6,(.94,.97,1))
    area('Gentle rear separation',(-1,6,8),150,5,(1,.98,.94))
    return mats

def camera(loc,target,scale):
    # A long product-photography lens introduces natural perspective without
    # the flattened geometry of the original orthographic renders.
    target=Vector(target);direction=(Vector(loc)-target).normalized()
    distance=scale*70/36
    bpy.ops.object.camera_add(location=target+direction*distance);c=bpy.context.object
    c.rotation_euler=(Vector(target)-c.location).to_track_quat('-Z','Y').to_euler()
    c.data.type='PERSP';c.data.lens=70;c.data.sensor_width=36
    bpy.context.scene.camera=c
    return c

def save_render(name):
    bpy.context.scene.render.filepath=str(IMAGES/f'{name}.png')
    bpy.ops.wm.save_as_mainfile(filepath=str(HERE/f'{name}.blend'))
    # Pack all exact-source print textures so scenes can travel with the deliverable.
    bpy.ops.file.make_paths_relative()
    bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(HERE/f'{name}.blend'))
    bpy.ops.render.render(write_still=True)

def stationery():
    m=init()
    # Genuine scale relationships: A4 210x297 mm and 90x54 mm business cards.
    box('Letterhead underlay',(-1.6,.75,.022),(4.2,5.94,.035),m['mist'],.008,-5)
    box('A4 cotton letterhead',(-1.8,.65,.065),(4.2,5.94,.035),m['pearl'],.007,-9)
    print_top('A4 original-logo print',-1.8,.65,.0835,4.192,5.932,print_mat('letterhead'),-9)
    box('Envelope paper',(2.05,1.65,.045),(4.4,2.2,.07),m['mist'],.018,9)
    print_top('Envelope original-logo print',2.05,1.65,.082,4.385,2.185,print_mat('envelope'),9)
    # Thick duplex stock, a visible layered edge on the card stack.
    for j in range(16):
        box(f'Ink card stock {j+1}',(1.5,-1.55,.015+j*.012),(1.8,1.08,.011),m['ink'] if j%2 else m['pearl'],.004,-10)
    print_top('Business card original-logo front',1.5,-1.55,.202,1.795,1.075,print_mat('card_ink'),-10)
    box('Pearl business card',(2.3,-.25,.06),(1.8,1.08,.027),m['pearl'],.004,14)
    print_top('Pearl business card original-logo front',2.3,-.25,.074,1.795,1.075,print_mat('card_pearl'),14)
    # Real geometry pen, no fictitious contact information.
    rod('Copper pen barrel',(3.62,-1.95,.09),(4.08,.62,.09),.044,m['copper'])
    rod('Ink pen cap',(4.08,.62,.09),(4.17,1.12,.09),.049,m['ink'])
    rod('Pen writing tip',(3.59,-2.1,.09),(3.62,-1.95,.09),.02,m['copper'])
    rod('Pen clip',(4.11,.63,.15),(4.17,1.02,.15),.012,m['copper'])
    # Keep the complete A4 suite visible; paper and print provide the detail.
    camera((.6,-4.8,14),(.1,.6,0),11.6)
    save_render('mockup_stationery')

def packaging(welcome=False):
    m=init()
    if not welcome and 'ALDAYEL_SAMPLES' not in os.environ:
        bpy.context.scene.cycles.samples=64
    # Open, rigid paper shopping bag with real edge thickness and bottom.
    bx,by,bw,bd,bh=-1.75,.65,3.05,1.36,3.7
    box('Bag front',(bx,by-bd/2,bh/2),(bw,.035,bh),m['ink'],.018)
    box('Bag back',(bx,by+bd/2,bh/2),(bw,.035,bh),m['ink'],.018)
    # Actual inward-folded side gussets instead of a rigid rectangular box.
    # The printed front remains planar and its UV geometry remains unchanged.
    for sign,label in [(-1,'left'),(1,'right')]:
        verts=[]
        for z,inset in [(.045,.015),(.65,.12),(bh,.18)]:
            for yy,fold in [(by-bd/2+.012,0),(by,inset),(by+bd/2-.012,0)]:
                verts.append((bx+sign*(bw/2-.012-fold),yy,z))
        faces=[(a,a+1,a+4,a+3) for a in [0,1,3,4]]
        mesh=bpy.data.meshes.new('Folded paper gusset '+label);mesh.from_pydata(verts,[],faces);mesh.update()
        ob=bpy.data.objects.new('Bag '+label+' inward paper gusset',mesh);bpy.context.collection.objects.link(ob);mesh.materials.append(m['ink'])
        solid=ob.modifiers.new('Paper wall thickness','SOLIDIFY');solid.thickness=.025
        edge=ob.modifiers.new('Soft paper fold','BEVEL');edge.width=.008;edge.segments=3
    box('Bag bottom',(bx,by,.035),(bw,bd,.07),m['ink'],.015)
    # Ink-colored folded rims, visible as real edges at the opening.
    box('Folded front rim',(bx,by-bd/2+.018,bh-.09),(bw-.04,.05,.18),m['ink'],.015)
    box('Folded back rim',(bx,by+bd/2-.018,bh-.09),(bw-.04,.05,.18),m['ink'],.015)
    print_front('Bag original-logo surface',bx,by-bd/2-.0185,bh/2,bw-.03,bh-.03,print_mat('bag'))
    # Paper-cord handles attach below top rim; no floating handles.
    for y in [by+.62,by-.73]:
        rope('Twisted paper handle',[(bx-.62,y,3.36),(bx-.65,y,4.12),(bx-.35,y,4.49),(bx+.35,y,4.49),(bx+.65,y,4.12),(bx+.62,y,3.36)],.037,m['handle'])
        for x in [bx-.62,bx+.62]:
            rod('Small paper handle eyelet',(x,y+.025,3.33),(x,y-.018,3.33),.05,m['ink'])
    # Presentation box: ink base and warm pearl lid with restrained copper wrap.
    x,y=1.35,-1.2
    box('Rigid presentation box base',(x,y,.43),(3.32,2.34,.86),m['ink'],.035,-4)
    box('Rigid presentation box lid',(x,y,.94),(3.4,2.42,.22),m['pearl'],.035,-4)
    print_top('Presentation lid exact-logo print',x,y,1.052,3.37,2.39,print_mat('box'),-4)
    # Narrow copper ribbon follows lid top and front edge, angled with the box.
    ribbon=material('Copper woven ribbon','#A96B53',.88,0,noise=.0012)
    a=math.radians(-4)
    def pos(dx,dy,z):return(x+math.cos(a)*dx-math.sin(a)*dy,y+math.sin(a)*dx+math.cos(a)*dy,z)
    box('Ribbon top',pos(-1.0,0,1.06),(.14,2.43,.012),ribbon,.002,-4)
    box('Ribbon front',pos(-1,-1.216,.535),(.14,.012,1.06),ribbon,.002,-4)
    box('Ribbon back',pos(-1,1.216,.535),(.14,.012,1.06),ribbon,.002,-4)
    # Additional flat welcome card, using the approved exact logo print.
    cx,cy=(2.95,1.0) if welcome else (3.65,1.35)
    box('Welcome card',(cx,cy,.026),(1.8,1.08,.025),m['ink'],.004,13)
    print_top('Welcome card exact-logo print',cx,cy,.041,1.795,1.075,print_mat('card_ink'),13)
    if welcome:
        camera((-7,-13,8),(-.15,0,1.94),10.8)
        save_render('mockup_packaging_welcome')
    else:
        camera((6,-13,8),(-.15,0,1.94),12.0)
        save_render('mockup_packaging')

def torus(name,loc,major,minor,mat):
    bpy.ops.mesh.primitive_torus_add(major_radius=major,minor_radius=minor,major_segments=128,minor_segments=16,location=loc)
    o=bpy.context.object;o.name=name;o.data.materials.append(mat)
    for f in o.data.polygons:f.use_smooth=True
    return o

def cup_body(name,x,y,texture):
    # Continuous tapered paper shell. UV unwrap places the unaltered vector logo
    # onto the physically curved cup; it is not redrawn or flattened afterward.
    n=192;verts=[];faces=[];uvs=[];phase=-1.2-math.pi
    for z,r in [(.06,.72),(2.6,.98)]:
        for i in range(n+1):
            a=phase+2*math.pi*i/n;verts.append((x+r*math.cos(a),y+r*math.sin(a),z))
    for i in range(n):faces.append((i,i+1,n+2+i,n+1+i))
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update()
    o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o)
    uv=mesh.uv_layers.new(name='Full-circumference original-logo artwork')
    for poly in mesh.polygons:
        i=poly.index;coords=[(i/n,0),((i+1)/n,0),((i+1)/n,1),(i/n,1)]
        for loop,co in zip(poly.loop_indices,coords):uv.data[loop].uv=co
        poly.use_smooth=True
    mesh.materials.append(print_mat(texture))
    s=o.modifiers.new('Real paper wall','SOLIDIFY');s.thickness=.015
    return o

def cup_lid(name,x,y,mat,dark):
    # A closed, stepped molded lid: recessed centre, raised annular drinking
    # deck and rolled closure. Apertures are cut through the actual mesh.
    profile=[(.001,2.735),(.54,2.735),(.60,2.75),(.64,2.80),(.67,2.855),(.86,2.855),(.91,2.83),(.94,2.74),(.97,2.67),(1.025,2.65),(1.04,2.615),(1.035,2.585),(.99,2.57),(.95,2.59),(.90,2.70),(.85,2.81),(.69,2.81),(.64,2.705),(.001,2.705)]
    n=128;verts=[];faces=[]
    for r,z in profile:
        for i in range(n):
            a=2*math.pi*i/n;verts.append((x+r*math.cos(a),y+r*math.sin(a),z))
    for j in range(len(profile)-1):
        for i in range(n):faces.append((j*n+i,(j+1)*n+i,(j+1)*n+(i+1)%n,j*n+(i+1)%n))
    faces.append(tuple(reversed(range(n))))
    faces.append(tuple((len(profile)-1)*n+i for i in range(n)))
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update()
    o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);mesh.materials.append(mat)
    for f in mesh.polygons:f.use_smooth=True
    # Orient all closed mesh normals consistently before the exact Boolean.
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active=o;o.select_set(True)
    bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT')
    for label,cx,cy,rx,ry in [('drinking slot',x+.07,y-.765,.18,.063),('air vent',x-.04,y+.31,.016,.016)]:
        bpy.ops.mesh.primitive_cylinder_add(vertices=64,radius=1,depth=.6,location=(cx,cy,2.77))
        cutter=bpy.context.object;cutter.name=name+' '+label+' cutter';cutter.scale=(rx,ry,1)
        bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
        cut=o.modifiers.new('True through-cut '+label,'BOOLEAN');cut.operation='DIFFERENCE';cut.solver='EXACT';cut.object=cutter
        bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=cut.name)
        bpy.data.objects.remove(cutter,do_unlink=True)
    edge=o.modifiers.new('Molded opening edges','BEVEL');edge.width=.006;edge.segments=3
    # The visible darkness comes from a deep cavity, not a flat painted dot.
    bpy.ops.mesh.primitive_cylinder_add(vertices=96,radius=.9,depth=.018,location=(x,y,2.0))
    interior=bpy.context.object;interior.name=name+' dark cup interior';interior.data.materials.append(dark)

def cups():
    m=init()
    if 'ALDAYEL_SAMPLES' not in os.environ:
        bpy.context.scene.cycles.samples=64
    dark=material('Recessed lid openings','#202830',.95)
    lid=material('Matte molded pearl lid','#F4F3EF',.72,noise=.0004)
    for name,x,y,tex in [('Pearl welcome cup',-1.04,-.25,'cup_pearl'),('Ink welcome cup',1.30,.94,'cup_ink')]:
        cup_body(name,x,y,tex)
        cup_lid(name,x,y,lid,dark)
        torus(name+' rolled foot',(x,y,.075),.72,.022,m['pearl'] if tex=='cup_pearl' else m['ink'])
    # At the scene's nominal 40 mm/unit scale, cup primary marks are ~52 mm wide.
    # Detail card is 90 x 54 mm, with an unchanged 63 mm primary mark.
    for j in range(6):
        box(f'Detail card stock {j+1}',(.45,-1.95,.015+j*.014),(2.25,1.35,.013),m['ink'] if j%2 else m['pearl'],.004,-9)
    print_top('Large original-logo card detail',.45,-1.95,.093,2.245,1.345,print_mat('card_detail_ink'),-9)
    camera((3.1,-10,5.5),(.08,-.3,1.2),8.6)
    save_render('mockup_cups')

if MODE in ('both','stationery'):stationery()
if MODE in ('both','packaging'):packaging()
if MODE in ('both','cups'):cups()
if MODE=='welcome':packaging(welcome=True)
