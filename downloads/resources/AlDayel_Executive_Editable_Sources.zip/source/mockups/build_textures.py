"""Build mockup print textures from original AlDayel vector geometry.

No raster logo reconstruction; the supplied SVG is embedded without geometry edits.
Arabic uses the supplied Helvetica Neue LT Arabic through fontconfig/Inkscape.
"""
from pathlib import Path
import base64, subprocess, os

ROOT = next(p for p in Path(__file__).resolve().parents if (p / 'assets/logos/residential').is_dir())
OUT = Path(__file__).resolve().parent / 'textures'
OUT.mkdir(exist_ok=True)
FONT_DIR = Path(os.environ.get('ALDAYEL_FONT_DIR', ROOT.parent / '.work/fonts'))
FONT_CACHE = OUT / '.fontcache'
FONT_CACHE.mkdir(exist_ok=True)
fontconf = OUT / 'fonts.conf'
fontconf.write_text(f'''<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd"><fontconfig><include ignore_missing="yes">/etc/fonts/fonts.conf</include><dir>{FONT_DIR}</dir><cachedir>{FONT_CACHE}</cachedir></fontconfig>''')
env = dict(os.environ, FONTCONFIG_FILE=str(fontconf))

INK, PEARL, MIST, COPPER = '#1C3549', '#F4F3EF', '#CCDDE4', '#A96B53'

def logo(x,y,w,color='ink'):
    svg = (ROOT / f'assets/logos/residential/aldayel-primary-ar-{color}.svg').read_bytes()
    encoded = base64.b64encode(svg).decode()
    h = w * 287.841431 / 763.470016
    return f'<image x="{x}" y="{y}" width="{w}" height="{h}" href="data:image/svg+xml;base64,{encoded}"/>'

def label(x,y,color=INK,size=40):
    return f'<text x="{x}" y="{y}" text-anchor="middle" font-family="Helvetica Neue LT Arabic" font-size="{size}" fill="{color}">السكني</text>'

def make(name,w,h,bg,content):
    p = OUT / f'{name}.svg'
    p.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><rect width="{w}" height="{h}" fill="{bg}"/>{content}</svg>')
    subprocess.run(['inkscape',str(p),'--export-filename',str(OUT/f'{name}.png'),'--export-width',str(w)],check=True,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    outlined = OUT / 'outlined'
    outlined.mkdir(exist_ok=True)
    subprocess.run(['inkscape',str(p),'--export-type=svg','--export-plain-svg','--export-text-to-path','--export-filename',str(outlined/f'{name}.svg')],check=True,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)

make('letterhead',1400,1980,PEARL,
    logo(865,125,385)+label(1058,325,size=33)+
    '<path d="M125 1710 V1845 H1275 M125 1775 H190 V1845" fill="none" stroke="#A96B53" stroke-width="2"/>'+ 
    '<path d="M125 1905 H1275" fill="none" stroke="#CCDDE4" stroke-width="1"/>')

make('card_ink',1500,900,INK,logo(375,180,750,'pearl')+label(750,590,PEARL,50)+
    '<path d="M1380 95 H1415 V805 H120" fill="none" stroke="#A96B53" stroke-width="3"/>')
make('card_pearl',1500,900,PEARL,logo(375,180,750)+label(750,590,INK,50)+
    '<path d="M110 110 V790 H1390 M110 685 H215 V790" fill="none" stroke="#A96B53" stroke-width="3"/>')

make('envelope',1800,900,MIST,logo(1100,130,510)+label(1355,435,INK,35)+
    '<path d="M100 120 V780 H1700 M100 650 H230 V780" fill="none" stroke="#1C3549" stroke-width="2"/>')

make('bag',1400,1700,INK,logo(300,530,800,'pearl')+label(700,1005,PEARL,50)+
    '<path d="M120 1340 V1570 H1280 M120 1460 H240 V1570" fill="none" stroke="#A96B53" stroke-width="3"/>')

make('box',1600,1120,PEARL,logo(585,280,650)+label(910,680,INK,42)+
    '<path d="M400 150 V970 H1450" fill="none" stroke="#A96B53" stroke-width="2"/>')

make('cup_pearl',2800,1400,PEARL,logo(1060,460,680)+label(1400,890,INK,58)+
    '<path d="M0 1280 H2800" fill="none" stroke="#A96B53" stroke-width="3"/>')
make('cup_ink',2800,1400,INK,logo(1060,460,680,'pearl')+label(1400,890,PEARL,58)+
    '<path d="M0 1280 H2800" fill="none" stroke="#A96B53" stroke-width="3"/>')
make('card_detail_ink',1500,900,INK,logo(225,120,1050,'pearl')+label(750,690,PEARL,55)+
    '<path d="M1390 95 V805 H110" fill="none" stroke="#A96B53" stroke-width="3"/>')

print('Textures built from exact original vector logo.')
