#!/usr/bin/env python3
"""Audit the exported 20-page executive book without changing design files.

Run after build/render, then inspect every rendered page separately. This checker
does not certify visual quality, PDF/UA, PDF/X, commercial data, or press output.
Image PPI is derived from native pixels and the complete PDF image transform;
upscaled previews are never treated as extra source resolution.
"""
from pathlib import Path
import argparse
import collections
import hashlib
import json
import re
import struct

import fitz
from pypdf import PdfReader
from validate_pdf import audit as pdf_audit
from validate_pdf_logo_affine import audit as logo_audit

ROOT = Path(__file__).resolve().parent.parent
FULL_GUIDE_HASH = "6afa44a0ceb60aa162b03463847dc820a8da44888a452dd395ddebaded26db7d"
PALETTE = {"ink": (28, 53, 73), "pearl": (244, 243, 239),
           "mist": (204, 221, 228), "copper": (169, 107, 83)}


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sfnt_family_names(path):
    """Read identifying names with stdlib; no extra font dependency required."""
    data = path.read_bytes()
    if data[:4] not in (b"\x00\x01\x00\x00", b"OTTO", b"true"):
        return []
    count = struct.unpack_from(">H", data, 4)[0]
    for i in range(count):
        tag, _, offset, length = struct.unpack_from(">4sIII", data, 12 + i * 16)
        if tag != b"name":
            continue
        _, records, storage = struct.unpack_from(">HHH", data, offset)
        names = set()
        for j in range(records):
            platform, _, _, name_id, size, start = struct.unpack_from(
                ">HHHHHH", data, offset + 6 + 12 * j)
            if name_id not in (1, 4, 6, 16):
                continue
            value = data[offset + storage + start:offset + storage + start + size]
            names.add(value.decode("utf-16-be" if platform in (0, 3) else "latin1", errors="replace"))
        return sorted(names)
    return []


def embedded_font_records(reader):
    """Type3 fonts contain glyph streams, rather than a FontFile descriptor."""
    def resolve(value):
        return value.get_object() if hasattr(value, "get_object") else value
    found = {}
    for page in reader.pages:
        resources = resolve(page.get("/Resources", {}))
        for value in resolve(resources.get("/Font", {})).values():
            key = (getattr(value, "idnum", None), getattr(value, "generation", None))
            if key in found:
                continue
            font = value.get_object()
            subtype = str(font.get("/Subtype", ""))
            descendants = font.get("/DescendantFonts", [])
            descriptor_owner = descendants[0].get_object() if descendants else font
            descriptor = resolve(descriptor_owner.get("/FontDescriptor", {}))
            files = [k for k in ("/FontFile", "/FontFile2", "/FontFile3") if k in descriptor]
            glyphs = resolve(font.get("/CharProcs", {}))
            embedded = bool(glyphs) if subtype == "/Type3" else bool(files)
            found[key] = {"xref": key[0], "subtype": subtype,
                          "name": str(font.get("/BaseFont", "")),
                          "embedded": embedded, "type3_glyph_streams": len(glyphs),
                          "to_unicode": "/ToUnicode" in font}
    return list(found.values())


def audit(pdf, root):
    pdf = pdf.resolve()
    root = root.resolve()
    technical = pdf_audit(pdf)
    doc = fitz.open(pdf)
    reader = PdfReader(str(pdf), strict=True)
    failures, warnings = [], []

    def require(ok, code, detail):
        if not ok:
            failures.append({"code": code, "detail": detail})

    require(len(doc) == 20, "page_count", f"Expected 20 pages, found {len(doc)}")
    require(not doc.is_repaired, "pdf_repair", "PDF parser required repair")
    dimensions = [{"page": i + 1,
                   "mm": [round(pg.rect.width * 25.4 / 72, 6), round(pg.rect.height * 25.4 / 72, 6)]}
                  for i, pg in enumerate(doc)]
    exact_geometry = all(abs(row["mm"][0] - 240) < .01 and abs(row["mm"][1] - 300) < .01 for row in dimensions)
    require(exact_geometry, "trim_size", "Media/Crop geometry must be 240 x 300 mm within 0.01 mm; change boxes without scaling the physical specimens")
    catalog = reader.trailer["/Root"]
    preferences = catalog.get("/ViewerPreferences", {})
    if hasattr(preferences, "get_object"):
        preferences = preferences.get_object()
    direction = str(preferences.get("/Direction", ""))
    layout = str(catalog.get("/PageLayout", ""))
    require(direction == "/R2L" and layout == "/TwoPageRight", "reader_direction", {"direction": direction, "layout": layout})

    full = root / "AlDayel_Residential_Brand_Guidelines_PREMIUM_FINAL.pdf"
    full_hash = sha256(full) if full.is_file() else None
    require(full_hash == FULL_GUIDE_HASH, "full_guide_preservation", {"expected": FULL_GUIDE_HASH, "actual": full_hash})

    fonts = embedded_font_records(reader)
    require(bool(fonts) and all(f["embedded"] for f in fonts), "font_embedding", fonts)
    require(all(f["to_unicode"] for f in fonts), "font_unicode", "Every font resource needs a ToUnicode map")
    source_fonts = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in (".otf", ".ttf", ".ttc", ".woff", ".woff2"):
            continue
        names = sfnt_family_names(path)
        allowed = bool(names) and all("ptsans" in re.sub(r"[^a-z]", "", n.lower()) or "pt sans" in n.lower() for n in names)
        source_fonts.append({"path": str(path.relative_to(root)), "family_names": names,
                             "permitted_pt_sans_source": allowed})
    require(all(f["permitted_pt_sans_source"] for f in source_fonts), "licensed_source_font_exclusion", source_fonts)
    require((root / "assets/fonts/PTSans-LICENSE.txt").is_file(), "pt_sans_license", "PT Sans redistribution licence is required")

    fills = collections.Counter()
    for pg in doc:
        for item in pg.get_drawings():
            if item.get("fill") and item.get("fill_opacity", 1) > .99:
                fills[tuple(round(v * 255) for v in item["fill"])] += 1
    colors = [{"name": name, "expected_rgb_8bit": list(rgb), "matching_vector_fill_count": fills[rgb]} for name, rgb in PALETTE.items()]
    require(all(c["matching_vector_fill_count"] for c in colors), "approved_palette", colors)
    swatch_fills = collections.Counter(tuple(round(v * 255) for v in item["fill"])
                                     for item in doc[6].get_drawings()
                                     if item.get("fill") and item.get("fill_opacity", 1) > .99 and item["rect"].get_area() > 100)
    require(all(swatch_fills[rgb] for rgb in PALETTE.values()), "page7_palette_swatches", "All four approved RGB colours must occur as substantial vector fills on page 7")

    logos = logo_audit(pdf, root / "assets/logos/original")
    intentional, bad, logo_color_issues = [], [], []
    page_drawings = {i + 1: page.get_drawings() for i, page in enumerate(doc)}
    for row in logos["records"]:
        x0, y0, x1, y1 = row["bbox_pt"]
        page_rect = doc[row["page"] - 1].rect
        # Exact *instance* exception: middle lower misuse example, primary Arabic,
        # known scaleX(1.45). Never exempt an entire page, particularly page 15.
        is_wrong_use = (row["page"] == 6 and row["variant"] == "primary-ar"
                        and .3 * page_rect.width < (x0 + x1) / 2 < .7 * page_rect.width
                        and y0 > .6 * page_rect.height
                        and abs(row["anisotropy_percent"] - 45) < .1
                        and row["affine_max_error_pt"] < .01)
        row["intentional_wrong_use_instance"] = is_wrong_use
        subset = page_drawings[row["page"]][row["drawing_start"]:row["drawing_start"] + row["path_count"]]
        row["rgb_fills_8bit"] = sorted({tuple(round(v * 255) for v in item["fill"])
                                      for item in subset if item.get("fill")})
        if any(tuple(fill) not in PALETTE.values() for fill in row["rgb_fills_8bit"]):
            logo_color_issues.append({"page": row["page"], "variant": row["variant"], "fills": row["rgb_fills_8bit"]})
        if is_wrong_use:
            intentional.append(row)
        elif row["anisotropy_percent"] > .1 or row["affine_max_error_pt"] > .01:
            bad.append(row)
    require(len(logos["records"]) >= 30, "vector_logo_coverage", f"Only {len(logos['records'])} exact topology logo records matched; inspect missing variants")
    require(len(intentional) == 1, "intentional_misuse_scope", f"Expected exactly one scoped p6 distortion; found {len(intentional)}")
    require(not bad, "vector_logo_geometry", bad)
    require(not logo_color_issues, "vector_logo_palette", logo_color_issues)
    samples = []
    for variant, width in (("primary-ar", 45), ("wordmark", 20), ("icon", 8)):
        rows = [r for r in logos["records"] if r["page"] == 6 and r["variant"] == variant and not r["intentional_wrong_use_instance"]]
        match = min(rows, key=lambda r: abs(r["width_mm"] - width)) if rows else None
        actual = match["width_mm"] if match else None
        passed = actual is not None and abs(actual - width) < .01
        samples.append({"variant": variant, "target_width_mm": width, "actual_ink_width_mm": actual,
                        "tolerance_mm": .01, "pass": passed, "bbox_pt": match["bbox_pt"] if match else None})
        require(passed, "physical_logo_specimen", samples[-1])

    copy_path = root / "source/book-copyable-text.ar.txt"
    copy_text = copy_path.read_text() if copy_path.is_file() else ""
    sections = re.findall(r"(?m)^\[(\d{2})\]", copy_text)
    require(sections == [f"{i:02}" for i in range(1, 21)], "logical_arabic_source", "Logical source text must contain all 20 ordered page sections")
    require("الدايل السكني" in copy_text and "\ufffd" not in copy_text, "logical_arabic_integrity", "Logical source text must contain readable Arabic without replacement characters")
    require(all(p["selectable_text_present"] for p in technical["pages"]), "selectable_pdf_text", technical["summary"]["pages_without_selectable_text"])
    require(not technical["summary"]["pages_with_text_outside_page"], "pdf_text_bounds", technical["summary"]["pages_with_text_outside_page"])

    architecture_images = [im for im in technical["image_placements"] if im["page"] in (1, 4, 11, 13) and im["fraction_page_area_before_clipping"] > .2]
    for image in technical["summary"]["significant_images_below_180_ppi"]:
        warnings.append({"code": "native_image_print_limit", "page": image["page"],
                         "pixels": image["pixels"], "effective_ppi": image["effective_ppi"],
                         "detail": "Appropriate resolution must be judged for the actual viewing distance; this is not native 300 PPI press imagery. Enlarging previews does not add detail."})
    page19_images = [im for im in technical["image_placements"] if im["page"] == 19 and im["fraction_page_area_before_clipping"] > .2]
    require(bool(page19_images), "page19_material_scene", "Page 19 requires a loaded substantial material scene; missing-image alt text is not an application preview")
    if technical["text_copy_accessibility"]["actual_text_marked_spans"]:
        warnings.append({"code": "arabic_copy_variation", "detail": "Arabic glyphs and ActualText are present, but extractor ordering/diacritic handling varies. Use the supplied logical Unicode sidecar; PDF/UA is not certified."})

    result = {"name": "Executive 20P exported-PDF technical audit", "pdf": str(pdf), "pdf_sha256": sha256(pdf),
              "pass": not failures, "failures": failures, "warnings": warnings,
              "page_geometry_mm": dimensions, "reader_preferences": {"direction": direction, "layout": layout},
              "full_guide_sha256": full_hash, "font_resources": fonts, "distributed_source_fonts": source_fonts,
              "exact_palette_vector_fills": colors, "physical_page6_samples": samples,
              "intentional_distortion_count": len(intentional), "logo_affine": logos,
              "logical_source_text": {"path": str(copy_path.relative_to(root)), "sha256": sha256(copy_path) if copy_path.is_file() else None,
                                      "ordered_page_sections": sections, "arabic_characters": len(re.findall(r"[\u0600-\u06ff]", copy_text))},
              "architecture_image_placements": architecture_images, "pdf_technical": technical,
              "limitations": ["Automated checks do not replace independent visual inspection of all 20 exported pages.",
                              "This is an RGB digital master; no PDF/X, CMYK output-intent, true bleed or native 300 PPI printing claim.",
                              "Logo geometry audit sees vector paths; logos flattened inside mockups require visual verification."]}
    doc.close()
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdf", nargs="?", type=Path, default=ROOT / "AlDayel_Residential_Brand_Book_EXECUTIVE_20P.pdf")
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path, default=ROOT / "quality/executive-technical.json")
    args = parser.parse_args()
    report = audit(args.pdf, args.root)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"pdf_sha256": report["pdf_sha256"], "pass": report["pass"],
                      "failure_codes": [x["code"] for x in report["failures"]],
                      "warnings": len(report["warnings"]), "output": str(args.output)}, ensure_ascii=False))
    raise SystemExit(0 if report["pass"] else 1)
