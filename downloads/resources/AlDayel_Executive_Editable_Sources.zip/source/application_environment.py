"""Portable font/tool setup shared by the application builders and validator.

Only licensed Arabic fonts are external inputs. Logos, photos, and PT Sans are
resolved from the delivered project; generated caches stay in sibling .work.
"""
from pathlib import Path
from xml.sax.saxutils import escape
import os
import shutil

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT.parent / '.work'
ARABIC_FONT_FILES = (
    'HelveticaNeueLTArabic-Roman.otf',
    'HelveticaNeueLTArabic-Bold.otf',
)


def configure_fonts(profile):
    """Return a complete independent Inkscape/fontconfig environment.

    ALDAYEL_FONT_DIR is the shared public setting. The older marketing-only
    ALDAYEL_ARABIC_FONT_DIR remains an optional compatibility alias.
    """
    if shutil.which('inkscape') is None:
        raise RuntimeError('Inkscape is required on PATH; see source/README-applications.md.')
    configured = os.environ.get('ALDAYEL_FONT_DIR') or os.environ.get('ALDAYEL_ARABIC_FONT_DIR')
    font_dir = Path(configured).expanduser().resolve() if configured else WORK / 'fonts'
    missing = [name for name in ARABIC_FONT_FILES if not (font_dir / name).is_file()]
    if missing:
        raise RuntimeError(
            'Original licensed Arabic fonts are required; no substitute will be used. '
            'Set ALDAYEL_FONT_DIR to the folder containing ' + ', '.join(ARABIC_FONT_FILES)
            + '. Missing: ' + ', '.join(missing)
        )
    cache = WORK / 'fontcache'
    profile_dir = WORK / ('inkscape-' + profile)
    for path in (WORK, cache, WORK / 'cache', WORK / 'config', profile_dir):
        path.mkdir(parents=True, exist_ok=True)
    fontconf = WORK / (profile + '-fonts.conf')
    fontconf.write_text(
        '<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd">'
        '<fontconfig><include ignore_missing="yes">/etc/fonts/fonts.conf</include>'
        f'<dir>{escape(str(font_dir))}</dir>'
        f'<dir>{escape(str(ROOT / "assets/fonts"))}</dir>'
        f'<cachedir>{escape(str(cache))}</cachedir></fontconfig>',
        encoding='utf-8',
    )
    return dict(
        os.environ,
        FONTCONFIG_FILE=str(fontconf),
        INKSCAPE_PROFILE_DIR=str(profile_dir),
        XDG_CACHE_HOME=str(WORK / 'cache'),
        XDG_CONFIG_HOME=str(WORK / 'config'),
    )
