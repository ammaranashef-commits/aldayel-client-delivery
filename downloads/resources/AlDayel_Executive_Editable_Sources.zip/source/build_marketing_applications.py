#!/usr/bin/env python3
"""Build AlDayel's editable marketing layouts and outlined SVG / exact-size PDF proofs.
Requirements and rebuild instructions: source/README-applications.md.
No original logo geometry or image pixels are retouched. Raster imagery is embedded JPEG.
"""
from pathlib import Path
from xml.sax.saxutils import escape
from lxml import etree as ET
from PIL import Image
import base64, io, json, os, subprocess, re

from application_environment import ROOT,WORK,configure_fonts
OUT = ROOT/'applications'
EDIT = OUT/'editable'
PREVIEW = OUT/'previews'
INK='#1C3549'; PEARL='#F4F3EF'; MIST='#CCDDE4'; COPPER='#A96B53'
NS='http://www.w3.org/2000/svg'
AR='Helvetica Neue LT Arabic'
LATIN='PT Sans'
SPECS={}
for p in (OUT,EDIT,PREVIEW):
 p.mkdir(parents=True,exist_ok=True)

ENV=configure_fonts('marketing')

IMAGES={}
for kind in ('exterior','interior'):
 im=Image.open(ROOT/f'assets/images/concept_residential_{kind}.png').convert('RGB')
 b=io.BytesIO(); im.save(b,format='JPEG',quality=94,subsampling=0)
 IMAGES[kind]='data:image/jpeg;base64,'+base64.b64encode(b.getvalue()).decode()

class Canvas:
 def __init__(self,name,w,h,width,height,background=PEARL):
  self.name=name; self.w=w; self.h=h; self.width=width; self.height=height; self.items=[];self.n=0;self.logo_metrics=[]
  self.rect(0,0,w,h,background)
 def rect(self,x,y,w,h,fill,stroke=None,sw=1):
  self.items.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}"'+(f' stroke="{stroke}" stroke-width="{sw}"' if stroke else '')+'/>')
 def line(self,x1,y1,x2,y2,color=MIST,sw=1):
  self.items.append(f'<path d="M{x1},{y1} H{x2}" fill="none" stroke="{color}" stroke-width="{sw}"/>' if y1==y2 else f'<path d="M{x1},{y1} L{x2},{y2}" fill="none" stroke="{color}" stroke-width="{sw}"/>')
 def text(self,txt,x,y,size=24,color=INK,weight='normal',rtl=True,anchor=None,opacity=1,element_id=None):
  # Logical Unicode Arabic, shaped by the real licensed font via Inkscape/Pango.
  # Direction-aware start anchors the first RTL character at the right boundary.
  anchor=anchor or 'start'
  style=f'font-family:{AR if rtl else LATIN};font-size:{size}px;font-weight:{weight};fill:{color};text-anchor:{anchor};direction:{"rtl" if rtl else "ltr"};opacity:{opacity}'
  xml_id=f' id="{element_id}"' if element_id else ''
  self.items.append(f'<text{xml_id} x="{x}" y="{y}" style="{style}" xml:lang="{"ar" if rtl else "en"}">{escape(txt)}</text>')
 def logo(self,x,y,w=240,color='ink',label=True):
  p=ROOT/f'assets/logos/residential/aldayel-primary-ar-{color}.svg'
  svg=ET.fromstring(p.read_bytes()); vb=list(map(float,svg.get('viewBox').split())); h=w*vb[3]/vb[2]
  self.n+=1;prefix=f'{self.name}-logo-{self.n}-'
  physical_w=w*float(self.width[:-2])/self.w
  unit=self.width[-2:]
  minimum=45 if unit=='mm' else 240
  assert physical_w>=minimum, f'{self.name}: full primary logo smaller than {minimum}{unit}'
  self.logo_metrics.append({'type':'full-primary-ar','display_width':physical_w,'unit':unit,'minimum_width':minimum,'display_height':h*float(self.width[:-2])/self.w,'clear_space_each_side':h*.25*float(self.width[:-2])/self.w,'minimum_width_pass':physical_w>=minimum,'original_geometry_unchanged':True})
  # Namespace IDs only; every original path d and transform is preserved exactly.
  for el in svg.iter():
   if el.get('id'): el.set('id',prefix+el.get('id'))
   for a,val in list(el.attrib.items()):
    if 'url(#' in val: el.set(a,val.replace('url(#','url(#'+prefix))
  inner=''.join(ET.tostring(el,encoding='unicode') for el in svg)
  self.items.append(f'<g id="primary-mark-{self.name}" aria-label="Original complete AlDayel logo, unmodified geometry" transform="translate({x},{y}) scale({w/vb[2]}) translate({-vb[0]},{-vb[1]})">{inner}</g>')
  if label:
   size=w*.116
   # Roman glyph top at ~0.8em above baseline; 0.38 logo-height gap ensures >=h/4.
   self.text('السكني',x+w/2,y+h+h*.38+size*.82,size,PEARL if color=='pearl' else INK,anchor='middle',element_id=f'residential-label-{self.name}')
  return h
 def photo(self,kind,x,y,w,h,caption=True,caption_color=PEARL):
  self.n+=1; clip=f'{self.name}-photo-{self.n}'
  self.items.append(f'<defs><clipPath id="{clip}"><rect x="{x}" y="{y}" width="{w}" height="{h}"/></clipPath></defs>')
  self.items.append(f'<image x="{x}" y="{y}" width="{w}" height="{h}" href="{IMAGES[kind]}" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="{IMAGES[kind]}" preserveAspectRatio="xMidYMid slice" clip-path="url(#{clip})"/>')
  if caption:
   f=max(14,min(w*.024,24)); pad=f*.65
   self.rect(x+w-f*13-pad*2,y+h-f*2.1,f*13+pad*2,f*2.1,INK)
   self.text('تصوّر سكني توضيحي',x+w-pad,y+h-f*.65,f,caption_color)
 def eyebrow(self,txt,x,y,color=INK,size=16):
  self.text(txt,x,y,size,color,rtl=False)
 def save(self):
  desc='قالب هوية الدايل السكني. نموذج توضيحي؛ الصور تصوّر سكني مولّد ولا تمثّل مشاريع فعلية. «مساحة تشبه حياتك» عبارة تحريرية مقترحة وليست شعاراً لفظياً معتمداً. البيانات والمساحات والعناوين تُستكمل قبل النشر.'
  svg=f'''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="{NS}" xmlns:xlink="http://www.w3.org/1999/xlink" width="{self.width}" height="{self.height}" viewBox="0 0 {self.w} {self.h}">
<title>AlDayel Residential — {self.name} — editable application</title><desc>{escape(desc)}</desc>
{''.join(self.items)}</svg>'''
  (EDIT/f'{self.name}.svg').write_text(svg)
  SPECS[self.name]={'width':self.width,'height':self.height,'viewBox':[0,0,self.w,self.h],'editable_svg':f'editable/{self.name}.svg','outlined_svg':f'{self.name}.svg','pdf':f'{self.name}.pdf','concept_image':True,'logos':self.logo_metrics}

def post():
 c=Canvas('social-post',1080,1350,'1080px','1350px')
 c.logo(766,45,244)
 c.eyebrow('ALDAYEL / RESIDENTIAL',65,82,size=18)
 c.line(65,110,350,110,INK,1)
 c.text('مساحة',1008,292,91,weight='bold')
 c.text('تشبه حياتك',1008,397,91,weight='bold')
 c.rect(65,284,5,96,COPPER)
 c.text('تفاصيل تصنع الفارق',91,332,21,anchor='end')
 c.photo('exterior',65,467,950,633)
 c.text('تفاصيل تُقرأ في كل زاوية',1015,1190,34)
 c.line(65,1250,1015,1250,INK,.8)
 c.text('نموذج توضيحي — صياغة مقترحة',1015,1298,18)
 c.eyebrow('01 — A SENSE OF HOME',65,1296,size=16)
 c.save()

def story():
 c=Canvas('social-story',1080,1920,'1080px','1920px',INK)
 # All logo geometry, labels and editable text stay within y250..1670.
 # Background alone extends through the 250px platform UI exclusion zones.
 c.logo(764,260,244,'pearl')
 c.eyebrow('ALDAYEL RESIDENTIAL',72,285,PEARL,18)
 c.line(72,318,339,318,MIST,1)
 c.text('مساحة',1008,555,99,PEARL,'bold')
 c.text('تشبه حياتك',1008,668,99,PEARL,'bold')
 c.photo('interior',72,750,936,600)
 c.rect(1000,1441,8,114,COPPER)
 c.text('تفاصيل هادئة.',962,1484,44,PEARL)
 c.text('وحضور يترك أثره.',962,1555,44,PEARL)
 c.line(72,1600,1008,1600,MIST,.8)
 c.text('نموذج توضيحي — عبارة تحريرية مقترحة',1008,1650,18,PEARL)
 c.eyebrow('A SENSE OF HOME / 02',72,1650,PEARL,18)
 # Stable text IDs allow checking actual glyph bounds, including captions.
 c.items=[part.replace('<text x=',f'<text id="story-safe-text-{i}" x=') for i,part in enumerate(c.items)]
 c.save()
 SPECS['social-story']['safe_area_px']={'top':250,'bottom':250,'critical_content_y_min':250,'critical_content_y_max':1670}

def signage():
 c=Canvas('signage',2000,1000,'2000mm','1000mm',INK)
 c.photo('exterior',0,0,1095,1000)
 c.rect(1095,0,15,1000,MIST)
 c.logo(1615,78,275,'pearl')
 c.text('مساحة',1890,454,118,PEARL,'bold')
 c.text('تشبه حياتك',1890,596,118,PEARL,'bold')
 c.rect(1812,679,78,5,COPPER)
 c.text('تفاصيل هادئة وحضور واضح',1890,777,38,PEARL)
 c.line(1220,868,1890,868,MIST,1)
 c.eyebrow('ALDAYEL / RESIDENTIAL',1220,931,PEARL,24)
 c.text('نموذج توضيحي — صياغة مقترحة',1890,930,22,PEARL)
 c.save()

def property_card():
 c=Canvas('property-card',740,1050,'148mm','210mm')
 c.logo(458,42,230)
 c.eyebrow('RESIDENTIAL / PROPERTY CARD',48,60,size=13)
 c.line(48,86,285,86,INK,.8)
 c.text('بطاقة وحدة سكنية',688,250,48,weight='bold')
 c.text('المشروع',688,299,20)
 c.line(48,309,598,309,MIST,1)
 c.photo('exterior',48,340,644,355)
 # Deliberately empty fields: no unverified inventory, areas, prices or locations.
 for yy,label in [(750,'نوع الوحدة'),(818,'المساحة'),(886,'الموقع')]:
  c.text(label,688,yy,24)
  c.line(48,yy+23,692,yy+23,MIST,1)
 c.text('نموذج توضيحي — تُستكمل البيانات قبل النشر',688,998,16)
 c.save()

def presentation_cover():
 c=Canvas('presentation-cover',1600,900,'1600px','900px',INK)
 c.photo('exterior',0,0,860,900)
 c.rect(860,0,7,900,MIST)
 c.logo(1264,66,244,'pearl')
 c.text('مساحة',1508,373,101,PEARL,'bold')
 c.text('تشبه حياتك',1508,491,101,PEARL,'bold')
 c.line(954,580,1508,580,MIST,1)
 c.text('عرض تقديمي سكني',1508,650,36,PEARL)
 c.eyebrow('ALDAYEL / RESIDENTIAL',954,795,PEARL,18)
 c.text('نموذج توضيحي — صياغة مقترحة',1508,836,18,PEARL)
 c.save()

def presentation_detail():
 c=Canvas('presentation-detail',1600,900,'1600px','900px')
 c.eyebrow('ALDAYEL / RESIDENTIAL',70,66,size=16)
 c.logo(1286,38,244)
 c.text('التفاصيل تصنع الانطباع',1530,285,68,weight='bold')
 c.photo('interior',70,356,865,442)
 c.rect(1525,346,5,55,COPPER)
 c.text('مساحات للحياة',1492,390,35,weight='bold')
 c.text('ضوء طبيعي وخامات هادئة،',1492,467,27)
 c.text('ومساحات تمنح الحياة اتساعاً.',1492,513,27)
 c.line(1015,570,1530,570,MIST,1)
 c.text('وضوح في التفاصيل',1530,633,22,weight='bold')
 c.text('توازن بين الضوء والفراغ والخامة.',1530,681,27)
 c.text('صياغة تحريرية مقترحة',1530,729,17)
 c.text('نموذج توضيحي',1530,835,17)
 c.eyebrow('02 / PRESENTATION',70,853,size=16)
 c.save()

def flyer():
 c=Canvas('flyer',740,1050,'148mm','210mm',PEARL)
 c.logo(462,40,230)
 c.eyebrow('ALDAYEL / RESIDENTIAL',48,65,size=14)
 c.line(48,91,255,91,INK,.8)
 c.text('مساحة',690,280,66,weight='bold')
 c.text('تشبه حياتك',690,360,66,weight='bold')
 c.rect(48,253,4,86,COPPER)
 c.photo('interior',48,415,644,402)
 c.text('تفاصيل هادئة وحضور واضح',692,894,29)
 c.text('للتواصل',692,946,19)
 c.line(48,954,605,954,MIST,1)
 c.line(48,981,692,981,MIST,1)
 c.eyebrow('A SENSE OF HOME',48,1020,size=13)
 c.text('نموذج توضيحي — صياغة مقترحة',692,1020,14)
 c.save()

def rollup():
 c=Canvas('rollup',850,2000,'850mm','2000mm',PEARL)
 c.logo(570,85,210)
 c.eyebrow('ALDAYEL / RESIDENTIAL',70,112,size=18)
 c.line(70,145,345,145,INK,1)
 c.text('مساحة',780,434,94,weight='bold')
 c.text('تشبه حياتك',780,547,94,weight='bold')
 c.photo('exterior',70,649,710,762)
 c.rect(774,1490,6,111,COPPER)
 c.text('تفاصيل هادئة.',740,1536,43)
 c.text('وحضور يترك أثره.',740,1608,43)
 c.line(70,1708,780,1708,INK,1)
 c.text('نموذج توضيحي',780,1775,23)
 c.eyebrow('A SENSE OF HOME',70,1773,size=20)
 c.text('عبارة تحريرية مقترحة',780,1840,19)
 # Bottom 100mm intentionally free for roller cassette, per final supplier spec.
 c.save()

BUILDERS=[post,story,signage,property_card,presentation_cover,presentation_detail,flyer,rollup]

def validate_outputs():
 import fitz
 from PIL import ImageDraw
 reports=[]; tiles=[]
 original=ET.parse(str(ROOT/'assets/logos/residential/aldayel-primary-ar-ink.svg'))
 original_paths={p.get('d') for p in original.findall('.//{'+NS+'}path')}
 for name,spec in SPECS.items():
  editable=ET.parse(str(EDIT/f'{name}.svg')); outlined=ET.parse(str(OUT/f'{name}.svg'))
  doc=fitz.open(OUT/f'{name}.pdf'); page=doc[0]
  mm=spec['width'].endswith('mm'); ratio=72/25.4 if mm else .75
  expected=[float(spec['width'][:-2])*ratio,float(spec['height'][:-2])*ratio]
  q=subprocess.run(['inkscape',str(EDIT/f'{name}.svg'),'--query-all'],env=ENV,capture_output=True,text=True,check=True)
  boxes={}
  for line in q.stdout.splitlines():
   fields=line.split(',')
   if len(fields)==5:boxes[fields[0]]=list(map(float,fields[1:]))
  bx,by,bw,bh=boxes['primary-mark-'+name]
  lx,ly,lw,lh=boxes['residential-label-'+name]
  px_to_unit=25.4/96 if mm else 1
  actual_width=bw*px_to_unit
  required=45 if mm else 240
  label_gap=ly-by-bh
  page_css=[float(spec['width'][:-2])/(25.4/96 if mm else 1),float(spec['height'][:-2])/(25.4/96 if mm else 1)]
  edges=[bx,by,page_css[0]-bx-bw,page_css[1]-by-bh]
  ep={p.get('d') for p in editable.findall('.//{'+NS+'}path')}; op={p.get('d') for p in outlined.findall('.//{'+NS+'}path')}
  report={'name':name,'pdf_page_points':[page.rect.width,page.rect.height],'expected_page_points':expected,'size_verified':all(abs(a-b)<.05 for a,b in zip([page.rect.width,page.rect.height],expected)),'editable_text_elements':len(editable.findall('.//{'+NS+'}text')),'outlined_text_elements':len(outlined.findall('.//{'+NS+'}text')),'original_logo_paths_preserved_in_editable':original_paths<=ep,'original_logo_paths_preserved_in_outlined':original_paths<=op,'pdf_vector_drawing_count':len(page.get_drawings()),'pdf_raster_image_count':len(page.get_images()),'pdf_embedded_fonts':len(page.get_fonts()),'logo_size':{'unit':'mm' if mm else 'px','declared_viewbox_width':spec['logos'][0]['display_width'],'actual_artwork_width':actual_width,'actual_artwork_height':bh*px_to_unit,'minimum_full_primary_width':required,'minimum_width_pass':actual_width>=required,'required_H_over_4_clearspace':bh*px_to_unit/4,'actual_gap_to_residential_descriptor':label_gap*px_to_unit,'descriptor_clearspace_pass':label_gap>=bh/4,'page_edge_clearspace_pass':min(edges)>=bh/4},'visual_review_reference':'previews/'+name+'.png'}
  if name=='social-story':
   text_boxes={el.get('id'):boxes[el.get('id')] for el in editable.findall('.//{'+NS+'}text')}
   top=min([by]+[b[1] for b in text_boxes.values()])
   bottom=max([by+bh]+[b[1]+b[3] for b in text_boxes.values()])
   report['story_safe_area_check']={'required_y_min':250,'required_y_max':1670,'actual_critical_content_y_min':top,'actual_critical_content_y_max':bottom,'all_text_and_logo_pass':top>=250 and bottom<=1670,'text_element_count':len(text_boxes)}
   assert report['story_safe_area_check']['all_text_and_logo_pass'],report['story_safe_area_check']
  assert report['size_verified'] and report['outlined_text_elements']==0 and report['original_logo_paths_preserved_in_editable'] and report['original_logo_paths_preserved_in_outlined'],report
  assert all(report['logo_size'][k] for k in ['minimum_width_pass','descriptor_clearspace_pass','page_edge_clearspace_pass']),report
  reports.append(report)
  im=Image.open(PREVIEW/f'{name}.png').convert('RGB');im.thumbnail((370,640));tile=Image.new('RGB',(400,710),'#DDD');tile.paste(im,((400-im.width)//2,30));ImageDraw.Draw(tile).text((12,680),name,fill='black');tiles.append(tile)
 (OUT/'marketing-validation.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2))
 sheet=Image.new('RGB',(1600,1420),'white')
 for i,tile in enumerate(tiles):sheet.paste(tile,((i%4)*400,(i//4)*710))
 sheet.save(PREVIEW/'marketing-contact-sheet.jpg',quality=94)
 print('Validated all actual logo widths, descriptor clearspace, page dimensions, vectors and paths.',flush=True)

def run():
 for b in BUILDERS:b()
 (OUT/'marketing-manifest.json').write_text(json.dumps(SPECS,ensure_ascii=False,indent=2))
 # Process sequentially to avoid font cache races or surprise memory spikes.
 for name,spec in SPECS.items():
  src=EDIT/f'{name}.svg'; dst=OUT/f'{name}.svg'
  for args in [
   [str(src),'--export-text-to-path','--export-plain-svg',f'--export-filename={dst}'],
   [str(dst),'--export-text-to-path',f'--export-filename={OUT/f"{name}.pdf"}'],
   [str(dst),'--export-width=1000',f'--export-filename={PREVIEW/f"{name}.png"}'],
  ]:
   proc=subprocess.run(['inkscape',*args],env=ENV,text=True,capture_output=True)
   if proc.returncode:raise RuntimeError(proc.stderr)
  if spec['width'].endswith('px'):
   subprocess.run(['inkscape',str(dst),f'--export-width={int(spec["width"][:-2])}',f'--export-filename={OUT/f"{name}.png"}'],env=ENV,check=True,capture_output=True)
  tree=ET.parse(str(dst))
  assert not tree.findall('.//{'+NS+'}text'),f'Live text remains: {name}'
  print(f'Built {name}: editable SVG + outlined SVG + PDF + preview',flush=True)
 validate_outputs()

if __name__=='__main__':run()
