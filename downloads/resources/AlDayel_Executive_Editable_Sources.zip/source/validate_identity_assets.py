#!/usr/bin/env python3
"""Recheck unchanged logo geometry, embedded mockup logos and numeric color values.

Runs on the delivered source files. External original AI hashes are checked when
their recorded source paths are available. Missing external originals are reported
as unavailable, never silently marked as verified.
"""
from pathlib import Path
import argparse, base64, hashlib, json, re, xml.etree.ElementTree as ET
from PIL import Image, ImageCms

ROOT = Path(__file__).resolve().parent.parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def geometry(root):
    return [{'tag': e.tag.split('}')[-1], **{k: v for k, v in sorted(e.attrib.items())
            if k not in ('fill', 'stroke', 'class', 'style')}} for e in root.iter()
            if e.tag.split('}')[-1] in ('path', 'use')]


def paths(root):
    return [(e.get('d'), e.get('transform')) for e in root.iter() if e.tag.endswith('}path')]


def lum(rgb):
    vals = [x / 255 for x in rgb]
    return sum((v / 12.92 if v <= .04045 else ((v + .055) / 1.055) ** 2.4) * w
               for v, w in zip(vals, [.2126, .7152, .0722]))


def audit(root, profile):
    original_roots, originals, recolors, applications, textures = {}, [], [], [], []
    for item in json.loads((root / 'assets/logos/original/provenance.json').read_text()):
        p = root / 'assets/logos/original' / item['svg_file']
        r = ET.parse(p).getroot(); original_roots[item['variant']] = r
        geom_hash = hashlib.sha256(json.dumps(geometry(r), ensure_ascii=False,
                                    separators=(',', ':')).encode()).hexdigest()
        src = Path(item['source'])
        originals.append({'variant': item['variant'],
            'original_svg_hash_pass': sha(p) == item['svg_sha256'],
            'original_geometry_hash_pass': geom_hash == item['geometry_sha256'],
            'original_AI_file_present': src.is_file(),
            'original_AI_hash_pass': sha(src) == item['source_sha256'] if src.is_file() else None})
    recolor_files = list((root / 'assets/logos/residential').glob('*.svg'))
    recolor_bytes = {p.name: p.read_bytes() for p in recolor_files}
    for p in recolor_files:
        variant = p.stem[8:].rsplit('-', 1)[0]
        r = ET.parse(p).getroot(); original = original_roots[variant]
        recolors.append({'file': p.name, 'geometry_unchanged': geometry(r) == geometry(original),
                         'viewBox_unchanged': r.get('viewBox') == original.get('viewBox')})
    for folder in ['applications/editable', 'applications']:
        for p in (root / folder).glob('*.svg'):
            marks = []
            for el in ET.parse(p).getroot().iter():
                variant = el.get('data-original-variant')
                if el.get('aria-label') == 'Original complete AlDayel logo, unmodified geometry':
                    variant = 'primary-ar'
                if not variant: continue
                row = {'variant': variant, 'path_geometry_unchanged': paths(el) == paths(original_roots[variant]),
                       'transform': el.get('transform')}
                if el.tag.endswith('}svg'):
                    vb = [float(x) for x in el.get('viewBox').split()]
                    row['uniform_scale'] = abs(float(el.get('width')) / float(el.get('height')) - vb[2] / vb[3]) < 1e-5
                elif row['transform']:
                    row['uniform_scale'] = 'scale(' in row['transform'] and not re.search(r'scale\([^)]*[, ]', row['transform'])
                marks.append(row)
            applications.append({'file': str(p.relative_to(root)), 'logos': marks})
    for p in (root / 'source/mockups/textures').glob('*.svg'):
        marks = []
        for el in ET.parse(p).getroot().iter():
            href = el.get('href', el.get('{http://www.w3.org/1999/xlink}href', ''))
            if href.startswith('data:image/svg+xml;base64,'):
                embedded = base64.b64decode(href.split(',', 1)[1])
                matched = [name for name, content in recolor_bytes.items() if content == embedded]
                marks.append({'embedded_logo_matches_exact_source': bool(matched), 'matched_files': matched})
        textures.append({'file': str(p.relative_to(root)), 'embedded_logos': marks})
    tokens = json.loads((root / 'assets/design-tokens.json').read_text())
    color = {'profile_available': profile.is_file(), 'colors': [], 'contrast': []}
    transform = None
    if profile.is_file():
        icc = ImageCms.getOpenProfile(str(profile))
        transform = ImageCms.buildTransformFromOpenProfiles(ImageCms.createProfile('sRGB'), icc,
                                                           'RGB', 'CMYK', renderingIntent=1)
        color.update(profile=ImageCms.getProfileDescription(icc).strip(), profile_sha256=sha(profile),
                     intent_value=1, intent='relative colorimetric')
    for col in tokens['colors']:
        rgb = list(bytes.fromhex(col['hex'][1:]))
        row = {'name': col['name_en'], 'hex': col['hex'], 'rgb_computed': rgb, 'rgb_pass': rgb == col['rgb']}
        if transform:
            values = ImageCms.applyTransform(Image.new('RGB', (1, 1), tuple(rgb)), transform).getpixel((0, 0))
            computed = [round(v / 255 * 100) for v in values]
            row.update(cmyk_8bit=list(values), cmyk_computed_percent=computed, cmyk_pass=computed == col['cmyk'])
        color['colors'].append(row)
    for i, a in enumerate(tokens['colors']):
        for b in tokens['colors'][i+1:]:
            low, high = sorted([lum(a['rgb']), lum(b['rgb'])])
            color['contrast'].append({'foreground': a['name_en'], 'background': b['name_en'],
                                      'ratio': round((high + .05) / (low + .05), 2)})
    return {'original_logos': originals, 'recolored_logos': recolors, 'applications': applications,
            'mockup_textures': textures, 'color_conversion': color,
            'scope_note': 'Source geometry and placement scale inspection; raster mockup appearance and surface perspective require separate visual review.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--icc', type=Path, default=Path('/usr/share/color/icc/ghostscript/default_cmyk.icc'))
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = audit(args.root, args.icc)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(json.dumps({'report': str(args.output), 'originals': len(report['original_logos']),
                      'recolors': len(report['recolored_logos']), 'application_files': len(report['applications'])}))
