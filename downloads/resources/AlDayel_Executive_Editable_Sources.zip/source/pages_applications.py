"""Executive application pages 12–19. Live editorial text + official vector art.

Every displayed specimen is an illustration of a source application, not a
production template. See applications/ for full editable dimensions.
"""


def build(ctx):
    pages = []
    pages.append(ctx.page(12, 'القرطاسية المؤسسية', f'''
      <div class="safe">{ctx.heading('تفاصيل تصنع الثقة', 'CORRESPONDENCE / 01')}
        <p class="app12-intro">هوية واحدة، من أول تعارف إلى كل مراسلة.</p>
      </div>
      <div class="app12-card-front paper">{ctx.art('business-card-front', width_mm=90)}</div>
      <div class="app12-card-back paper">{ctx.art('business-card-back', width_mm=90)}</div>
      <p class="app12-card-note caption">بطاقة العمل {ctx.ltr('90 × 55 mm')} · رمز QR تجريبي بهامش أربع وحدات؛ تُعتمد وجهته ويُختبر قبل الإنتاج.</p>
      <div class="app12-letter paper">{ctx.art('letterhead', width_mm=81)}</div>
      <div class="app12-env c4 paper">{ctx.art('envelope-c4', width_mm=100)}</div>
      <div class="app12-env c5 paper">{ctx.art('envelope-c5', width_mm=88)}</div>
      <div class="app12-env dl paper">{ctx.art('envelope-dl', width_mm=100)}</div>
      <p class="app12-letter-note caption">ورق المراسلات<br>{ctx.ltr('A4 · 210 × 297 mm')}</p>
      <div class="app12-envelopes-note caption">الأظرف: {ctx.ltr('DL 220 × 110')}<br>{ctx.ltr('C5 229 × 162 · C4 324 × 229 mm')}</div>
    ''', 'app12'))

    pages.append(ctx.page(13, 'اللافتات والواجهات', f'''
      {ctx.photo('concept-entrance-portrait.png', 'app13-photo')}
      <div class="app13-plaque-logo">{ctx.logo(color='pearl', width_mm=15.40)}</div>
      <div class="app13-editorial">
        <div class="kicker">ARRIVAL / 02</div>
        <h1>علامة تعرف مكانها</h1>
        <p>حضور واضح، بحجم ينسجم مع العمارة.</p>
        <div class="app13-flat">{ctx.art('signage', width_mm=57)}</div>
        <p class="caption app13-spec">لافتة عقارية {ctx.ltr('2000 × 1000 mm')}<br>مشهد تصوّري؛ يُضبط الحجم حسب مسافة الرؤية.</p>
      </div>
    ''', 'app13'))

    pages.append(ctx.page(14, 'المطبوعات العقارية', f'''
      <div class="app14-title">{ctx.heading('الهوية بين الصفحات', 'PROPERTY EDITIONS / 03')}</div>
      <div class="app14-outside paper">{ctx.art('brochure-outside', width_mm=141)}</div>
      <div class="app14-inside paper">{ctx.art('brochure-inside', width_mm=141)}</div>
      <div class="app14-folder paper">{ctx.art('folder', width_mm=42)}</div><div class="app14-pocket-detail paper"><div class="app14-pocket-source">{ctx.art('folder-pocket', width_mm=42)}</div></div>
      <div class="app14-folder-caption caption">حافظة الملفات · {ctx.ltr('A4')}<br>الغلاف والجيب الداخلي</div><div class="app14-presentation-cover">{ctx.art('presentation-cover', width_mm=48)}</div><div class="app14-presentation-detail">{ctx.art('presentation-detail', width_mm=48)}</div><p class="app14-presentation-caption caption">عرض تقديمي<br>الغلاف والصفحة الداخلية<br>{ctx.ltr('1600 × 900 px')}</p>
      <p class="app14-outside-caption caption">بروشور ثلاثي الطي · الوجه الخارجي</p>
      <p class="app14-inside-caption caption">الوجه الداخلي · {ctx.ltr('A4 / 297 × 210 mm')}</p>
    ''', 'app14'))

    pages.append(ctx.page(15, 'العرض والمعاملة', f'''
      <div class="safe">{ctx.heading('من العرض إلى التفاصيل', 'OFFER & DOCUMENTATION / 04')}</div>
      <div class="app15-property paper">{ctx.art('property-card', width_mm=110)}</div>
      <p class="app15-property-caption caption">بطاقة الوحدة · {ctx.ltr('148 × 210 mm')}<br>حقول واضحة للمشروع، ونوع الوحدة، والمساحة، والموقع.</p>
      <div class="app15-form voucher">
        <div class="caption form-label">سند قبض · {ctx.ltr('A5')}</div>
        <div class="form-detail paper"><div class="form-source">{ctx.art('payment-voucher', width_mm=112.5)}</div></div>
      </div>
      <div class="app15-form receipt">
        <div class="caption form-label">إيصال استلام · {ctx.ltr('A5')}</div>
        <div class="form-detail paper"><div class="form-source">{ctx.art('receipt', width_mm=112.5)}</div></div>
      </div>
      <div class="app15-form quotation">
        <div class="caption form-label">عرض سعر · {ctx.ltr('A4')}</div>
        <div class="form-detail paper"><div class="form-source">{ctx.art('quotation', width_mm=112.5)}</div></div>
      </div>
      <div class="app15-stamp">{ctx.art('stamp', width_mm=55)}</div>
      <p class="app15-stamp-caption caption">ختم أحادي اللون<br>{ctx.ltr('55 × 30 mm')}</p>
      <p class="app15-note caption">تفاصيل مكبّرة من النماذج. تبقى البيانات المالية والتجارية فارغة حتى اعتمادها.</p>
    ''', 'app15'))

    pages.append(ctx.page(16, 'وسائل التواصل الاجتماعي', f'''
      <div class="safe">{ctx.heading('حضور رقمي متّسق', 'SOCIAL PRESENCE / 05')}</div>
      <div class="app16-story">{ctx.art('social-story', width_mm=68)}</div>
      <div class="app16-post">{ctx.art('social-post', width_mm=108)}</div>
      <p class="app16-story-label caption">قصة<br>{ctx.ltr('1080 × 1920 px')}</p>
      <p class="app16-post-label caption">منشور<br>{ctx.ltr('1080 × 1350 px')}</p>
      <div class="app16-rule"><span class="en">250 px</span><p>مساحة أمان تقريبية أعلى القصة وأسفلها؛ تُراجع مع واجهة المنصة.</p></div>
      <p class="app16-note caption">رسالة واحدة، وصورة تقود التكوين. نماذج تصوّرية بمحتوى غير تجاري.</p>
    ''', 'app16'))

    pages.append(ctx.page(17, 'التجربة الرقمية والحركة', f'''
      <div class="safe">{ctx.heading('تجربة هادئة وواضحة', 'DIGITAL EXPERIENCE / 06')}</div>
      <div class="app17-site">
        <div class="site-nav">
          {ctx.logo(width_mm=43)}
          <div class="site-links"><span>المساحات</span><span>التفاصيل</span><span>تواصل</span></div>
        </div>
        <div class="site-hero">
          <div class="site-copy"><span class="site-eyebrow">الدايل السكني</span><h2>مساحة<br>تشبه حياتك</h2><p>تفاصيل هادئة.<br>وخطوة تبدأ بالوضوح.</p><span class="site-cta">اكتشف المساحات <b>←</b></span></div>
          {ctx.photo('concept_residential_interior.png', 'site-image')}
        </div>
        <div class="site-bottom"><span>مساحات للحياة</span><span>ضوء طبيعي · خامات واضحة · حضور متّزن</span></div>
      </div>
      <p class="app17-site-note caption">واجهة تصوّرية لتطبيق الهوية؛ ليست موقعًا أو نظامًا منشورًا.</p>
      <div class="app17-motion-title"><h2>العلامة في الحركة</h2></div>
      <div class="app17-motion-strip">
        <figure><img src="../motion/stills/motion-0p25s.png" alt="الشعار عند ربع ثانية"><figcaption class="en">0.25 s</figcaption></figure>
        <figure><img src="../motion/stills/motion-1s.png" alt="الشعار عند ثانية"><figcaption class="en">1.00 s</figcaption></figure>
        <figure><img src="../motion/stills/motion-5p5s.png" alt="الشعار عند خمس ثوان ونصف"><figcaption class="en">5.50 s</figcaption></figure>
      </div>
      <p class="app17-motion-note caption">ظهور تدريجي وإزاحة خفيفة للشعار كوحدة واحدة، مع نسخة ثابتة لتقليل الحركة.<br>{ctx.ltr('6 s · 24 fps · 1920 × 1080 · H.264 · Silent')}</p>
    ''', 'app17'))

    pages.append(ctx.page(18, 'الحملات الإعلانية', f'''
      <div class="safe">{ctx.heading('رسالة تستحق الانتباه', 'CAMPAIGNS / 07')}</div>
      <div class="app18-flyer paper">{ctx.art('flyer', width_mm=125)}</div>
      <div class="app18-rollup paper">{ctx.art('rollup', width_mm=62)}</div>
      <p class="app18-flyer-label caption">فلاير · {ctx.ltr('A5 / 148 × 210 mm')}</p>
      <p class="app18-rollup-label caption">رول أب<br>{ctx.ltr('850 × 2000 mm')}</p>
      <p class="app18-note">صورة واحدة. عنوان مباشر. ومساحة كافية للرسالة.</p>
      <p class="app18-production caption">نموذجان تصوّريان؛ تُراجع قوالب المورد ودقّة الصور عند الحجم الفعلي قبل الإنتاج.</p>
    ''', 'app18'))

    pages.append(ctx.page(19, 'الهوية في الواقع', f'''
      {ctx.photo('executive-material-scene.png', 'app19-photo')}
      <div class="app19-editorial"><div class="kicker">THE MATERIAL EXPERIENCE / 08</div><h1>حضور في كل تفصيل</h1>
      <p>أكياس، علب، أكواب وملصقات — تصوّر تطبيقي.</p>
      </div><p class="app19-production caption">واجهات تصميمية؛ تُعتمد قوالب القص والخامات مع المورد.</p>
    ''', 'app19'))
    return pages
