#!/usr/bin/env python3
"""Measure logo deformation in the exported PDF, independent of SVG source checks.

Matches complete original path topology, fits all curve control points to the
original PDF, then reports anisotropic scale/shear and affine residual. Examples
on the guide's incorrect-use page are deliberately reported, not silently omitted.
"""
from pathlib import Path
import argparse, hashlib, json
import fitz
import numpy as np

ROOT = Path(__file__).resolve().parent.parent


def signature(drawings):
    return [tuple(item[0] for item in drawing['items']) for drawing in drawings]


def points(drawings):
    vals = []
    for drawing in drawings:
        for item in drawing['items']:
            for value in item[1:]:
                if isinstance(value, fitz.Point):
                    vals.append([value.x, value.y])
                elif isinstance(value, fitz.Rect):
                    vals.extend([[value.x0, value.y0], [value.x1, value.y0],
                                 [value.x1, value.y1], [value.x0, value.y1]])
                elif isinstance(value, fitz.Quad):
                    vals.extend([[p.x, p.y] for p in value])
    return np.array(vals, dtype=float)


def fit(original, target):
    assert original.shape == target.shape
    matrix = np.linalg.lstsq(np.c_[original, np.ones(len(original))], target, rcond=None)[0]
    error = np.c_[original, np.ones(len(original))] @ matrix - target
    linear = matrix[:2].T
    singular = np.linalg.svd(linear, compute_uv=False)
    sx, sy = np.linalg.norm(linear[:, 0]), np.linalg.norm(linear[:, 1])
    x, y = original - original.mean(0), target - target.mean(0)
    u, s, vt = np.linalg.svd(x.T @ y)
    rotation = u @ vt
    scale = s.sum() / (x*x).sum()
    similarity_error = x @ rotation * scale - y
    return {
        'point_count': len(original),
        'linear_matrix': linear.tolist(), 'translation': matrix[2].tolist(),
        'scale_x': float(sx), 'scale_y': float(sy), 'scale_x_over_y': float(sx/sy),
        'axis_dot_normalized': float(np.dot(linear[:,0], linear[:,1])/(sx*sy)),
        'singular_values': singular.tolist(),
        'anisotropy_percent': float((singular.max()/singular.min()-1)*100),
        'affine_rms_error_pt': float(np.sqrt((error*error).mean())),
        'affine_max_error_pt': float(np.linalg.norm(error, axis=1).max()),
        'similarity_rms_error_pt': float(np.sqrt((similarity_error*similarity_error).mean())),
    }


def audit(pdf, originals, allow_optimized=False):
    source = []
    for p in originals.glob('*-original.pdf'):
        doc = fitz.open(p); drawings = doc[0].get_drawings()
        source.append({'variant': p.stem[8:-9], 'signature': signature(drawings),
                       'points': points(drawings), 'drawings': drawings, 'path_count': len(drawings)})
    source.sort(key=lambda item: item['path_count'], reverse=True)
    doc = fitz.open(pdf); records = []
    for pn, page in enumerate(doc, 1):
        drawings = page.get_drawings(); sig = signature(drawings); occupied = set()
        for src in source:
            count = src['path_count']
            for pos in range(len(sig)-count+1):
                indices = set(range(pos, pos+count))
                if indices & occupied:
                    continue
                matched = [i for i in range(count) if sig[pos+i] == src['signature'][i]]
                if len(matched) != count and not (allow_optimized and count >= 18 and len(matched)/count >= .9):
                    continue
                subset = drawings[pos:pos+count]
                target = points([subset[i] for i in matched])
                original_points = points([src['drawings'][i] for i in matched])
                if target.shape != original_points.shape: continue
                result = fit(original_points, target)
                # Exact topology can occasionally be shared by another decorative
                # path; residual explicitly reveals such cases for human review.
                box = fitz.Rect()
                for d in subset: box |= d['rect']
                records.append({'page': pn, 'variant': src['variant'], 'drawing_start': pos,
                    'path_count': count, 'matched_path_count': len(matched),
                    'full_topology_match': len(matched) == count,
                    'omitted_path_indices': [i for i in range(count) if i not in matched],
                    'bbox_pt': list(box), 'width_mm': box.width*25.4/72,
                    'height_mm': box.height*25.4/72, **result})
                occupied |= indices
    return {'file': pdf.name, 'sha256': hashlib.sha256(pdf.read_bytes()).hexdigest(),
            'method': 'Exact ordered path-topology match; least-squares affine fit on every endpoint and Bezier control point against original PDF. Singular-value ratio detects nonuniform scale/shear. Nested wordmark/icon matches within a complete logo are not counted twice.',
            'limitations': 'Does not see logos flattened into photos or raster mockups. Deliberate incorrect-use examples need separate interpretation. A source SVG geometry pass does not guarantee uniform scaling in the exported PDF.',
            'records': records}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pdf', type=Path)
    parser.add_argument('--originals', type=Path, default=ROOT/'assets/logos/original')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--allow-optimized-paths', action='store_true',
        help='Fit shared points when >=90%% of path signatures match (native application exports only). Report omitted paths explicitly.')
    args = parser.parse_args(); result = audit(args.pdf, args.originals, args.allow_optimized_paths)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2))
    print(json.dumps({'records': len(result['records']), 'output': str(args.output),
        'max_anisotropy_percent_excluding_page15': max((r['anisotropy_percent'] for r in result['records'] if r['page'] != 15), default=None)}))
