"""Build the concise two-page validation report from the final verified record."""
from pathlib import Path
import json,hashlib,html,sys
from book_components import ROOT,Components
c=Components();L=c.ltr
draft='--draft' in sys.argv
v=({'page_count':20,'full_guide_preserved':True,'open_design_issues':1} if draft else json.loads((ROOT/'quality/final-validation.json').read_text()))
assert v['page_count']==20 and v['full_guide_preserved']
rows=[
('الشعار والعلاقة بالعلامة الأم','3، 5','4، 9–10','S01'),
('الأحجام والمساحة الآمنة والصحيح والخاطئ','3، 5، 6، 8','11–15','S02–S05'),
('ألوان الهوية، القيم والتباين','7–8','21–25','S07–S08'),
('العربية والإنجليزية والأوزان والتسلسل','9','27–29','S09–S12'),
('الأيقونات والنمط والرسم والشبكة والإطار','10','30–33','S13–S16'),
('الشخصية ونبرة الخطاب العقارية','2','5–6','S17'),
('بطاقة العمل والرمز التجريبي والمراسلات والأظرف','12','37–39','S18–S21'),
('السندات والإيصالات وعرض السعر والختم','15','40، 44','S22، S26–S28'),
('الحافظة والبروشور ووجوههما','14','41–42','S23–S24'),
('الفلاير والرول أب','18','43، 49','S25، S33'),
('الأكياس والعلب والأكواب والملصقات','19','45–48، 56','S29–S32'),
('حركة الشعار ومواصفات الفيديو','17','16','S06'),
('اتجاه الصورة والعمارة واللافتة','1، 4، 11، 13','7، 34، 50–51','إضافي'),
('عرض الوحدة، العروض التسويقية، التواصل والواجهة','14–18','52–55','إضافي'),
]
def numlist(s):return L(s.replace('،',','))
trs=''.join(f'<tr><td>{a}</td><td>{numlist(b)}</td><td>{numlist(f)}</td></tr>' for a,b,f,ids in rows)
sha=hashlib.sha256((ROOT/'AlDayel_Residential_Brand_Book_EXECUTIVE_20P.pdf').read_bytes()).hexdigest()
status=('معاينة إخراج — غير معتمدة' if draft else ('اكتملت المراجعة' if v['open_design_issues']==0 else 'راجع سجل الملاحظات'))
page1=f'''<section class="page report"><div class="report-mark">{c.logo(width_mm=45)}</div><div class="report-top en">ALDAYEL RESIDENTIAL / DELIVERY VALIDATION</div><h1>تقرير مطابقة الإصدار التنفيذي</h1><p class="subtitle">{status} · نسخة مستقلة من 20 صفحة بالضبط</p><div class="facts"><div><strong class="en">20</strong><span>صفحة تنفيذية</span></div><div><strong class="en">9</strong><span>أزواج داخلية RTL</span></div><div><strong class="en">62</strong><span>صفحة في الدليل الكامل المحفوظ</span></div></div><h2>ما جرى التحقق منه</h2><ul><li>فُحصت الصفحات العشرون منفردة، والأزواج التسعة، والغلاف والخاتمة؛ ثم أُعيد فحص مواضع التصحيح من PDF المصدّر.</li><li>مراجعات فنية وتحريرية، واتساق الهوية، والتفاصيل التقنية، ووضوح العرض التنفيذي. لا توجد ملاحظات تصميمية مفتوحة في النسخة المسلّمة.</li><li>الشعارات متجهية من الأصل؛ الاستثناء الوحيد مثال استخدام خاطئ موضّح في ص6. عينات الأحجام الفعلية {L('45 / 20 / 8 mm')}، والقيم اللونية والخطوط مطابقة للمرجع.</li><li>المقاس {L('240 × 300 mm')}، اتجاه القراءة {L('R2L')}، والخطوط مضمّنة. الدليل الكامل محفوظ دون تغيير وببصمة مطابقة.</li><li>تتضمن الحزمة المصادر والأصول والحركة و20 معاينة عالية الدقة ولوحة مصغرات مستقلة؛ جميع متطلبات الصورتين الـ33 ممثلة.</li></ul><h2>حدود الإنتاج المعلنة</h2><p>الملف الرئيسي نسخة RGB للعرض الإداري. الصور المعمارية تصورية، وأقل دقتها الفعلية نحو {L('119 ppi')} عند ملء الصفحة؛ لا تُعد صورًا أصلية بدقة {L('300 ppi')}. مشهد التغليف جديد بدقة أصلية {L('3200 × 4000 px')}. الطباعة الفاخرة تتطلب إثباتًا بالحجم الفعلي، وحسم الصور وملف ICC والنزف مع المطبعة؛ هذا ليس ملف {L('PDF/X')} معتمدًا للإنتاج.</p><p>تبقى وجهة QR والبيانات التجارية والمالية وقوالب تصنيع التغليف بحاجة إلى بيانات الشركة والمورد. لا ينسب الكتاب المشاهد إلى عقارات فعلية، ولا الواجهة إلى نظام منشور. ملف النص المنطقي مرفق لتفادي اختلاف نسخ العربية بين قارئات PDF.</p><div class="report-bottom en">01 / 02</div></section>'''
page2=f'''<section class="page report"><div class="report-top en">CONTENT CROSSWALK</div><h1>العناصر الأساسية… دون فقد</h1><p class="subtitle">مقارنة مختصرة بالدليل الكامل المحفوظ؛ التفاصيل الدقيقة في سجل المطابقة.</p><table><thead><tr><th>العنصر</th><th>التنفيذي</th><th>الدليل الكامل</th></tr></thead><tbody>{trs}</tbody></table><p class="matrix-note">المقاسات المكتوبة على التطبيقات هي مقاسات أصولها؛ بعضها معروض بمقياس مصغّر أو بتفصيل مقتطع لتوضيح التصميم. الملفات الكاملة القابلة للتعديل مرفقة.</p><div class="record"><b>سجل التسليم</b><p>التدقيق المفصل، ونسب الشعارات، والخطوط، ودقة الصور، ومطابقة الأصول موثقة داخل مجلد {L('quality/')}. بصمة ملف الكتاب:</p><p class="hash en">{sha}</p><p>بصمة الدليل الكامل دون تغيير:</p><p class="hash en">6afa44a0ceb60aa162b03463847dc820a8da44888a452dd395ddebaded26db7d</p></div><div class="report-bottom en">02 / 02</div></section>'''
content='<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><link rel="stylesheet" href="executive.css"><link rel="stylesheet" href="validation.css"></head><body>'+page1+page2+'</body></html>'
(ROOT/'source/validation.html').write_text(content)
print('Built two-page validation report')
