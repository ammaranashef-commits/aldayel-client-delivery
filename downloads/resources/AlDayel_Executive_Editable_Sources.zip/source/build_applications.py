#!/usr/bin/env python3
"""Build editable stationery/packaging SVGs plus reliable outlined SVG/PDF exports.
Requirements and rebuild instructions: source/README-applications.md.
Original logo paths are included unchanged inside uniformly scaled nested SVGs.
"""
from pathlib import Path
from xml.etree import ElementTree as ET
import html,json,os,subprocess,sys,base64,copy
from application_environment import ROOT,WORK,configure_fonts
import qrcode
OUT=ROOT/'applications';EDIT=OUT/'editable';PRE=OUT/'previews'
for d in [OUT,EDIT,PRE]:d.mkdir(parents=True,exist_ok=True)
INK='#1C3549';PEARL='#F4F3EF';MIST='#CCDDE4';COPPER='#A96B53';WHITE='#FFFFFF'
FONT='Helvetica Neue LT Arabic';EN='PT Sans'
QR_PAYLOAD='ALDAYEL RESIDENTIAL - DESIGN SAMPLE - NOT A LIVE LINK'
manifest=[];counter=0
NS='http://www.w3.org/2000/svg';ET.register_namespace('',NS)
ENV=configure_fonts('applications')
def esc(s):return html.escape(str(s),quote=True)
def rect(x,y,w,h,c=INK,r=0,stroke=None,sw=.25):return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{c}"'+(f' stroke="{stroke}" stroke-width="{sw}"' if stroke else '')+'/>'
def line(x1,y1,x2,y2,c=INK,sw=.25,op=1):return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{c}" stroke-width="{sw}" opacity="{op}"/>'
def ar(s,x,y,fs=3.5,c=INK,bold=False,anchor='start'):
 return f'<text x="{x}" y="{y}" font-family="{FONT}" font-size="{fs}" font-weight="{700 if bold else 400}" fill="{c}" direction="rtl" unicode-bidi="embed" text-anchor="{anchor}">{esc(s)}</text>'
def en(s,x,y,fs=2.8,c=INK,bold=False,anchor='start'):
 return f'<text x="{x}" y="{y}" font-family="{EN}" font-size="{fs}" font-weight="{700 if bold else 400}" fill="{c}" text-anchor="{anchor}">{esc(s)}</text>'
def logo(x,y,w=36,color='ink',kind='primary-ar',branch=True,branch_size=None):
 global counter
 counter+=1
 p=ROOT/f'assets/logos/residential/aldayel-{kind}-{color}.svg';el=ET.parse(p).getroot()
 vb=[float(n) for n in el.attrib['viewBox'].split()];h=w*vb[3]/vb[2]
 prefix=f'appmark{counter}_'
 for sub in el.iter():
  for k,v in list(sub.attrib.items()):
   if k=='id':sub.set(k,prefix+v)
   elif 'url(#' in v:sub.set(k,v.replace('url(#','url(#'+prefix))
 el.set('id',f'original-mark-{counter}');el.set('data-original-variant',kind);el.set('x',str(x));el.set('y',str(y));el.set('width',str(w));el.set('height',str(h))
 result=ET.tostring(el,encoding='unicode')
 if branch:
  fs=branch_size or max(2.3,w*.08)
  result+=ar('السكني',x+w/2,y+h+h/4+fs*.9,fs,{'ink':INK,'pearl':PEARL,'mist':MIST,'copper':COPPER,'black':'#000000'}[color],False,'middle').replace('<text ',f'<text id="descriptor-{counter}" ',1)
 return result

def motif(x,y,w,h,c=MIST,sw=.35):
 # Architectural linework is a supporting frame, never a substitute mark.
 return f'<g fill="none" stroke="{c}" stroke-width="{sw}"><path d="M{x} {y+h} V{y+h*.34} L{x+w*.45} {y} H{x+w} V{y+h}"/><path d="M{x+w*.12} {y+h} V{y+h*.46} L{x+w*.47} {y+h*.21} H{x+w*.87} V{y+h}"/></g>'
def qr(x,y,w=20):
 q=qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M,box_size=1,border=4);q.add_data(QR_PAYLOAD);q.make(fit=True);m=q.get_matrix();n=len(m);u=w/n
 d=[]
 for yy,row in enumerate(m):
  for xx,val in enumerate(row):
   if val:d.append(f'M{x+xx*u:.5f},{y+yy*u:.5f}h{u:.5f}v{u:.5f}h-{u:.5f}z')
 return rect(x,y,w,w,WHITE)+f'<path d="{"".join(d)}" fill="{INK}"/>'
def image(path,x,y,w,h):
 data=base64.b64encode(Path(path).read_bytes()).decode()
 return f'<svg x="{x}" y="{y}" width="{w}" height="{h}" viewBox="0 0 {w} {h}" overflow="hidden"><image width="{w}" height="{h}" preserveAspectRatio="xMidYMid slice" href="data:image/png;base64,{data}"/></svg>'
def note(w,h,label='نموذج توضيحي',color=INK):return ar(label,w-10,h-7,2.5,color)
def save(name,w,h,content,description,unit='mm'):
 svg=f'''<?xml version="1.0" encoding="UTF-8"?><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{w}{unit}" height="{h}{unit}" viewBox="0 0 {w} {h}" version="1.1"><title>{esc(description)}</title><desc>AlDayel Residential concept application. Original logo vector geometry preserved. Illustrative fields only. Live editable text; locally licensed fonts required.</desc>{content}</svg>'''
 (EDIT/(name+'.svg')).write_text(svg)
 manifest.append(dict(name=name,width=w,height=h,unit=unit,description=description,editable='editable/'+name+'.svg',svg=name+'.svg',pdf=name+'.pdf',illustrative=True))

def header(w,h,title,english,subtitle=None):
 z=rect(0,0,w,h,PEARL)+logo(w-61,15,46)+en('ALDAYEL / RESIDENTIAL',15,22,2.5)+line(15,31,34,31,COPPER,.8)
 z+=ar(title,w-15,58,7,INK,True)+en(english.upper(),15,58,3)
 if subtitle:z+=ar(subtitle,w-15,70,3.3)
 return z

def field(label,x,y,w,fs=3.4):
 return ar(label,x+w,y,fs)+line(x,y+4,x+w,y+4,MIST,.4)

def bodytext(lines,x,y,fs=3.4,leading=7,color=INK):return ''.join(ar(s,x,y+i*leading,fs,color) for i,s in enumerate(lines))

def build():
 # Business card, exact 90x55mm; intentionally spacious two-sided system.
 z=rect(0,0,90,55,INK)+motif(2,3,10,49,'#385365',.24)+logo(22,8,46,'pearl',branch_size=3.2)+en('ALDAYEL RESIDENTIAL',45,45,2.15,PEARL,anchor='middle')+line(40,49,50,49,COPPER,.65)
 save('business-card-front',90,55,z,'بطاقة العمل — الوجه الأمامي 90×55 مم')
 z=rect(0,0,90,55,PEARL)+ar('الاسم',82,12,3.3,INK,True)+line(42,15,82,15,MIST,.3)+ar('المسمى الوظيفي',82,22,2.7)+line(42,25,82,25,MIST,.3)+ar('البريد الإلكتروني',82,32,2.6)+line(42,35,82,35,MIST,.3)+ar('رقم التواصل',82,42,2.6)+line(42,45,82,45,MIST,.3)+qr(5,10,23)+ar('رمز تجريبي',16.5,37,2.1,INK,anchor='middle')+note(90,55)
 save('business-card-back',90,55,z,'بطاقة العمل — الوجه الخلفي، بيانات ورمز تجريبي')
 # Correspondence.
 z=header(210,297,'مراسلات','Correspondence')+field('التاريخ',128,82,67)+field('المرجع',15,82,90)
 z+=field('إلى',15,106,180,4)+field('الموضوع',15,122,180,4)
 z+=ar('تحية طيبة،',195,143,4)
 z+=ar('وتفضلوا بقبول التحية،',195,212,4)+field('الاسم والتوقيع',120,236,75)+line(15,267,195,267,MIST,.4)+ar('بيانات الاتصال',195,278,3)+line(95,282,195,282,MIST,.3)+en('ALDAYEL RESIDENTIAL',15,278,2.7)+note(210,297)
 save('letterhead',210,297,z,'ورق مراسلات A4 — نموذج فارغ قابل للتعديل')
 for name,w,h in [('envelope-dl',220,110),('envelope-c5',229,162),('envelope-c4',324,229)]:
  lgw=46 if w<300 else 50;z=rect(0,0,w,h,PEARL)+rect(0,0,w,3,INK)+logo(14,14,lgw)+motif(14,h*.51,34,h*.31,MIST,.35)
  z+=field('المستلم',w-100,h*.52,83,4.2)+field('عنوان التسليم',w-100,h*.52+16,83,3.5)
  z+=en('ALDAYEL RESIDENTIAL',14,h-14,3)+note(w,h)
  save(name,w,h,z,f'ظرف {name.split("-")[-1].upper()} — واجهة {w}×{h} مم')
 # Payments and receipt intentionally have separate semantic labels.
 for name,title,eng,received in [('payment-voucher','سند قبض','Receipt voucher',False),('receipt','إيصال استلام','Payment receipt',True)]:
  w,h=210,148 # A5 landscape: more room for signing and practical fields.
  z=rect(0,0,w,h,PEARL)+logo(149,10,46,branch_size=2.8)+ar(title,140,27,7,INK,True)+en(eng.upper(),15,23,2.5)+line(15,31,44,31,COPPER,.7)
  z+=field('رقم السند' if name=='payment-voucher' else 'رقم الإيصال',113,49,82)+field('التاريخ',15,49,82)
  z+=field('استلمنا من',15,66,180)+field('المبلغ والعملة',15,83,180)
  z+=field('مقابل',15,100,116)+field('طريقة الدفع',141,100,54,3)
  z+=field('المستلم — الاسم والتوقيع',113,124,82,3.2)+field('المدقق — الاسم والتوقيع',15,124,82,3.2)+note(w,h)
  save(name,w,h,z,f'{title} — A5 أفقي، غير معد كنموذج محاسبي معتمد')
 # Quotation, editable blank schedule with generous row spacing.
 z=header(210,297,'عرض سعر','Quotation')+field('العميل',15,72,180)+field('المرجع',119,88,76)+field('التاريخ',15,88,85)
 z+=rect(15,105,180,14,INK)+ar('وصف البند',189,114,3.5,PEARL,True)+ar('الكمية',103,114,3.2,PEARL)+ar('سعر الوحدة',73,114,3.2,PEARL)+ar('القيمة',35,114,3.2,PEARL)
 for i in range(4):
  y=128+i*18;z+=line(15,y+7,195,y+7,MIST,.3)
 z+=field('الإجمالي',119,213,76,4)+field('مدة صلاحية العرض',15,233,180,3.3)+field('الشروط والرسوم',15,249,180,3.3)+line(15,267,195,267,MIST,.4)+field('اسم المخوّل وتوقيعه',119,276,76,3.5)+note(210,297)
 save('quotation',210,297,z,'عرض سعر A4 — حقول توضيحية غير محسوبة')
 # Folder front + separate internal pocket artwork.
 z=rect(0,0,210,297,INK)+logo(62,36,86,'pearl',branch_size=6)+motif(18,154,174,108,'#385365',.5)+en('ALDAYEL RESIDENTIAL',22,274,4,PEARL)+line(22,284,64,284,COPPER,1)+note(210,297,color=PEARL)
 save('folder',210,297,z,'فولدر — واجهة A4')
 z=rect(0,0,210,297,PEARL)+logo(144,20,46)+rect(0,202,210,95,INK)+motif(15,218,84,72,'#385365',.35)+ar('مساحة تحفظ تفاصيلك',194,230,5,PEARL,True)+line(139,248,194,248,COPPER,.7)+en('ALDAYEL RESIDENTIAL',194,266,2.7,PEARL,anchor='end')+note(210,297,color=PEARL)
 save('folder-pocket',210,297,z,'فولدر — تصور الجيب الداخلي؛ ليس قالب قص تصنيعي')
 # Brochure: 3-panel mockup at A4 landscape, fold positions in metadata/readme.
 exterior=ROOT/'assets/images/concept_residential_exterior.png';interior=ROOT/'assets/images/concept_residential_interior.png'
 z=rect(0,0,297,210,PEARL)+rect(198,0,99,210,INK)+image(exterior,198,0,99,100)+logo(220,111,55,'pearl',branch_size=4)+ar('مساحة تشبه حياتك',286,173,5.3,PEARL,True)+ar('تصوّر سكني توضيحي',286,185,2.8,PEARL)
 z+=logo(118,18,49)+ar('بداية واضحة',186,68,6,INK,True)+bodytext(['تفاصيل واضحة تساعد على','تصوّر المساحة وطريقة العيش.','صياغة تحريرية مقترحة'],186,85,3.9,8)+motif(112,127,72,65,MIST,.4)
 z+=en('ALDAYEL',12,23,6,INK,True)+en('RESIDENTIAL',12,31,3.3)+ar('لنبدأ الحوار',87,65,6,INK,True)+field('للتواصل',12,83,75,3.5)+qr(17,113,37)+ar('رمز تجريبي',35.5,159,2.8,INK,anchor='middle')+ar('نموذج توضيحي',87,199,2.8)
 save('brochure-outside',297,210,z,'بروشور A4 ثلاثي الطي — خارج: خلفية/لسان/غلاف، تقسيمات إرشادية 99 مم')
 z=rect(0,0,297,210,PEARL)+image(interior,0,0,99,210)+rect(0,172,99,38,INK)+ar('تفاصيل تمنح الحياة اتساعاً',89,187,3.9,PEARL,True)+ar('تصوّر سكني توضيحي',89,198,2.6,PEARL)
 z+=en('01 / SPACE',112,24,2.7)+ar('مساحات للحياة',186,45,5.6,INK,True)+bodytext(['نور طبيعي.','توزيع مدروس.','علاقة هادئة بين الداخل والخارج.'],186,66,3.8,10)+line(112,108,183,108,COPPER,.7)+field('وصف المساحة',112,127,74,3.6)+field('المزايا',112,145,74,3.6)+motif(117,159,61,33,MIST,.35)
 z+=en('02 / DETAILS',210,24,2.7)+ar('قرار يبدأ بالوضوح',285,45,5.5,INK,True)+''.join(field(label,210,65+i*18,75,3.3) for i,label in enumerate(['المشروع','نوع الوحدة ومساحتها','الموقع','الزيارة والتواصل']))+rect(210,142,75,39,INK)+ar('كل تفصيل في مكانه',278,159,4,PEARL,True)+ar('محتوى تحريري مقترح',278,171,2.8,PEARL)+ar('نموذج توضيحي',285,199,2.8)
 save('brochure-inside',297,210,z,'بروشور A4 ثلاثي الطي — داخل، صور ومعلومات توضيحية')
 # Seal: single ink, no invented registration numbers.
 z=rect(0,0,55,30,'none')+rect(1,1,53,28,'none',1,INK,.55)+logo(15,4.4,25,'ink',kind='wordmark',branch_size=2.3)+ar('نموذج توضيحي',27.5,27,2.2,INK,anchor='middle')
 save('stamp',55,30,z,'ختم 55×30 مم — تصور غير معتمد، لون واحد')
 # Packaging artwork. Faces only, no false manufacturing dielines.
 z=rect(0,0,250,320,PEARL)+rect(0,226,250,94,INK)+logo(67,62,116,branch_size=8.5)+motif(15,247,112,61,'#385365',.55)+en('ALDAYEL RESIDENTIAL',231,287,5,PEARL,anchor='end')+line(183,297,231,297,COPPER,1.1)+note(250,320,color=PEARL)
 save('shopping-bag',250,320,z,'حقيبة ورقية — تصميم واجهة 250×320 مم')
 z=rect(0,0,240,160,INK)+motif(8,8,47,144,'#385365',.5)+logo(73,39,94,'pearl',branch_size=6.3)+en('ALDAYEL RESIDENTIAL',120,132,3.8,PEARL,anchor='middle')+line(107,143,133,143,COPPER,.9)+note(240,160,color=PEARL)
 save('presentation-box',240,160,z,'علبة تسليم — تصميم الغطاء 240×160 مم')
 z=rect(0,0,260,110,PEARL)+rect(0,0,124,110,INK)+logo(35,21,54,'pearl',branch_size=4)+motif(145,12,97,82,MIST,.45)+rect(180,20,52,66,PEARL)+logo(196,27,20,'ink',kind='icon',branch_size=2.8)+ar('تصوّر أولي — ليس قالب تصنيع',246,100,3)+line(15,98,109,98,COPPER,.8)
 save('cup',260,110,z,'كوب ورقي — مساحة تصميم مسطحة تقريبية 260×110 مم، ليست قالب قص')
 z=rect(0,0,180,110,WHITE)+f'<circle cx="36" cy="38" r="29" fill="{INK}"/>'+logo(26,17,20,'pearl',kind='icon',branch_size=2.4)+f'<circle cx="104" cy="38" r="29" fill="{PEARL}"/>'+logo(89,20,30,'ink',kind='wordmark',branch_size=2.4)+rect(12,78,156,23,INK,2)+logo(20,84,10,'pearl',kind='icon',branch=False)+ar('السكني',158,90,4,PEARL)+en('ALDAYEL RESIDENTIAL',158,97,2.6,PEARL,anchor='end')+ar('نماذج توضيحية',171,16,2.6,INK,anchor='start')
 save('stickers',180,110,z,'ملصقات — نموذجان دائريان وملصق مستطيل؛ صفحة عينات')


def export_all():
 # Inkscape uses HarfBuzz/Pango to shape connected Arabic before outline export.
 for item in manifest:
  name=item['name'];src=EDIT/(name+'.svg');dest=OUT/(name+'.svg');pdf=OUT/(name+'.pdf')
  cmds=[['inkscape',str(src),'--export-text-to-path','--export-plain-svg',f'--export-filename={dest}'],['inkscape',str(src),'--export-text-to-path',f'--export-filename={pdf}']]
  for cmd in cmds:
   r=subprocess.run(cmd,env=ENV,capture_output=True,text=True)
   if r.returncode:raise RuntimeError(name+': '+r.stderr[-2000:])
  # Assert export is vector and outline SVG really has no remaining live text.
  parsed=ET.parse(dest)
  text_count=sum(1 for e in parsed.getroot().iter() if e.tag.endswith('}text'))
  item['outlined_svg_live_text_count']=text_count
  print(name,'ready',flush=True)
 (OUT/'stationery-packaging-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
 (OUT/'QR_PAYLOAD.txt').write_text(QR_PAYLOAD+'\n\nDesign sample text only; not a website, company address, contact card, or live link.\nError correction M; 4-module quiet zone.\n')

if __name__=='__main__':
 build();export_all()
