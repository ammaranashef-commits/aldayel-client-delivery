# Rebuild the application artwork

These instructions cover `build_applications.py`, `build_marketing_applications.py`, and `validate_stationery_applications.py`. They rebuild the supplied application layouts; they do not build the main brand guide or the Blender mockups.

## Requirements

- Python 3.10 or newer, with `venv` and `pip`.
- Inkscape 1.2 or newer on `PATH`, with Fontconfig and Arabic shaping support. Linux is the supported command-line environment; Windows users can use WSL or a Linux container.
- Python packages listed in `requirements-applications.txt`.
- The user's licensed original `HelveticaNeueLTArabic-Roman.otf` and `HelveticaNeueLTArabic-Bold.otf`. Set `ALDAYEL_FONT_DIR` to their directory, or place them in the private `.work/fonts` directory alongside the delivered project folder. The build stops if these files are missing and does not silently substitute another Arabic font.
- The bundled `assets/logos/residential`, `assets/images/concept_residential_exterior.png`, `assets/images/concept_residential_interior.png`, and `assets/fonts/PTSans-*.ttf`. No source archive or Drive download is needed.

Arabic font licensing and redistribution are documented separately by the project. Existing outlined SVG/PDF exports remain viewable without rebuilding or installing those fonts.

## Commands

Run from the delivered `AlDayel_Residential_Premium_Final_Delivery` folder. Keep private fonts and build caches outside the distributable project:

```bash
python3 -m venv ../.work/applications-venv
../.work/applications-venv/bin/python -m pip install -r source/requirements-applications.txt
export ALDAYEL_FONT_DIR="/path/to/your/licensed/arabic/fonts"

../.work/applications-venv/bin/python source/build_applications.py
../.work/applications-venv/bin/python source/validate_stationery_applications.py
../.work/applications-venv/bin/python source/build_marketing_applications.py
```

Omit the `export` line when using the default sibling `.work/fonts` location. The previous `ALDAYEL_ARABIC_FONT_DIR` setting is accepted as a compatibility alias; `ALDAYEL_FONT_DIR` takes precedence.

The scripts resolve paths from their own location, so they also work when invoked from another working directory. Fontconfig paths are XML-escaped, including project/font paths containing spaces or `&`.

## Outputs and checks

- `build_applications.py` writes stationery/packaging live-text SVGs to `applications/editable`, plus outlined SVGs, PDFs, previews, and `applications/stationery-packaging-manifest.json`.
- `validate_stationery_applications.py` independently configures the supplied fonts, checks dimensions, original logo paths, minimum logo widths, clear space, outlined text, and the demonstration QR payload. It writes `quality/applications-stationery-checks.json` and updated contact sheets in `applications/previews`.
- `build_marketing_applications.py` writes the marketing SVG/PDF/PNG layouts and previews, then runs its own geometry, dimensions, and clear-space checks. Reports are in `applications/marketing-manifest.json` and `applications/marketing-validation.json`.

Build commands replace their corresponding generated application files. They do not modify the bundled original logo paths or the main guide. Fontconfig files, Inkscape profiles, and caches are created in the sibling `.work` folder and need not be distributed.

The sample QR code intentionally contains `ALDAYEL RESIDENTIAL - DESIGN SAMPLE - NOT A LIVE LINK`. It is not a live customer destination.
