"""Chromium print renderer with licensed Arabic fonts served only in memory.
Outputs a trimmed RGB executive PDF, preserving vector artwork and font subsets.
"""
from pathlib import Path
import argparse,asyncio,json,os,threading,shutil
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
from playwright.async_api import async_playwright
import fitz
ROOT=Path(__file__).resolve().parent.parent

async def render(output=None,html='executive.html',expected=20,quality='browser-layout-check.json'):
    output=Path(output or ROOT/'AlDayel_Residential_Brand_Book_EXECUTIVE_20P.pdf').resolve()
    fontdir=Path(os.environ.get('ALDAYEL_FONT_DIR',ROOT.parent/'.work/fonts')).resolve()
    fontnames=['HelveticaNeueLTArabic-Roman.otf','HelveticaNeueLTArabic-Bold.otf']
    for name in fontnames:
        if not (fontdir/name).is_file():raise FileNotFoundError(f'Install licensed fonts and set ALDAYEL_FONT_DIR: {name}')
    class Handler(SimpleHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_GET(self):
            if self.path.startswith('/__aldayel_fonts/'):
                name=self.path.split('/')[-1]
                if name not in fontnames:self.send_error(404);return
                data=(fontdir/name).read_bytes();self.send_response(200);self.send_header('Content-Type','font/otf');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
            return super().do_GET()
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(Handler,directory=str(ROOT)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        page=await browser.new_page(viewport={'width':907,'height':1134},device_scale_factor=1)
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        await page.goto(f'http://127.0.0.1:{server.server_address[1]}/source/{html}',wait_until='load')
        await page.emulate_media(media='print')
        await page.evaluate('''async()=>{await Promise.all([...document.images].map(i=>i.decode().catch(()=>{})));await new Promise(requestAnimationFrame);await Promise.all([...document.fonts].map(f=>f.load()));await document.fonts.ready;await new Promise(requestAnimationFrame)}''')
        check=await page.evaluate('''()=>({images:[...document.images].filter(i=>!i.complete||!i.naturalWidth).map(i=>i.getAttribute('src')),fonts:[...document.fonts].map(f=>({family:f.family,status:f.status,weight:f.weight,style:f.style})),pages:[...document.querySelectorAll('.page')].map((p,i)=>{const r=p.getBoundingClientRect();return{number:i+1,width:r.width,height:r.height,text_bounds:[...p.querySelectorAll('h1,h2,h3,p,.caption,.kicker,.branch,.color-values,.en')].filter(e=>!e.closest('svg')).map(e=>{const b=e.getBoundingClientRect();return{text:e.textContent.slice(0,120),left:(b.left-r.left)*25.4/96,top:(b.top-r.top)*25.4/96,right:(b.right-r.left)*25.4/96,bottom:(b.bottom-r.top)*25.4/96,font:parseFloat(getComputedStyle(e).fontSize)*.75}}),outside:[...p.querySelectorAll('h1,h2,h3,p,.caption,.kicker')].filter(e=>!e.closest('svg')).filter(e=>{const b=e.getBoundingClientRect();return b.left<r.left-1||b.right>r.right+1||b.top<r.top-1||b.bottom>r.bottom-1}).map(e=>e.textContent.slice(0,100))}}),image_placements:[...document.images].map(i=>{const b=i.getBoundingClientRect();return{page:i.closest('.page')?.dataset.page,src:i.getAttribute('src'),native:[i.naturalWidth,i.naturalHeight],size_mm:[b.width*25.4/96,b.height*25.4/96],object_fit:getComputedStyle(i).objectFit}})})''')
        raw=output.with_name(output.stem+'-raw.pdf')
        await page.pdf(path=str(raw),print_background=True,prefer_css_page_size=True)
        await browser.close()
    server.shutdown();server.server_close()
    doc=fitz.open(raw);assert len(doc)==expected,(len(doc),expected)
    doc.set_metadata({'title':('الدايل السكني | AlDayel Residential — Executive Brand Book' if expected==20 else 'AlDayel Residential — Executive 20P Validation'),'author':'AlDayel Residential','subject':('Luxury editorial edition — 20 pages' if expected==20 else 'Independent content and technical delivery validation'),'creator':'Editable HTML/CSS/SVG editorial design','keywords':'AlDayel, residential, identity, editorial, RTL, 2026'})
    if expected==20:
        manifest=json.loads((ROOT/'quality/page-manifest.json').read_text());doc.set_toc([[1,p['title'],p['page']] for p in manifest])
        doc.xref_set_key(doc.pdf_catalog(),'ViewerPreferences','<</Direction /R2L /DisplayDocTitle true>>')
        doc.xref_set_key(doc.pdf_catalog(),'PageLayout','/TwoPageRight')
    for pg in doc:
        # Chromium quantizes CSS paper size to 0.01 inch. Restore exact trim
        # without scaling original logo geometry or the page content stream.
        if expected==20: pg.set_mediabox(fitz.Rect(0,0,240*72/25.4,300*72/25.4))
        elif html=='validation.html': pg.set_mediabox(fitz.Rect(0,0,210*72/25.4,297*72/25.4))
        pg.set_cropbox(pg.mediabox);pg.set_trimbox(pg.mediabox);pg.set_bleedbox(pg.mediabox)
    doc.save(output,garbage=4,deflate=True);doc.close();raw.unlink()
    check['javascript_errors']=errors;check['pdf_pages']=expected;check['pdf']=output.name
    (ROOT/'quality'/quality).write_text(json.dumps(check,ensure_ascii=False,indent=2))
    print(json.dumps({'pdf':str(output),'pages':expected,'missing_images':check['images'],'outside':[p['number'] for p in check['pages'] if p['outside']],'fonts':check['fonts']},ensure_ascii=False))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output');ap.add_argument('--html',default='executive.html');ap.add_argument('--expected',type=int,default=20);ap.add_argument('--quality',default='browser-layout-check.json');a=ap.parse_args();asyncio.run(render(a.output,a.html,a.expected,a.quality))
