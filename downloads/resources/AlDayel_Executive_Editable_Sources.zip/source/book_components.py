"""Proportional original SVG embedding. All public dimensions are millimetres."""
from pathlib import Path
import json, re, html, xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent.parent
ET.register_namespace('', 'http://www.w3.org/2000/svg')
ET.register_namespace('xlink', 'http://www.w3.org/1999/xlink')
_instance=0

def inline_svg(path,width_mm=None,height_mm=None,css_class='art',label=''):
    global _instance
    tree=ET.parse(path).getroot()
    _,_,vw,vh=map(float,re.split(r'[\s,]+',tree.attrib['viewBox'].strip()))
    if width_mm is None: width_mm=height_mm*vw/vh
    elif height_mm is None: height_mm=width_mm*vh/vw
    else:
        s=min(width_mm/vw,height_mm/vh);width_mm,height_mm=vw*s,vh*s
    _instance+=1; prefix=f'exec-{_instance:04d}-'
    ids={e.get('id'):prefix+e.get('id') for e in tree.iter() if e.get('id')}
    def urls(v):return re.sub(r'''url\(\s*(['"]?)#([^)'"\s]+)\1\s*\)''',lambda m:'url(#'+ids.get(m[2],m[2])+')',v)
    for e in tree.iter():
        if e.get('id'):e.set('id',ids[e.get('id')])
        for k,v in list(e.attrib.items()):
            if k.rsplit('}',1)[-1]=='href' and v.startswith('#'):v='#'+ids.get(v[1:],v[1:])
            e.set(k,urls(v))
        if e.tag.rsplit('}',1)[-1]=='style' and e.text:
            s=urls(e.text)
            for old,new in ids.items():s=re.sub(r'#'+re.escape(old)+r'(?![\w-])','#'+new,s)
            e.text=s
    tree.set('class',css_class);tree.set('width',f'{width_mm}mm');tree.set('height',f'{height_mm}mm')
    tree.set('style',tree.get('style','')+f';width:{width_mm:.8f}mm;height:{height_mm:.8f}mm;')
    tree.set('preserveAspectRatio','xMidYMid meet');tree.set('role','img')
    if label:tree.set('aria-label',label)
    return ET.tostring(tree,encoding='unicode')

class Components:
    root=ROOT
    def logo(self,variant='primary-ar',color='ink',width_mm=65,branch=False):
        s=inline_svg(ROOT/f'assets/logos/residential/aldayel-{variant}-{color}.svg',width_mm=width_mm,css_class='logo',label='شعار الدايل الأصلي')
        if branch:
            return f'<div class="lockup" style="width:{width_mm}mm;gap:{width_mm*287.84/763.47/4:.5f}mm">{s}<div class="branch">السكني <span class="en">RESIDENTIAL</span></div></div>'
        return s
    def actual_logo(self,mm,variant='primary-ar',color='ink'):
        meta=next(x for x in json.loads((ROOT/'assets/logos/original/provenance.json').read_text()) if x['variant']==variant)
        vw=float(ET.parse(ROOT/f'assets/logos/original/aldayel-{variant}-original.svg').getroot().get('viewBox').split()[2])
        return self.logo(variant,color,mm*vw/meta['logo_width'])
    def art(self,name,width_mm=None,height_mm=None):return inline_svg(ROOT/f'applications/{name}.svg',width_mm,height_mm,label=name)
    def graphic(self,name,width_mm=None,height_mm=None):return inline_svg(ROOT/f'assets/graphics/{name}.svg',width_mm,height_mm,label=name)
    def photo(self,filename,cls='',style=''):return f'<img class="photo {cls}" src="../assets/images/{html.escape(filename)}" style="{style}" alt="مشهد سكني تصوري">'
    def ltr(self,text):return f'<bdi dir="ltr" class="en">{html.escape(str(text))}</bdi>'
    def heading(self,ar,en):return f'<div class="heading"><div class="kicker">{en}</div><h1 class="title">{ar}</h1></div>'
    def page(self,n,title,body,classes=''):
        parity='right' if n%2==0 else 'left'
        footer='' if n in (1,20) else f'<div class="folio en">{n:02d}</div>'
        return {'page':n,'title':title,'html':f'<section class="page {parity} {classes}" id="p{n}" data-page="{n}">{body}{footer}</section>'}
