"""Build the standalone 20-page Arabic editorial book from editable modules."""
from pathlib import Path
import json
from bs4 import BeautifulSoup
from book_components import Components,ROOT
import pages_core

def build():
    c=Components();pages=pages_core.build(c)
    try:
        import pages_applications
        pages.extend(pages_applications.build(c))
    except ImportError:
        for n in range(12,20): pages.append(c.page(n,f'صفحة {n}',f'<div class="safe"><h1>قيد التصميم {n}</h1></div>'))
    pages.sort(key=lambda x:x['page'])
    assert [p['page'] for p in pages]==list(range(1,21))
    html='<!doctype html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>AlDayel Residential — Executive Brand Book</title><link rel="stylesheet" href="executive.css"><link rel="stylesheet" href="executive-applications.css"></head><body>'+''.join(p['html'] for p in pages)+'</body></html>'
    (ROOT/'source/executive.html').write_text(html)
    (ROOT/'quality/page-manifest.json').write_text(json.dumps([{k:v for k,v in p.items() if k!='html'} for p in pages],ensure_ascii=False,indent=2))
    texts=[]
    for p in pages:
        soup=BeautifulSoup(p['html'],'html.parser')
        for svg in soup.find_all('svg'):svg.decompose()
        texts.append(f"\n[{p['page']:02d}] {p['title']}\n"+soup.get_text('\n',strip=True))
    (ROOT/'source/book-copyable-text.ar.txt').write_text('\n\n'.join(texts))
    print('Built 20 editable pages')
if __name__=='__main__':build()
