"""Editorial opening, identity system and closing. Layouts are intentionally distinct."""
def build(c):
    p=[]; L=c.ltr
    p.append(c.page(1,'الدايل السكني — كتاب الهوية التنفيذي',f'''
      <div class="cover-mark">{c.logo(width_mm=62,branch=True)}</div>
      <div class="cover-image">{c.photo('concept-cover-detail-portrait.png')}</div>
      <div class="cover-title"><div class="kicker">ALDAYEL RESIDENTIAL</div><h1>كتاب الهوية</h1><p>الإصدار التنفيذي</p></div>
      <div class="cover-edition en">ARCHITECTURE / IDENTITY / EXPERIENCE<br>EXECUTIVE EDITION — 2026</div>
      <div class="cover-side en">A RESIDENTIAL EXPRESSION</div>
    ''','core01'))
    p.append(c.page(2,'جوهر العلامة',f'''<div class="safe">
      <div class="kicker">01 / THE BRAND</div>
      <h1 class="essence-display">حضور هادئ.<br>تفاصيل واضحة.<br>وعلاقة تدوم.</h1>
      <p class="essence-lede">لغة سكنية معاصرة، تحمل ثقة اسم الدايل<br>وتمنح المكان مساحةً ليعبّر عن نفسه.</p>
      <div class="values"><div><b>ثقة</b><span>وضوح المعلومة</span></div><div><b>راحة</b><span>بساطة التواصل</span></div><div><b>رقيّ معاصر</b><span>دقة التفاصيل</span></div></div>
      <div class="voice"><div class="kicker">TONE OF VOICE</div><h2>ودية ومطمئنة.<br>باحترافية عقارية.</h2><p>«لنبدأ بما تحتاجه في منزلك القادم:<br>الموقع، المساحة، وطريقة حياتك اليومية.»</p><p class="caption">نقدّم المعلومة قبل الوعد. ونتجنب العوائد المضمونة،<br>والتفضيل غير المثبت، والاستعجال المصطنع.</p></div>
      <p class="essence-note caption">العبارات أمثلة تحريرية؛ ليست شعارًا لفظيًا رسميًا.</p>
    </div>''','core02'))
    p.append(c.page(3,'اسم واحد. اختصاص واضح.',f'''<div class="safe">
      {c.heading('اسم واحد. اختصاص واضح.','BRAND ARCHITECTURE')}
      <div class="parent-mark">{c.logo(width_mm=99)}<p class="caption">العلامة الأم · مركز الدايل العقاري</p></div>
      <div class="branch-field">{c.logo(width_mm=82,color='pearl',branch=True)}</div>
      <div class="relationship-copy"><h2>الأصل ثابت. التعبير سكني.</h2><p>تبقى مسارات الشعار وكلماته الأصلية دون تعديل.<br>يظهر التعريف السكني خارج حدوده، بفاصل لا يقل عن {L('X = H/4')}.</p><p class="caption">الاختصاص السكني مستقل في ألوانه وتطبيقاته؛ ولا يدمج لغة الفرع الخدمي أو الحرفي.</p></div>
    </div>''','core03'))
    p.append(c.page(4,'العمارة تمنح الهوية سياقها',f'''
      <div class="hero-photo">{c.photo('concept-courtyard-portrait.png')}</div>
      <div class="hero-label"><div class="kicker">ARCHITECTURAL HORIZON</div><h1>ضوء. فراغ. اتزان.</h1><p class="caption">مشهد معماري تصوري · الصورة ليست عقارًا معروضًا.</p></div>
    ''','core04'))
    cells=[]
    for variant,label,w in [('secondary-ar','ثانوي عربي',47),('secondary-en','ثانوي إنجليزي',47),('submark-ar','عمودي عربي',22),('submark-en','عمودي إنجليزي',22),('wordmark','الاسم',45),('icon','الرمز',23)]:
        cells.append(f'<div class="variant"><div class="variant-art">{c.logo(variant,width_mm=w)}</div><p class="caption">{label}</p></div>')
    p.append(c.page(5,'منظومة الشعار',f'''<div class="safe">
      {c.heading('منظومة الشعار','02 / THE VISUAL IDENTITY')}
      <div class="primary-signature">{c.logo(width_mm=100)}<p class="caption">التوقيع العربي الأساسي</p></div>
      <div class="english-signature">{c.logo('primary-en',width_mm=72)}<p class="caption">التوقيع الإنجليزي الأساسي</p></div>
      <div class="variants">{''.join(cells)}</div>
      <p class="caption variants-note">ثمانية أصول متجهية؛ تتغير المقاسات واللون المعتمد فقط.<br>التعريف «السكني» إضافة مستقلة، وليس جزءًا من المسارات الأصلية.</p>
    </div>''','core05'))
    p.append(c.page(6,'مساحة تحمي الشعار',f'''<div class="safe">
      {c.heading('مساحة تحمي الشعار','LOGO / PRECISION')}
      <div class="clearspace-diagram"><div class="clearspace-box"><div class="ink-bounds">{c.actual_logo(106)}</div><span class="x-label en">X</span><span class="h-label en">H</span><i class="x-bracket"></i><i class="h-bracket"></i></div><div class="clearspace-note"><strong class="en">X = H/4</strong><p class="caption">المساحة الآمنة حول حدود الحبر الفعلية.<br>لا يقاس الفراغ من حافة لوح الرسم.</p></div></div>
      <div class="minimums"><div>{c.actual_logo(45)}<p><b>التوقيع الكامل</b><br>{L('45 mm / 240 px')}</p></div><div>{c.actual_logo(20,'wordmark')}<p><b>الاسم</b><br>{L('20 mm / 110 px')}</p></div><div>{c.actual_logo(8,'icon')}<p><b>الرمز</b><br>{L('8 mm / 32 px')}</p></div></div>
      <p class="caption size-caption">العينات أعلاه بالحجم الطباعي الفعلي. يمتد نطاق التطبيق من {L('20–200 mm')}؛ يبدأ التوقيع الكامل من {L('45 mm')}، والاسم من {L('20 mm')}.</p>
      <div class="usage"><div><div class="usage-art good">{c.logo(width_mm=39)}</div><p class="caption">✓ لون واضح ونسب أصلية</p></div><div><div class="usage-art bad-stretch">{c.logo(width_mm=32)}</div><p class="caption">× تمديد أو ضغط</p></div><div><div class="usage-art bad-contrast">{c.logo(color='pearl',width_mm=39)}</div><p class="caption">× تباين ضعيف</p></div></div>
      <p class="caption logo-rules-end">يُمنع الدوران والظلال، وتزاحم العناصر، وإعادة ترتيب مكونات الشعار.<br>فوق الصور المزدحمة: حقل لوني واضح دون مؤثرات على الشعار.</p>
    </div>''','core06'))
    palette=[('ink','حبر أزرق','Ink Blue','#1C3549','28 / 53 / 73','98 / 76 / 47 / 60','أساسي'),('pearl','أبيض لؤلؤي','Pearl','#F4F3EF','244 / 243 / 239','3 / 3 / 5 / 0','محايد أساسي'),('mist','ضباب أزرق','Blue Mist','#CCDDE4','204 / 221 / 228','19 / 7 / 7 / 0','ثانوي'),('copper','نحاس مطفأ','Muted Copper','#A96B53','169 / 107 / 83','27 / 65 / 75 / 13','مساعد')]
    blocks=[]
    for key,ar,en,h,rgb,cmyk,role in palette:
        blocks.append(f'<div class="color-record {key}"><div class="color-block"></div><div class="color-name"><h2>{ar}</h2><p class="en">{en}</p><span class="caption">{role}</span></div><div class="color-values en"><b>{h}</b><span>RGB&nbsp; {rgb}</span><span>CMYK&nbsp; {cmyk}</span></div></div>')
    p.append(c.page(7,'أفق معماري',f'''<div class="safe">{c.heading('أفق معماري','THE RESIDENTIAL PALETTE')}<div class="color-records">{''.join(blocks)}</div><p class="caption color-profile">قيم الشاشة {L('sRGB')}. تحويلات {L('CMYK')} مرجعية وفق {L('Artifex CMYK SWOP')}؛<br>تُطابق مع ملف المطبعة والورق بعينة فعلية قبل الإنتاج.</p></div>''','core07'))
    p.append(c.page(8,'اللون… بإيقاع محسوب',f'''<div class="safe">
      {c.heading('اللون… بإيقاع محسوب','COLOR IN CONTEXT')}
      <div class="color-composition"><div class="composition-ink"><div class="color-cover-mark">{c.logo(width_mm=48,color='pearl')}</div><h2>مساحات<br>للحياة.</h2><div class="color-cover-footer"><span>ملف العرض السكني</span><span class="en">RESIDENTIAL / EDITIONS</span></div></div><div class="composition-mist"><span>مساحة<br>واضحة.</span></div><div class="composition-pearl"><span class="en">ALDAYEL<br>RESIDENTIAL</span><div class="composition-copper"></div><p>تفصيل هادئ.<br>حضور متزن.</p></div></div>
      <div class="ratios"><span style="width:50%;background:var(--pearl)">50</span><span style="width:30%;background:var(--ink);color:var(--pearl)">30</span><span style="width:15%;background:var(--mist)">15</span><span style="width:5%;background:var(--copper)"></span></div>
      <p class="caption ratios-caption">لؤلؤي {L('50%')} · حبر {L('30%')} · ضباب {L('15%')} · نحاس {L('5%')}<br>نسب إرشادية للمجموعة؛ التكوين أعلاه نموذج غلاف تحريري.</p>
      <div class="contrast-pairs"><div><strong>قراءة واضحة</strong><span class="en">11.43:1</span><p class="caption">حبر / لؤلؤي</p></div><div><strong>قراءة واضحة</strong><span class="en">9.08:1</span><p class="caption">حبر / ضباب</p></div></div>
      <p class="caption contrast-note">النحاس للتفاصيل أو النص الكبير: {L('3.85:1')} على اللؤلؤي.<br>نتجنب الحبر على النحاس {L('2.97:1')}؛ الحد الرقمي {L('4.5:1')} للنص العادي و{L('3:1')} للكبير.</p>
    </div>''','core08'))
    p.append(c.page(9,'الخطّ يصنع الإيقاع',f'''<div class="safe">
      {c.heading('الخطّ يصنع الإيقاع','TYPOGRAPHY')}
      <div class="type-ar"><h2>مساحة<br>تشبه حياتك.</h2><p class="en">Helvetica Neue LT Arabic</p><p class="caption">Roman للنصوص · Bold للعناوين والتأكيدات</p></div>
      <div class="type-en"><div class="en type-en-sample">Space.<br>Light. <i>Belonging.</i></div><p class="en">PT Sans / Regular · <b>Bold</b> · <i>Italic</i></p></div>
      <div class="hierarchy"><div><b>العنوان الرئيسي</b><span class="en">44–60 pt / H1</span></div><div><b>العنوان الفرعي</b><span class="en">24–32 pt / H2</span></div><div><span>النص الطباعي / الرقمي</span><span class="en">11–14 pt / 18–24 px</span></div></div>
      <p class="caption type-rules">هذه مقاسات التطبيقات المرجعية؛ للكتاب تسلسل تحريري يناسب مقاسه.<br>تباعد الأسطر {L('1.5–1.8')}. محاذاة عربية يمينية؛ دون تباعد حرفي أو ميل مصطنع.<br>المائل للإنجليزية فقط. العبارات أمثلة تحريرية، لا شعارات لفظية معتمدة.</p>
    </div>''','core09'))
    icons=[]
    for name,ar in [('home','المنزل'),('location','الموقع'),('key','الاستلام'),('area','المساحة'),('light','الضوء'),('community','المحيط')]:icons.append(f'<div>{c.graphic("icon-"+name,width_mm=14)}<p class="caption">{ar}</p></div>')
    p.append(c.page(10,'لغة من العمارة',f'''<div class="safe">
      {c.heading('لغة من العمارة','VISUAL LANGUAGE')}
      <div class="graphic-hero">{c.graphic('residential-illustration',width_mm=126)}<span class="caption">رسم محوري تصوري</span></div>
      <div class="icon-set">{''.join(icons)}</div><p class="caption icons-note">أيقونات مخصصة · حد رقمي أدنى {L('24 px')} · لا تحل محل رمز الشعار.</p>
      <div class="graphic-samples"><div><div class="pattern-sample">{c.graphic('architectural-pattern',width_mm=90)}</div><p class="caption">نمط منخفض التباين بعيدًا عن النصوص الطويلة.</p></div><div><div class="frame-sample"><div class="grid-sample">{''.join('<i></i>' for _ in range(6))}</div><span>الإطار ينظّم المساحة.</span></div><p class="caption">شبكة منتظمة · إطار مفتوح · هوامش مستقرة.</p></div></div>
      <p class="caption graphics-rule">خطوط العناصر {L('1–2 px')} رقميًا؛ ولا تقل عن {L('0.25 mm')} في الطباعة.</p>
    </div>''','core10'))
    p.append(c.page(11,'الصورة تقرّب المكان',f'''
      <div class="photo11">{c.photo('concept-interior-portrait.png')}</div>
      <div class="photo11-copy"><div class="kicker">PHOTOGRAPHIC LANGUAGE</div><h1>الصورة تقرّب المكان.</h1><p>ضوء طبيعي. منظور مستقيم. خامات ملموسة.</p><p class="caption">نختار الصورة لتوضّح المكان، ونترك التفاصيل تتنفس.<br>مشهد سكني تصوري؛ لا يمثل مشروعًا فعليًا للدايل.</p></div>
    ''','core11'))
    p.append(c.page(20,'الدايل السكني',f'''<div class="closing-mark">{c.logo(width_mm=102,branch=True)}</div><div class="closing-line"><span class="en">A DISTINCT RESIDENTIAL EXPRESSION</span><p>هوية واضحة. حضور متكامل.</p></div><div class="closing-colophon"><div class="en">ALDAYEL RESIDENTIAL<br>EXECUTIVE BRAND BOOK / 2026</div><p class="caption">المرجع التفصيلي: دليل الهوية الكامل <span class="en">PREMIUM FINAL</span>.<br>المشاهد والتطبيقات عرض تصوري للهوية؛ ولا تفيد إطلاق مشاريع أو أنظمة.</p></div>''','core20'))
    return p
