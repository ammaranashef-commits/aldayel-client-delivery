#!/usr/bin/env python3
"""Inspect the exported PDF itself. Does not replace page-by-page visual review.

Usage: python source/validate_pdf.py book.pdf --output quality/final-technical.json
Requires PyMuPDF, pypdf, Pillow; pdffonts is optional but recommended.
PPI uses each image's real PDF transform, not preview resolution or clipped boxes.
"""
from pathlib import Path
import argparse, collections, hashlib, json, math, re, shutil, subprocess
import fitz
from pypdf import PdfReader
from PIL import Image, ImageStat


def audit(path):
    doc = fitz.open(path)
    reader = PdfReader(str(path), strict=True)
    result = {
        'file': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'bytes': path.stat().st_size, 'pdf_format': doc.metadata.get('format'),
        'pymupdf_open': True, 'pymupdf_required_repair': doc.is_repaired,
        'pypdf_strict_open': True, 'page_count': len(doc),
        'pypdf_page_count': len(reader.pages), 'encrypted': doc.is_encrypted,
        'metadata': doc.metadata, 'bookmarks': doc.get_toc(),
        'ppi_method': 'width_pixels*72/hypot(a,b), height_pixels*72/hypot(c,d), from image transform (a,b,c,d,e,f). Includes image extents beyond crop; never divides by clipped bbox.',
        'scope': 'Structural and measurable checks only. Visual design, Arabic reading order and all clipping require the separate rendered-page review.',
    }
    font_xrefs, images, pages = {}, [], []
    for number, page in enumerate(doc, 1):
        text = page.get_text()
        spans = [s for b in page.get_text('dict')['blocks'] for l in b.get('lines', []) for s in l['spans']]
        outside = []
        for span in spans:
            box = fitz.Rect(span['bbox'])
            if box.x0 < -2 or box.y0 < -2 or box.x1 > page.rect.width + 2 or box.y1 > page.rect.height + 2:
                outside.append({'text': span['text'], 'bbox': list(box)})
        for font in page.get_fonts(full=True):
            font_xrefs[font[0]] = font
        page_images = []
        for info in page.get_image_info(xrefs=True):
            a, b, c, d, e, f = info['transform']
            wx, hy = math.hypot(a, b), math.hypot(c, d)
            ppi = [info['width'] * 72 / wx if wx else None,
                   info['height'] * 72 / hy if hy else None]
            record = {
                'page': number, 'xref': info['xref'],
                'pixels': [info['width'], info['height']],
                'transform': [round(v, 5) for v in info['transform']],
                'bbox_pt': [round(v, 3) for v in info['bbox']],
                'effective_ppi': [round(v, 2) if v else v for v in ppi],
                'colorspace': info['cs-name'],
                'fraction_page_area_before_clipping': round(abs(a*d-b*c) / page.rect.get_area(), 5),
                'digest': info.get('digest', b'').hex(),
            }
            images.append(record); page_images.append(record)
        # A uniform page is suspicious even if it contains an invisible text layer.
        pix = page.get_pixmap(matrix=fitz.Matrix(.25, .25), colorspace=fitz.csGRAY, alpha=False)
        sample = Image.frombytes('L', (pix.width, pix.height), pix.samples)
        variance = ImageStat.Stat(sample).var[0]
        drawings = page.get_drawings()
        trace = page.get_bboxlog()
        pages.append({
            'page': number, 'size_pt': [page.rect.width, page.rect.height],
            'rotation': page.rotation, 'media_box': list(page.mediabox),
            'crop_box': list(page.cropbox), 'text_characters': len(text),
            'arabic_characters': len(re.findall(r'[\u0600-\u06ff]', text)),
            'replacement_characters': text.count('\ufffd'),
            'selectable_text_present': bool(text.strip()),
            'render_grayscale_variance': round(variance, 3),
            'suspected_blank': variance < 1,
            'image_placements': len(page_images), 'vector_drawings': len(drawings),
            'drawing_operations': dict(collections.Counter(x[0] for x in trace)),
            'links': len(page.get_links()),
            'text_outside_page_gt_2pt': outside,
            'partial_opacity_drawing_count': sum(1 for x in drawings if 0 < (x.get('fill_opacity') or 1) < 1 or 0 < (x.get('stroke_opacity') or 1) < 1),
            'duplicate_diacritic_extraction_hits': len(re.findall(r'([\u064b-\u0652])\s*\1', text)),
            'actual_text_marked_spans': page.read_contents().count(b'/ActualText'),
            'reversed_char_marked_runs': page.read_contents().count(b'/ReversedChars'),
        })
    result['pages'] = pages
    result['image_placements'] = images
    result['fonts'] = [list(v) for v in font_xrefs.values()]
    result['font_verification'] = {'method': 'pdffonts optional'}
    if shutil.which('pdffonts'):
        p = subprocess.run(['pdffonts', str(path)], capture_output=True, text=True, check=True)
        font_rows = []
        for ln in p.stdout.splitlines()[2:]:
            values = ln.split()
            if len(values) < 7: continue
            font_rows.append({'name': values[0], 'embedded': values[-5] == 'yes',
                              'subset': values[-4] == 'yes', 'to_unicode': values[-3] == 'yes',
                              'xref': int(values[-2])})
        result['font_verification'] = {'method': 'pdffonts', 'raw': p.stdout,
            'fonts': font_rows, 'all_embedded': all(x['embedded'] for x in font_rows),
            'all_subsets': all(x['subset'] for x in font_rows),
            'all_have_unicode': all(x['to_unicode'] for x in font_rows)}
    result['summary'] = {
        'consistent_page_sizes': len({tuple(x['size_pt']) for x in pages}) == 1,
        'suspected_blank_pages': [x['page'] for x in pages if x['suspected_blank']],
        'pages_without_selectable_text': [x['page'] for x in pages if not x['selectable_text_present']],
        'pages_with_text_outside_page': [x['page'] for x in pages if x['text_outside_page_gt_2pt']],
        'significant_images_below_180_ppi': [x for x in images if min(x['effective_ppi']) < 180 and x['fraction_page_area_before_clipping'] > .02],
        'pages_with_duplicate_diacritics_in_pymupdf': [x['page'] for x in pages if x['duplicate_diacritic_extraction_hits']],
        'screen_suitable_requires_visual_review': True,
        'press_certified': False,
    }
    catalog = reader.trailer['/Root']
    result['text_copy_accessibility'] = {
        'tagged_structure_tree': '/StructTreeRoot' in catalog,
        'actual_text_marked_spans': sum(p['actual_text_marked_spans'] for p in pages),
        'limitation': 'Arabic shaping and embedded fonts do not guarantee identical copy order across PDF extractors. Correct ActualText clusters can produce duplicate combining marks in PyMuPDF; source/book-copyable-text.ar.txt preserves live source Unicode. Not certified PDF/UA or fully screen-reader accessible.',
        'copyable_source_digest_file': 'quality/final-source-text-digest.json',
    }
    result['print_format'] = {
        'output_intents': '/OutputIntents' in catalog,
        'bleed_boxes_explicit': sum('/BleedBox' in p for p in reader.pages),
        'trim_boxes_explicit': sum('/TrimBox' in p for p in reader.pages),
        'note': 'RGB digital review book; no claim of PDF/X or production printing certification. CMYK tables describe a named provisional conversion, not the PDF color encoding.',
    }
    doc.close()
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pdf', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    report = audit(args.pdf)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(json.dumps({'output': str(args.output), 'pages': report['page_count'],
        'summary': {k:v for k,v in report['summary'].items() if k!='significant_images_below_180_ppi'}}, ensure_ascii=False))
