"""Rasterize browser vector frames, preserving the intended 1920×1080 pixel canvas."""
from pathlib import Path
import sys,shutil
import fitz
frames=Path(sys.argv[1]);dest=Path(sys.argv[2])
for pdf in sorted(frames.glob('*.pdf')):
 doc=fitz.open(pdf);page=doc[0];pix=page.get_pixmap(matrix=fitz.Matrix(1920/page.rect.width,1080/page.rect.height),alpha=False)
 assert (pix.width,pix.height)==(1920,1080)
 pix.save(pdf.with_suffix('.png'))
for n,label in [(6,'0p25'),(24,'1'),(132,'5p5')]:
 shutil.copyfile(frames/f'frame-{n:04d}.png',dest/'stills'/f'motion-{label}s.png')
shutil.copyfile(frames/'reduced-motion-static.png',dest/'stills'/'reduced-motion-static.png')
print('Rasterized 144 vector frames and reduced-motion fallback')
