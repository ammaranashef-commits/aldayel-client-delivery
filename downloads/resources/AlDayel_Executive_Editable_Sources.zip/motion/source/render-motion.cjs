/** Requires Node.js, Playwright+Chromium, Python+PyMuPDF and ffmpeg. No runtime network requests. */
const {chromium}=require('playwright');
const fs=require('fs'),path=require('path'),os=require('os'),http=require('http'),{execFileSync}=require('child_process');
function onPath(names){
 const suffixes=process.platform==='win32'?['.exe','.cmd','']:[''];
 for(const name of names) for(const dir of (process.env.PATH||'').split(path.delimiter)) for(const suffix of suffixes){const candidate=path.join(dir,name+suffix);try{fs.accessSync(candidate,fs.constants.X_OK);return candidate}catch{}}
 return undefined;
}
function executableFrom(envName,names){const found=process.env[envName]||onPath(names);if(!found)throw new Error(`Missing ${names[0]}; install it on PATH or set ${envName}.`);return found;}
(async()=>{
 const bundled=chromium.executablePath();
 const browserPath=process.env.CHROMIUM_PATH||(fs.existsSync(bundled)?bundled:onPath(['chromium','chromium-browser','google-chrome','chrome']));
 if(!browserPath)throw new Error('Install Playwright Chromium (npx playwright install chromium) or set CHROMIUM_PATH to a Chromium executable.');
 const pythonPath=executableFrom('PYTHON_PATH',['python3','python']);
 const ffmpegPath=executableFrom('FFMPEG_PATH',['ffmpeg']);
 if(process.argv.includes('--check-tools')){console.log(JSON.stringify({chromium:browserPath,python:execFileSync(pythonPath,['-c','import fitz; print(fitz.__version__)'],{encoding:'utf8'}).trim(),ffmpeg:execFileSync(ffmpegPath,['-version'],{encoding:'utf8'}).split('\n')[0]},null,2));return;}
 const base=path.dirname(__dirname),temp=fs.mkdtempSync(path.join(os.tmpdir(),'aldayel-motion-'));
 const project=path.dirname(base);
 const server=http.createServer((req,res)=>{const p=path.resolve(project,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));if(!p.startsWith(project+path.sep)){res.writeHead(403);res.end();return}try{const ext=path.extname(p);res.setHeader('Content-Type',({'.html':'text/html; charset=utf-8','.svg':'image/svg+xml','.ttf':'font/ttf','.png':'image/png'})[ext]||'application/octet-stream');res.end(fs.readFileSync(p))}catch(e){res.writeHead(404);res.end()}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:browserPath,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const page=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});
 await page.goto(`http://127.0.0.1:${server.address().port}/motion/source/animated-logo.html?t=0`);
 await page.evaluate(()=>Promise.all([document.fonts.ready,...Array.from(document.images).map(i=>i.decode())]));
 for(let n=0;n<144;n++){
  await page.evaluate(t=>window.renderAt(t),n/24);
  await page.pdf({path:path.join(temp,`frame-${String(n).padStart(4,'0')}.pdf`),width:'1920px',height:'1080px',printBackground:true,margin:{top:0,right:0,bottom:0,left:0}});
 }
 await page.emulateMedia({reducedMotion:'reduce'});await page.evaluate(()=>window.renderAt(6));
 await page.pdf({path:path.join(temp,'reduced-motion-static.pdf'),width:'1920px',height:'1080px',printBackground:true,margin:{top:0,right:0,bottom:0,left:0}});
 await browser.close();server.close();
 execFileSync(pythonPath,[path.join(__dirname,'raster-frames.py'),temp,base],{stdio:'inherit'});
 execFileSync(ffmpegPath,['-y','-framerate','24','-i',path.join(temp,'frame-%04d.png'),'-c:v','libx264','-preset','medium','-crf','17','-pix_fmt','yuv420p','-movflags','+faststart','-an','-threads','2',path.join(base,'AlDayel_Residential_Animated_Logo.mp4')],{stdio:'inherit'});
 fs.rmSync(temp,{recursive:true,force:true});
 console.log('Motion export complete');
})().catch(e=>{console.error(e);process.exit(1)});
