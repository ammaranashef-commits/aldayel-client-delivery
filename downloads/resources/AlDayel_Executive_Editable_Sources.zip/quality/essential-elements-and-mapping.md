# Executive 20P: requirements and source crosswalk

> Scope: read-only source analysis and proposed integration. This file does not certify a final executive PDF.

## Essential screenshot checklist — all 33 retained

|ID|Requirement|Full guide pages|Executive pages|Minimum visible evidence|
|---|---|---|---|---|
|S01|الشعار الأصلي|9, 10|3, 5|Display untouched original primary Arabic artwork and inherited variants.|
|S02|الأحجام القياسية من 20 إلى 200 مم|13|6|State 20–200 mm range; 20 mm is wordmark-only. Give 45/60/100/200 mm full-mark scale labels; label reduced examples illustrative.|
|S03|المساحة الآمنة والحد الأدنى للمساحة الحرة|11, 12|3, 6|Show X=H/4 from actual ink height; X on all sides and at least X to residential descriptor.|
|S04|تطبيقات على خلفيات متنوعة|14|5, 8|Show exact ink/pearl/mist combinations plus logo in solid field over photography.|
|S05|الاستخدام الصحيح والخاطئ|14, 15|6|Visible correct example and explicit prohibited stretch/rotation/effect/low contrast/rearrangement/encroachment examples.|
|S06|تحريك الشعار للفيديو والرقمي|16|17|Motion storyboard plus 1920×1080,24fps,6sec; link/include actual inherited MP4 and reduced-motion still.|
|S07|المجموعة الأساسية|21, 22, 23|7, 8|All4 approved swatches and named roles.|
|S08|RGB وCMYK وHEX|22, 25|7|All4 exact HEX/RGB/CMYK values and named provisional ICC reference.|
|S09|خطوط العناوين الرئيسية|27, 28, 29|9|Helvetica Neue LT Arabic Bold/Roman; PT Sans Bold/Regular.|
|S10|خطوط النصوص والعناوين الفرعية|27, 28, 29|9|Roman/Regular text and Bold subheading specimens.|
|S11|أحجام الخطوط|29|9|Show inherited H1 44–60pt,H2 24–32pt,body11–14pt print/18–24px digital; notes are application guidance.|
|S12|الأنماط: عادي وغامق ومائل|27, 28|9|Arabic Roman/Bold; English Regular/Bold/Italic. No synthetic Arabic italic.|
|S13|مجموعة أيقونات مخصصة|31|10|Use six residential icons: home,location,handover,area,daylight,neighbourhood; minimum24px.|
|S14|أنماط زخرفية متكررة|32|10|Actual repeated architectural-pattern specimen.|
|S15|رسومات توضيحية|33|10|Actual inherited axonometric residential-illustration.svg, not an icon mislabeled illustration.|
|S16|أنماط الخلفيات والإطارات|30, 32|10|Show architectural straight frame and low-contrast background; avoid patterns behind long text.|
|S17|نبرة الخطاب|6|2|Warm reassuring tone with real-estate professionalism; one concrete approved-style sentence; no unsupported promises.|
|S18|الكرت الشخصي الرسمي|37|12|Front and back of90×55mm business card, with truthful fields.|
|S19|QR code|37|12|Actual QR example; mark demonstration and4-module quiet-zone rule; no false final company URL.|
|S20|ورق مراسلات|38|12|Actual A4 letterhead example.|
|S21|الأظرف|39|12|Actual envelope family; captions DL220×110,C5229×162,C4324×229 mm.|
|S22|السندات|40|15|Distinct سند قبض example or clear detail paired with unit dossier.|
|S23|الفولدرات|41|14|Actual folder cover and pocket face visible.|
|S24|البروشور|42|14|Actual brochure inside/outside visible, A4 landscape tri-fold concept.|
|S25|الفلايرات|43|18|Actual A5 flyer,148×210mm.|
|S26|الإيصالات|40|15|Distinct إيصال sample; not substituted by سند قبض.|
|S27|عرض سعر|40|15|Distinct A4 عرض سعر sample; no invented amounts or terms.|
|S28|ختم|44|15|Actual single-color wordmark stamp55×30mm; no invented license/address.|
|S29|أكياس ورقية دعائية|45, 56|19|Actual bag application visible.|
|S30|علب وتغليف|46, 56|19|Actual welcome box application visible.|
|S31|أكواب ورقية|47|19|Actual paper-cup application visible.|
|S32|استيكرات|48|19|Actual sticker sample(s) visible, may be discrete bottom detail strip.|
|S33|رول أب|49|18|Actual roll-up850×2000mm visible, not only listed.|

## Proposed 20-page editorial mapping

|Page|Purpose|Full guide pages|Integration|
|---|---|---|---|
|1|الغلاف الفني|1, 7, 62|Independent cover. Original residential lockup, restrained book title, and architectural image or detail; avoid excessive labels.|
|2|جوهر العلامة وصوتها|2, 5, 6|Quiet statement: ثقة، راحة، رقي معاصر. Include the real-estate tone and one short concrete invitation without guarantees.|
|3|أصل واحد؛ حضور سكني|4, 9, 11|Original and residential lockups; descriptor outside original with H/4 separation. Pair the quiet statement on page 02 with this precise visual explanation.|
|4|المشهد الرئيسي|7, 34, 50|Large architectural branding image with exact official vector logo placed on a plausible surface. Avoid generated lettering.|
|5|منظومة الشعار|9, 10, 14|Primary Arabic mark as the main element, with inherited English descriptor, secondary, wordmark and icon variants; retain exact geometry.|
|6|قواعد تحمي العلامة|11, 12, 13, 14, 15|Clear-space diagram, three minimum widths, the 20–200 mm range, and visible correct/incorrect examples. Allocate ample room.|
|7|ألوان أفق معماري|21, 22, 25|Four editorial swatches with all HEX, RGB and CMYK values. Add one concise profile and print-proof note.|
|8|اللون في الاستخدام|23, 24, 35|Visualize the 50/30/15/5 relationship and readable ink/pearl/mist combinations. Restrict copper to details and large text.|
|9|حروف واضحة|27, 28, 29|Arabic and English specimens with weights, italic rule and numerical hierarchy. Let typography carry the composition.|
|10|لغة معمارية|30, 31, 32, 33, 35|Use a quiet grid, actual six-icon set, repeated pattern, straight frame, and inherited axonometric illustration.|
|11|الضوء والمكان|7, 34|Dominant architectural photograph with three short principles; a calm counterpage to the graphic language on page 10.|
|12|المراسلات المؤسسية|36, 37, 38, 39|Letterhead, business-card front/back with QR, and DL/C5/C4 envelopes. Move financial forms to page 15 to preserve scale.|
|13|الهوية على الواجهة|50|Large convincing facade or signage application using exact logo geometry. The full guide has only a flat signage view, so a new physical scene adds value.|
|14|ملف العرض العقاري|41, 42, 55|Folder cover/pocket and brochure inside/outside. Add marketing presentation specimens if room permits; otherwise move them to page 18.|
|15|ملف الوحدة والمعاملة|40, 44, 54|Hero property card with truthful fields. Add distinct, labeled details for سند قبض, إيصال, عرض سعر and stamp; avoid illegible tiny whole pages.|
|16|الحضور الاجتماعي|51, 52, 53|Post and story layouts. Include the 250 px top/bottom safety guidance for a 1920 px story; use truthful illustrative content.|
|17|التجربة الرقمية والحركة|16, 57|Conceptual website or screen plus a motion storyboard with 6 sec / 24 fps specification and supplied video assets. Do not invent a live company URL.|
|18|الحملة السكنية|43, 49, 53, 55|A5 flyer, roll-up and related advertisement or presentation specimens with controlled scale and clear labels.|
|19|تجربة الترحيب|45, 46, 47, 48, 56|Bag and welcome-box hero scene, with actual cup and sticker visuals as supporting details; maintain one coherent visual family.|
|20|الخاتمة|62|Independent closing with precise original lockup. A small colophon may identify the full technical guide and conceptual visual status.|

## New executive acceptance requirements

|ID|Requirement|Page scope|
|---|---|---|
|E01|Exactly 20 pages including independent cover and closing.|1, 20|
|E02|Retain the full 62-page guide byte-for-byte; create a separate executive PDF.||
|E03|Choose book dimensions and an editorial grid; do not use automatic 16:9.|1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20|
|E04|RTL reading and right-side binding; pairs 02 right / 03 left through 18 right / 19 left.|2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19|
|E05|Architectural key visual with precisely composited official branding.|4, 13|
|E06|Parent/subbrand relationship; original descriptor remains untouched.|3|
|E07|Secondary colors, 50/30/15/5 proportions, and contrast guidance.|7, 8|
|E08|Photography: natural light, plausible perspective, material truth, and conceptual disclosure.|4, 11, 13, 19|
|E09|Property listing cards with truthful or unfilled data fields.|15|
|E10|Social posts 1080×1350 and stories 1080×1920, with 250 px story safe areas.|16|
|E11|Conceptual digital interface clearly not deployed; include the inherited motion application.|17|
|E12|Residential advertising and marketing presentation specimens.|14, 18|
|E13|Editable sources, linked assets, and inherited motion files.||
|E14|20-page contact sheet outside the book, plus selected high-resolution previews.||
|E15|Short separate validation PDF with a crosswalk and actual review results.||
|E16|Inspect all 20 exported pages individually and all nine RTL interior spreads.|1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20|
|E17|Five reviews: artistic, editorial, brand consistency, technical detail, executive presentation.|1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20|
|E18|Embedded fonts, vector logos, correct Arabic shaping and numeric direction.|1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20|
|E19|Actual bleed for a print PDF with full-bleed imagery; truthful RGB digital status.||
|E20|No invented facts, company claims, listing prices, or project status.|1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20|
|E21|External references inform layout only; never import their marks, palette, fonts, or content.|1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20|
|E22|Keep essential technical information readable; reorganize rather than excessively downsize.|6, 7, 9, 10, 12, 15, 16, 17, 18, 19|
