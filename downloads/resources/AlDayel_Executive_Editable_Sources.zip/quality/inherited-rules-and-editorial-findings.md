# Inherited identity rules and executive compression findings

Scope: source analysis only. No source asset or full-guide file was modified. The mapping files are a proposal, not a claim of final compliance.

## Sources inspected

- Latest complete guide: `AlDayel_Residential_Premium_Final_Delivery/AlDayel_Residential_Brand_Guidelines_PREMIUM_FINAL.pdf`, 62 pages, SHA-256 `6afa44a0ceb60aa162b03463847dc820a8da44888a452dd395ddebaded26db7d`. Opened with PyMuPDF and examined all 62 pages through the final contact sheets; read the logical Arabic source text and source rules.
- Official intake: `/workspace/shared/dayel-reference-intake/extracted/Branding Assets - AlDayel Real Estate`. Inventory has 252 non-hidden files across Visual identity, Print, Mockups, For Instagram, Highlight Icons. The official original identity book is 20 pages and names the two inherited type families.
- Requirement screenshots `1-1.jpg` and `2-2.jpg` reopened and visually read. All 33 items correspond to S01–S33 of the complete-guide matrix. The user's earlier correction replaces medical professionalism with real-estate professionalism.
- Both external PDFs reopened. Reference 1 is one very long raster PDF (336 × 6958 pt), represented by 19 review slices; reference 2 has 33 landscape pages (about 295 × 210 mm). All slices/pages were visually reviewed through their eight contact sheets. Their artwork, brands, palettes, and type must not enter this book.

## What the external references contribute

Use only the sequence from identity rules to applications, the generous size of product specimens, a clear change of visual pace between chapters, and a concise logo closing. Avoid their repeated horizontal slide grids, generic faux golden-ratio grids, long bilingual paragraphs, pink/teal palette, flower shapes, medical imagery, and source-brand marks. Neither reference dictates a coffee-table-book format. A new portrait or near-square book with true RTL spreads is justified by this brief.

## Immutable logo rules

The original primary Arabic artwork contains **مركز الدايل العقاري**. Preserve it intact. The English-descriptor original contains **AlDayel Real Estate**. A separate **السكني / RESIDENTIAL** extension is set outside either original; it never replaces an original word. Use existing vector source variants only: primary Arabic/English, secondary Arabic/English, wordmark only, icon only, vertical Arabic/English submarks.

Actual source ink aspect ratios: primary Arabic 2.6581586; primary English 2.6886840; secondary Arabic 1.5519636; secondary English 1.5978361; wordmark 2.0531991; icon 1.0476102; vertical English 0.6892687; vertical Arabic 0.6642820. Preserve geometry and proportional scaling. Fill recoloring is allowed using the inherited palette. Inlaid SVG instances should have unique IDs and proportional viewBox dimensions.

- Let H equal the original artwork's actual ink height. X = H/4. At least X clear space on all sides, measured from ink rather than artboard bounds.
- Residential descriptor is centered outside the original, separated by at least X. The optional separator does not replace original artwork.
- Full primary minimum: **45 mm print / 240 px digital**.
- Original wordmark minimum: **20 mm / 110 px**.
- Original icon minimum: **8 mm / 32 px**.
- Required range **20–200 mm** must appear, with 20 mm assigned to the original wordmark, never to the full primary lockup.
- If size samples are reduced to fit the new page, call them illustrative; do not claim physical 1:1 sizes. A 200 mm full lockup plus safe space needs approximately 238 mm before page margins.
- No stretch, compression, rotation, shadow, low contrast, encroachment, rearranged components, substituted descriptor, or invented reconstruction grid. Wrong-use specimens must be unmistakably labeled as prohibited.

These safe-space and size rules originated in the residential extension, not in the old brand book. The current brief treats the latest complete guide as the inherited reference; no further approval loop is needed for using its rules.

## Exact approved residential palette

| Role | Color | HEX | RGB | CMYK | Guide proportion |
|---|---|---|---|---|---|
| Primary | Ink Blue / حبر أزرق | #1C3549 | 28 / 53 / 73 | 98 / 76 / 47 / 60 | 30% |
| Neutral | Pearl / أبيض لؤلؤي | #F4F3EF | 244 / 243 / 239 | 3 / 3 / 5 / 0 | 50% |
| Secondary | Blue Mist / ضباب أزرق | #CCDDE4 | 204 / 221 / 228 | 19 / 7 / 7 / 0 | 15% |
| Accent | Muted Copper / نحاس مطفأ | #A96B53 | 169 / 107 / 83 | 27 / 65 / 75 / 13 | 5% |

HEX/RGB are sRGB. Inherited CMYK values use **Artifex CMYK SWOP Profile** and are provisional print separations, subject to printer ICC/paper and physical proof. They are not Pantone equivalents. The 50/30/15/5 mix is an overall guide, not a rigid percentage quota on each page. Dark covers and pearl stationery are expressly allowed.

Contrast: ink/pearl 11.43:1; ink/mist 9.08:1; copper/pearl 3.85:1; ink/copper 2.97:1. Copper/pearl is for large text and graphic details, not small body text. Ink/copper is unsuitable for text. Digital threshold: 4.5:1 normal / 3:1 large. Use a solid color field over busy photography; do not solve weak contrast with logo shadows.

## Typography

- Arabic: **Helvetica Neue LT Arabic Roman and Bold**; inherited supplied originals, no lookalike substitution. Roman for text, Bold for headers/emphasis.
- English: **PT Sans Regular, Bold, Italic**. Italic only for short English quotations. Original English logo glyph outlines remain untouched, including any original Montserrat lettering within the provided artwork.
- No artificial Arabic italic or tracking. Correct RTL shaping and separate LTR numeric/code spans.
- Inherited application hierarchy: H1 **44–60 pt**, H2 **24–32 pt**, text **11–14 pt print / 18–24 px digital**, line spacing **1.5–1.8**. Show these numerical rules on the typography page; adapt the book's own editorial hierarchy thoughtfully without pretending the sample display size is the specified application size.
- Embed permitted font subsets into PDFs. Do not redistribute the raw licensed Arabic font binaries. Supply editable sources and clear installation instructions. The inherited PT Sans files and license may be included.

## Other precise rules worth retaining in compact form

- Six custom icons: المنزل، الموقع، الاستلام، المساحة، الضوء، المحيط. Minimum digital icon size 24 px; consistent straight architectural strokes; label ambiguous meanings. Never replace the logo icon with a pictogram.
- Architectural graphic line: 1–2 px for large digital layouts; at least 0.25 mm in print. Pattern is low contrast; no pattern behind long text.
- Illustration is the existing axonometric residential block, explicitly conceptual rather than a project plan.
- Photo direction: natural light, believable straight perspective, clear material texture, honest conceptual labeling, no invented property attribution.
- Tone: friendly and reassuring, with real-estate professionalism. Prefer specific invitations and facts; prohibit guaranteed returns, unfounded superlatives, pressure, or claimed availability.
- Card 90×55 mm. QR demonstration only until its target is authorized; 4-module quiet zone and actual scanning test before production.
- Envelopes DL 220×110, C5 229×162, C4 324×229 mm; supplier flap/glue templates govern production.
- Letterhead A4; voucher and receipt A5 landscape 210×148; quotation A4. All financial/contact fields remain truthful and awaiting real inputs.
- Folder A4 contents; brochure A4 landscape tri-fold; flyer A5 148×210; stamp 55×30 single color.
- Bag front 250×320, box lid 240×160, cup flat reference 260×110 mm; these are design views, not approved dielines. Stickers preserve original icon/wordmark; review cut/bleed with supplier.
- Roll-up 850×2000 mm; signage 2000×1000 mm. Production needs supplier template and adequately resolved image at final scale.
- Social post 1080×1350; story 1080×1920 with about 250 px safe area at top and bottom, subject to platform UI.
- Presentation specimens 1600×900 remain valid application assets even though the executive book itself must not use a default 16:9 format.
- Motion: full mark stays a single unchanged unit; fade and slight translation only. Inherited output 1920×1080, 24 fps, 6 seconds, silent H.264; include its source and reduced-motion still.

## Compression feasibility and risk points

Twenty pages is feasible if most pages have one dominant editorial statement or image, while the technical pages use compact, readable proofs. It is not feasible to allocate one page per application and still retain all mandatory items. Page titles alone do not count as displaying applications.

The proposed user outline misses explicit motion, tone, QR, envelopes, forms, stamp, folder, bags, box, cups, stickers, and roll-up. The accompanying matrix integrates all of these. Use the full guide for secondary manufacturing detail and research history; retain the core rule and visible artifact in the executive book itself.

Highest density risks are pages 06 (logo rules), 10 (graphic language), 12/15 (stationery and administrative forms), and 19 (welcome applications). Spread stationery across page 12 (letterhead, card/QR, envelopes), page 14 (folder, brochure), and page 15 (unit card, distinct voucher/receipt/quotation, stamp) rather than forcing every document into page 12. Page 19 can use a large bag/box image and clearly labeled cup/sticker details. Actual forms can be shown by readable characteristic details instead of tiny whole pages, provided each is distinctly identified and the editable full source is supplied.

## Facing pages and production

Choose the final dimensions and right-hand binding before layout. With cover 01 and closing 20 independent, the interior RTL pairs are **02 right / 03 left**, **04 right / 05 left**, …, **18 right / 19 left**. Generate explicit spread previews in that physical order; ordinary PDF contact-sheet order does not demonstrate correct RTL spreads. Important type, the original logo, and QR must clear the binding allowance. Continuous imagery across two pages must remain coherent and useful on each separate page.

The digital PDF should have a clean trim page, embedded fonts and vectors. If a separate print-preparation PDF is produced for full-bleed pages, include actual bleed, correct TrimBox/BleedBox, right-binding instructions and printer-profile qualification. Do not label a digital RGB PDF as certified PDF/X or press-ready without the relevant checks. Do not lower image quality just to keep file size small; verify effective PPI in each placement.

## Source status and final validation

The full guide's previous exploratory palettes and research history are secondary background, retained in the untouched complete guide and source dossier. They do not need to be repeated as competing choices in an executive edition of the chosen identity. No additional brand claims, invented company facts, or new production approvals should be inferred from this condensation.

Final acceptance must inspect the exported 20-page PDF, all 20 individual high-resolution page previews, all nine RTL interior spreads, page count, embedded fonts, exact logo vectors/affine ratios, colors, effective image resolution, text clipping, and a source-content crosswalk. The short validation report should distinguish actual completed checks from pending physical printer/company approvals.
