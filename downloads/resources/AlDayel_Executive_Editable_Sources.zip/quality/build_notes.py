from pathlib import Path
import json,hashlib,fitz
R=Path('/workspace/codex/AlDayel_Residential_Premium_Final_Delivery')
O=Path('/workspace/codex/.work/executive-20p/requirements')
base=json.loads((R/'research/requirements-matrix.json').read_text())
# A recommendation for integration, not evidence that a final executive PDF has passed.
mp={1:([3,5],'Display untouched original primary Arabic artwork and inherited variants.'),2:([6],'State 20–200 mm range; 20 mm is wordmark-only. Give 45/60/100/200 mm full-mark scale labels; label reduced examples illustrative.'),3:([3,6],'Show X=H/4 from actual ink height; X on all sides and at least X to residential descriptor.'),4:([5,8],'Show exact ink/pearl/mist combinations plus logo in solid field over photography.'),5:([6],'Visible correct example and explicit prohibited stretch/rotation/effect/low contrast/rearrangement/encroachment examples.'),6:([17],'Motion storyboard plus 1920×1080,24fps,6sec; link/include actual inherited MP4 and reduced-motion still.'),7:([7,8],'All4 approved swatches and named roles.'),8:([7],'All4 exact HEX/RGB/CMYK values and named provisional ICC reference.'),9:([9],'Helvetica Neue LT Arabic Bold/Roman; PT Sans Bold/Regular.'),10:([9],'Roman/Regular text and Bold subheading specimens.'),11:([9],'Show inherited H1 44–60pt,H2 24–32pt,body11–14pt print/18–24px digital; notes are application guidance.'),12:([9],'Arabic Roman/Bold; English Regular/Bold/Italic. No synthetic Arabic italic.'),13:([10],'Use six residential icons: home,location,handover,area,daylight,neighbourhood; minimum24px.'),14:([10],'Actual repeated architectural-pattern specimen.'),15:([10],'Actual inherited axonometric residential-illustration.svg, not an icon mislabeled illustration.'),16:([10],'Show architectural straight frame and low-contrast background; avoid patterns behind long text.'),17:([2],'Warm reassuring tone with real-estate professionalism; one concrete approved-style sentence; no unsupported promises.'),18:([12],'Front and back of90×55mm business card, with truthful fields.'),19:([12],'Actual QR example; mark demonstration and4-module quiet-zone rule; no false final company URL.'),20:([12],'Actual A4 letterhead example.'),21:([12],'Actual envelope family; captions DL220×110,C5229×162,C4324×229 mm.'),22:([15],'Distinct سند قبض example or clear detail paired with unit dossier.'),23:([14],'Actual folder cover and pocket face visible.'),24:([14],'Actual brochure inside/outside visible, A4 landscape tri-fold concept.'),25:([18],'Actual A5 flyer,148×210mm.'),26:([15],'Distinct إيصال sample; not substituted by سند قبض.'),27:([15],'Distinct A4 عرض سعر sample; no invented amounts or terms.'),28:([15],'Actual single-color wordmark stamp55×30mm; no invented license/address.'),29:([19],'Actual bag application visible.'),30:([19],'Actual welcome box application visible.'),31:([19],'Actual paper-cup application visible.'),32:([19],'Actual sticker sample(s) visible, may be discrete bottom detail strip.'),33:([18],'Actual roll-up850×2000mm visible, not only listed.')}
rows=[]
for x in base[:33]:
 n=int(x['id'][1:]); ep,display=mp[n]
 rows.append({'id':x['id'],'source':x['source'],'requirement_ar':x['requirement'],'full_guide_pages':x['pages'],'recommended_executive_pages':ep,'minimum_visible_evidence':display,'status':'planned; final export must be visually verified'})
new=[
 ('E01','Exactly20pages including independent cover andclosing',[1,20]),
 ('E02','Retain full62page guide byte-for-byte; separate newexecutivePDF',[]),
 ('E03','Book format and editorial grid, not automatic16:9',list(range(1,21))),
 ('E04','RTL reading,bindingdirection,andfacingpairs:2right/3left through18right/19left',list(range(2,20))),
 ('E05','Architectural keyvisual with exact composited branding',[4,13]),
 ('E06','Parent/subbrandrelationship; originaldescriptor untouched',[3]),
 ('E07','Secondarycolors andproportions50/30/15/5 pluscontrast',[7,8]),
 ('E08','Photography:light,perspective,materialtruth,conceptualdisclosure',[4,11,13,19]),
 ('E09','Propertylisting cards with truthful/unfilledfields',[15]),
 ('E10','Socialposts1080×1350 andstories1080×1920;250pxsafeareas',[16]),
 ('E11','Conceptual digitalinterface clearly not deployed; motion included',[17]),
 ('E12','Residentialadvertising andmarketingslides',[14,18]),
 ('E13','Editable sources+assets and inherited motion files',[]),
 ('E14','20page contact sheetoutsidebook+selected highrespreviews',[]),
 ('E15','Short separatevalidationPDFwithcrosswalk and actualresults',[]),
 ('E16','All20 exportedpagesreviewedindividually plusall9RTLspreads',list(range(1,21))),
 ('E17','Five reviews:artistic,editorial,brand,technical,executive',list(range(1,21))),
 ('E18','Embeddedfonts;vectorlogos; noSVGglyphorRTLfaults',list(range(1,21))),
 ('E19','PrintbleediffullbleedprintPDF; honestRGBdigitalstatus',[]),
 ('E20','No inventedfacts,companyclaims,listingprices orprojectstatus',list(range(1,21))),
 ('E21','External references usedfor layoutonly; no importedmarks/colors/fonts',list(range(1,21))),
 ('E22','Readabletechnicalinformation without excessive downsizing',[6,7,9,10,12,15,16,17,18,19]),
]
newrows=[{'id':i,'requirement':t,'recommended_executive_pages':p,'status':'planned'} for i,t,p in new]
pageplan=[
 (1,'الغلاف الفني',[1,7,62],'Isolated cover. Original residential lockup, disciplined book title, architectural image/detail; avoid overloaded labels.'),
 (2,'جوهر العلامة وصوتها',[2,5,6],'Quiet statement: ثقة،راحة،رقي معاصر. Include real-estate tone and one short direct invitation; no guarantee.'),
 (3,'أصل واحد؛ حضور سكني',[4,9,11],'Original andresidentiallockup,descriptoroutsideoriginal; H/4separationnotfulltechnicalrepeat. Pairedwith2.'),
 (4,'المشهد الرئيسي',[7,34,50],'Large architecturalbranding hero; actual suppliedlogo composited, nofakegeneratedletters. Pairedwith5.'),
 (5,'منظومة الشعار',[9,10,14],'PrimaryArabichero plusEnglishdescriptor,secondary,wordmark/iconvariants; exact inks andproportions.'),
 (6,'قواعد تحمي العلامة',[11,12,13,14,15],'Clearspace diagram +3minimumwidths +20–200range +correct/incorrectminiatures. Needs ample room.'),
 (7,'ألوان أفق معماري',[21,22,25],'Foureditorialswatches with everyHEX/RGB/CMYKvalue. ICC/printnoteone concise line. Pairswith6.'),
 (8,'اللون في الاستخدام',[23,24,35],'50/30/15/5 visualarea relationships; readableink/pearl/mist samples; warn copper fordetailonly.'),
 (9,'حروف واضحة',[27,28,29],'Arabic+English specimens,weights,italicsruleandnumericalhierarchy. Pair8quietcolorwithtypographicenergy.'),
 (10,'لغة معمارية',[30,31,32,33,35],'Grid as quietscaffold; visible6icons,pattern,frameandactualillustration. Avoidfulltechnicalparagraphs.'),
 (11,'الضوء والمكان',[7,34],'Dominantphotograph,threeshortprinciples; calmcounterpageto10.'),
 (12,'المراسلات المؤسسية',[36,37,38,39],'Letterhead+businesscardfront/backQR+DL/C5/C4envelopes. Movefinancialformsto15soeachretainsroom.'),
 (13,'الهوية على الواجهة',[50],'Large convincing physicalsignage/facadeapplication with exactlogo; needed newscene iffullguide onlyflatlayout.'),
 (14,'ملف العرض العقاري',[41,42,55],'Foldercover/pocket andbrochureinside/outside; smallmarketingpresentationpairifroom,otherwisep18.'),
 (15,'ملف الوحدة والمعاملة',[40,44,54],'Hero propertycard with truthfulfields. Subsidiary labeledspecimenstrip ofسندقبض/إيصال/عرضسعرandstamp. Showdetailsatreadablescale,notallentirepagesillegibly.'),
 (16,'الحضور الاجتماعي',[51,52,53],'Post andstory layouts; actualsafearea250px/1920 note; neutralcopywithoutlistedproperties.'),
 (17,'التجربة الرقمية والحركة',[16,57],'Conceptualweb/screendesign plusmotionstrip/stillsand6sec24fpsspec; includeactualvideoassets. Nofalse livewebsiteURL.'),
 (18,'الحملة السكنية',[43,49,53,55],'A5flyer+rollup+supportingad/presentationspecimens incontrolledscale; preserve allspecimenlabels.'),
 (19,'تجربة الترحيب',[45,46,47,48,56],'Bagandboxheroscene pluscupandstickeractualsmallsecondaryvisuals; onefamily ratherthanunrelatedmontage.'),
 (20,'الخاتمة',[62],'Isolatedclosingwithpreciseoriginallockup; shortcolophoncanlinkfulltechnicalguideandstateconceptualnature.'),
]
report={'scope':'Read-only requirements audit and proposed mapping; not final validation','full_guide':{'path':str(R/'AlDayel_Residential_Brand_Guidelines_PREMIUM_FINAL.pdf'),'page_count':62,'sha256':hashlib.sha256((R/'AlDayel_Residential_Brand_Guidelines_PREMIUM_FINAL.pdf').read_bytes()).hexdigest()},'screenshot_requirements':rows,'executive_requirements':newrows,'page_plan':[{'page':p,'title_ar':t,'full_guide_pages':f,'direction':d} for p,t,f,d in pageplan],'palette':json.loads((R/'assets/design-tokens.json').read_text())}
(O/'essential-elements-and-mapping.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
lines=['# Executive20P: requirements and source crosswalk','', '> Scope: read-only source analysis and proposed integration; this file does not certify a final executive PDF.','', '## Essential screenshot checklist — all33 retained','', '|ID|Requirement|Full guide|Executive|Minimum visible evidence|','|---|---|---|---|---|']
for r in rows: lines.append('|'+ '|'.join([r['id'],r['requirement_ar'],','.join(map(str,r['full_guide_pages'])),','.join(map(str,r['recommended_executive_pages'])),r['minimum_visible_evidence']])+'|')
lines+=['','## Proposed20page editorial mapping','','|Page|Purpose|Full guide|Integration|','|---|---|---|---|']
for p,t,f,d in pageplan: lines.append(f'|{p:02}|{t}|'+','.join(map(str,f))+'|'+d+'|')
lines+=['','## New executive acceptance requirements','','|ID|Requirement|Page scope|','|---|---|---|']
for x in newrows: lines.append('|'+x['id']+'|'+x['requirement']+'|'+','.join(map(str,x['recommended_executive_pages']))+'|')
(O/'essential-elements-and-mapping.md').write_text('\n'.join(lines)+'\n')
print('Wrote',O/'essential-elements-and-mapping.json')
