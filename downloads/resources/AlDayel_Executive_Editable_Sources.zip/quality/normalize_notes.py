from pathlib import Path
import json
p=Path('/workspace/codex/.work/executive-20p/requirements/essential-elements-and-mapping.json')
d=json.loads(p.read_text())
new=[
'Exactly 20 pages including independent cover and closing.',
'Retain the full 62-page guide byte-for-byte; create a separate executive PDF.',
'Choose book dimensions and an editorial grid; do not use automatic 16:9.',
'RTL reading and right-side binding; pairs 02 right / 03 left through 18 right / 19 left.',
'Architectural key visual with precisely composited official branding.',
'Parent/subbrand relationship; original descriptor remains untouched.',
'Secondary colors, 50/30/15/5 proportions, and contrast guidance.',
'Photography: natural light, plausible perspective, material truth, and conceptual disclosure.',
'Property listing cards with truthful or unfilled data fields.',
'Social posts 1080×1350 and stories 1080×1920, with 250 px story safe areas.',
'Conceptual digital interface clearly not deployed; include the inherited motion application.',
'Residential advertising and marketing presentation specimens.',
'Editable sources, linked assets, and inherited motion files.',
'20-page contact sheet outside the book, plus selected high-resolution previews.',
'Short separate validation PDF with a crosswalk and actual review results.',
'Inspect all 20 exported pages individually and all nine RTL interior spreads.',
'Five reviews: artistic, editorial, brand consistency, technical detail, executive presentation.',
'Embedded fonts, vector logos, correct Arabic shaping and numeric direction.',
'Actual bleed for a print PDF with full-bleed imagery; truthful RGB digital status.',
'No invented facts, company claims, listing prices, or project status.',
'External references inform layout only; never import their marks, palette, fonts, or content.',
'Keep essential technical information readable; reorganize rather than excessively downsize.'
]
for r,s in zip(d['executive_requirements'],new):r['requirement']=s
pages=[
'Independent cover. Original residential lockup, restrained book title, and architectural image or detail; avoid excessive labels.',
'Quiet statement: ثقة، راحة، رقي معاصر. Include the real-estate tone and one short concrete invitation without guarantees.',
'Original and residential lockups; descriptor outside original with H/4 separation. Pair the quiet statement on page 02 with this precise visual explanation.',
'Large architectural branding image with exact official vector logo placed on a plausible surface. Avoid generated lettering.',
'Primary Arabic mark as the main element, with inherited English descriptor, secondary, wordmark and icon variants; retain exact geometry.',
'Clear-space diagram, three minimum widths, the 20–200 mm range, and visible correct/incorrect examples. Allocate ample room.',
'Four editorial swatches with all HEX, RGB and CMYK values. Add one concise profile and print-proof note.',
'Visualize the 50/30/15/5 relationship and readable ink/pearl/mist combinations. Restrict copper to details and large text.',
'Arabic and English specimens with weights, italic rule and numerical hierarchy. Let typography carry the composition.',
'Use a quiet grid, actual six-icon set, repeated pattern, straight frame, and inherited axonometric illustration.',
'Dominant architectural photograph with three short principles; a calm counterpage to the graphic language on page 10.',
'Letterhead, business-card front/back with QR, and DL/C5/C4 envelopes. Move financial forms to page 15 to preserve scale.',
'Large convincing facade or signage application using exact logo geometry. The full guide has only a flat signage view, so a new physical scene adds value.',
'Folder cover/pocket and brochure inside/outside. Add marketing presentation specimens if room permits; otherwise move them to page 18.',
'Hero property card with truthful fields. Add distinct, labeled details for سند قبض, إيصال, عرض سعر and stamp; avoid illegible tiny whole pages.',
'Post and story layouts. Include the 250 px top/bottom safety guidance for a 1920 px story; use truthful illustrative content.',
'Conceptual website or screen plus a motion storyboard with 6 sec / 24 fps specification and supplied video assets. Do not invent a live company URL.',
'A5 flyer, roll-up and related advertisement or presentation specimens with controlled scale and clear labels.',
'Bag and welcome-box hero scene, with actual cup and sticker visuals as supporting details; maintain one coherent visual family.',
'Independent closing with precise original lockup. A small colophon may identify the full technical guide and conceptual visual status.'
]
for r,s in zip(d['page_plan'],pages):r['direction']=s
p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
lines=['# Executive 20P: requirements and source crosswalk','','> Scope: read-only source analysis and proposed integration. This file does not certify a final executive PDF.','','## Essential screenshot checklist — all 33 retained','','|ID|Requirement|Full guide pages|Executive pages|Minimum visible evidence|','|---|---|---|---|---|']
for r in d['screenshot_requirements']: lines.append('|'+ '|'.join([r['id'],r['requirement_ar'],', '.join(map(str,r['full_guide_pages'])),', '.join(map(str,r['recommended_executive_pages'])),r['minimum_visible_evidence']])+'|')
lines+=['','## Proposed 20-page editorial mapping','','|Page|Purpose|Full guide pages|Integration|','|---|---|---|---|']
for r in d['page_plan']:lines.append('|'+str(r['page'])+'|'+r['title_ar']+'|'+', '.join(map(str,r['full_guide_pages']))+'|'+r['direction']+'|')
lines+=['','## New executive acceptance requirements','','|ID|Requirement|Page scope|','|---|---|---|']
for r in d['executive_requirements']:lines.append('|'+r['id']+'|'+r['requirement']+'|'+', '.join(map(str,r['recommended_executive_pages']))+'|')
p.with_suffix('.md').write_text('\n'.join(lines)+'\n')
