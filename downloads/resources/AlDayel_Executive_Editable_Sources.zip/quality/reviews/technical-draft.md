# Executive book: technical draft review

Reviewed PDF SHA-256: `f4bf2a9f9b8615bb14559c6c9d9b875a9a4edb10fa16a0e144ce9eb3fbaeaa8e`

All20exported pages were opened individually; pages6,12,15 also received direct-PDF300DPI detail inspection. This draft is not final-approved.

## Open corrections

- Page5 — major: Bottom logo overlaps explanatory note. Reflow and separate lower variants/footnote, then inspect exported page.
- Page13 — minor: Inset artwork covers the ARRIVAL/02 kicker. Separate kicker and inset bounds, then inspect exported page.
- Page19 — major: Missing material image leaves broken-image placeholder and blank field. Supply final material image, rebuild and verify exported PDF image presence and page rendering.
- Pageformat — minor: Media/Crop box is239.86066×299.88932mm instead of exact240×300mm. Set final boxes to exact size without scaling page content; preserve physical logo dimensions.

## Verified technical properties

-39exact-topology vector logos. The sole deliberate deformation is the middle lower misuse instance on page6; no whole-page exclusion is used, and page15 is fully checked.
-Actual page6 ink widths:44.997501mm,19.994408mm,7.996293mm for nominal45/20/8mm.
-All10font resources are embedded, including ArabicType3 glyph streams; all have ToUnicode maps.
-Approved RGB vector fills match #1C3549/#F4F3EF/#CCDDE4/#A96B53.
-Catalog requests R2L and TwoPageRight. The source package excludes Helvetica binaries and retains permitted PT Sans font files/licence.
-Logical Arabic source text contains20ordered page sections. Copy/extraction behaviour remains viewer-dependent; source sidecar is the authoritative logical text.
-Complete guide is unchanged: `6afa44a0ceb60aa162b03463847dc820a8da44888a452dd395ddebaded26db7d`.

## Image resolution

Architectural source images are1122×1402px. Cover placement is199.47×199.10PPI; pages4/11/13 are approximately118.7PPI. Do not claim native300PPI printing. RGB digital master has no PDF/X production certification.

## Page notes

- **01:** Cover logo, endorsement and bilingual title are intact. Photograph is approximately199PPI at placement; no edge clipping.
- **02:** Arabic brand character and voice copy shape correctly. Footer and column content fit with no overlap.
- **03:** Parent and residential lockups remain intact; branch-clearance explanation is legible. No clipped Arabic.
- **04:** Full-bleed concept scene and overlaid caption are readable. Native effective source resolution approximately119PPI, not300PPI.
- **05:** Blocking overlap: lower wordmark intersects the closing explanatory note. Root has identified this and is rebuilding the spacing.
- **06:** All minimum-size labels and usage rules visible. Direct300DPI crop confirms crisp glyphs. Actual ink widths45/20/8mm verified numerically within0.01mm. Only middle wrong-use example intentionally stretches the original.
- **07:** Four palette records, HEX/RGB/CMYK labels and named-profile caveat are intact. Approved colours are exact8bit RGB vector fills.
- **08:** Ratios50/30/15/5 and contrast guidance are legible. No numerical or Arabic shaping failure; root is revising visual composition.
- **09:** Arabic and English type families/weights are clear. Application-size hierarchy and Arabic no-tracking/no-faux-italic rules remain.
- **10:** Illustration, six icons, frame/pattern samples and minimum stroke rules are intact. No text clipping.
- **11:** Image and photographic-language text remain clear. Source is1122×1402px at approximately119PPI placement; digital master is not native300PPI press imagery.
- **12:** Business cards, letterhead and envelopes are legible. Direct300DPI business-card crop confirms intact labels and visibly preserved QR quiet zone. QR destination still requires business approval/test as stated.
- **13:** Inset signage artwork obscures the ARRIVAL/02 kicker in the caption panel. Main signage logo remains clear. Root is revising this page. Full-page image is approximately119PPI.
- **14:** Folder and inside/outside brochure samples fit; captions, original marks and QR example are intact.
- **15:** Property card, voucher/receipt detail crops, quotation detail and stamp fit. Direct300DPI voucher crop confirms intact date/number labels and original logo; forms are intentionally partial detail views. All visible vector logos pass geometry audit; page15 is not exempt.
- **16:** Post/story examples have coherent sizes;250px safety instruction remains legible. No overlap or malformed text.
- **17:** Conceptual website layout and three animation frames are clear. Motion resolution, duration, frame rate and reduced-motion note retained.
- **18:** Flyer and roll-up specimens maintain proportions, captions and production-resolution caveat.
- **19:** Blocking incomplete page: material image is missing, leaving broken-image icon/alt text and blank field. Final render is pending.
- **20:** Closing master logo, independent endorsement and reference to unchanged complete guide remain intact.

## Final rerun

`python source/validate_executive.py --output quality/executive-technical.json`

The checker reports failures separately from native-image-PPI and Arabic-copy limitations. It never substitutes for visual review.
