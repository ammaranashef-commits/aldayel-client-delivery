# Executive 20P — art direction and reference review

Read-only review. Reviewed both external PDFs by rendering the long reference into 19 sequential slices, and all 33 pages of reference 2 into contact sequences with individual detail checks. Reviewed the latest 62-page PREMIUM_FINAL sequence, original logo extraction proof, and original Branding Assets identity/report. No reference-brand logo, color, typeface or graphic is licensed by this review for reuse.

## Design conclusion

The external references demonstrate a useful identity-rules → applications sequence, but they are not a suitable luxury-book template: repeated centered headings, fixed backgrounds, decorative curves and floating commodity mockups would reproduce the presentation aesthetic the user now rejects. Retain their discipline of showing rules beside examples. Build this edition through portrait proportions, asymmetric but stable editorial axes, generous binding space, and a small number of strong architectural images.

Format: 240 × 300 mm portrait. RTL reading. Front/back pages 1 and 20 stand alone. Proof pairs are 2–3, 4–5, 6–7, 8–9, 10–11, 12–13, 14–15, 16–17, 18–19; in a visible spread the even page is physically RIGHT, odd page LEFT. Keep 25 mm inner and 20 mm outer safety; upper margin 20–24 mm, lower 18–24 mm. The grid is a tool, not a visible repeating frame. Six columns per page, 4 mm gutters, 4 mm baseline. No logo/title may cross the binding. Crop continuity can cross the spread only in noncritical image zones. Use one or two deliberate edge bleeds; a print companion must preserve real 3 mm bleed, not add white media space and call it bleed.

Typography: Helvetica Neue LT Arabic Roman/Bold, PT Sans Regular/Bold/Italic, unchanged from approved identity. Main explanatory copy ideally 11.5–13 pt, short rules 10–11 pt, small captions no lower than 8.5–9 pt. No letterspacing on Arabic. Avoid multiple all-caps English header bands: tiny English is navigation, not a second competing headline. Align data values in LTR subspans. Modest folios at the outside corners; no full-width footer rules on every page.

## 20-page rhythm

| Page | Function and composition | Across-spread relationship |
|---|---|---|
| 01 | Artistic cover: pearl paper field, original residential lockup, one strongly cropped architectural image occupying ~60%; restrained book title and edition note. Do not enlarge both logo and title simultaneously. | Standalone; image and whitespace establish book vocabulary. |
| 02 | Brand essence: quiet pearl; large short Arabic line, one concise sentence and three small values; short verbal-voice example. | Quiet RIGHT to p3 mark-system LEFT. |
| 03 | Parent architecture: original parent mark above residential lockup; large measured separation, short distinction text. Exact original geometry. | Same baseline as p2 essence; pale mist or pearl keeps opening calm. |
| 04 | Architecture hero: image nearly/full bleed, authentic mark applied on a plausible physical sign surface, no text rendered inside generated image. One discreet caption establishes conceptual status. | Rich RIGHT against p5 quiet logo taxonomy LEFT. |
| 05 | Logo system: one dominant original signature and smaller precise accepted Arabic/English/icon/wordmark variants. Avoid a uniform six-card gallery. Show residential descriptor as independent text treatment. | Dominant mark axis echoes architectural verticals opposite. |
| 06 | Logo rules: true safe-area diagram X=H/4, actual 20mm specimen if space permits, primary/secondary/digital minima, few correct/incorrect vector examples. Use a disciplined two-zone layout, not tiny screenshots. | Technical RIGHT balanced by large color material blocks LEFT. |
| 07 | Palette: four uninterrupted rectangular fields at distinct heights with exact HEX/RGB/CMYK text, reading order deliberately consistent. CMYK profile note small but visible. | Calm large shapes give visual rest beside p6 density. |
| 08 | Color in use: one editorial composition or real application demonstrating pearl50/ink30/mist15/copper5; compact ratio strip and accessible text-pair samples. | Application RIGHT complements p9 typography LEFT. |
| 09 | Typography: large Arabic specimen and quieter English specimen; readable face names and real weights, three hierarchy rows and compact print/digital sizes. Avoid full alphabet clutter. | Maintain the same top datum as p8 but with different image/text balance. |
| 10 | Visual language: generous architectural line pattern or illustration, 6 bespoke icons, one frame/network sample. Three named functions, minimal text. | Diagram RIGHT opens into photographic LEFT. |
| 11 | Photography: substantial image crop, a secondary intimate material/light detail only if genuinely distinct; three terse principles. | Visual geometry of p10 continues via architectural lines, not copied pattern. |
| 12 | Institutional stationery: editorial still life plus legible close view of card/QR and brief inventory including letterhead, envelopes, forms, folder, stamp. | Paper/material RIGHT to built-environment LEFT. |
| 13 | Facade/signage: one strong, high-quality environmental view; small scale-true flat artwork detail and roll-up inset only if needed. No tiny fake typography. | Match light direction/material tone to p12 without repeating composition. |
| 14 | Property print: brochure and folder hero; one actual inside spread and supporting flyer. Broad whitespace; clear panel sequence. | Publication RIGHT to readable unit card LEFT. |
| 15 | Unit offers: large property card with real data-field labels, no invented commercial values; crop detail aligned to the page grid. | Both pages share a picture ratio, not identical placement. |
| 16 | Social: 1 post + 1 story at honest proportional scales, each visually strong; small story safe-area note. Avoid generic phone frames consuming space. | Dynamic RIGHT against calm screen LEFT. |
| 17 | Digital concept and motion: genuine editable website concept art, clearly concept; compact three-frame animation strip + 6sec/24fps/1080p/H.264. Avoid fake browser-dashboard chrome. | Shared anchor line with p16; maintain optical scale of logos. |
| 18 | Campaign: a large editorial ad, one alternative format/roll-up if not elsewhere; short message. No repeated full image from p4 unless materially different framing. | Campaign RIGHT to material brand experience LEFT. |
| 19 | In reality / welcome: largest exceptional physical mockup with bag, box, cups, stickers present and readable at useful scale; very sparse caption. | Penultimate visual crescendo; use contained material scene, not more floating cards. |
| 20 | Closing: original residential signature in broad pearl or ink negative space, a single calm line. No pseudo-luxury seals, metallic simulation or invented brand promise. | Standalone; quiet resolution of cover. |

## Hierarchy and rhythm safeguards

- A full-image or large-material composition should recur every 3–4 turns, not every second page by formula.
- Never repeat the exact two-column title-left/image-right template more than once in sequence.
- No more than three dominant hues in any one spread; corporate four-color precision remains on p7.
- The architectural photographs currently provided are only 1536 × 1024 px. At full portrait height they cannot truthfully be called 300ppi print photography. Use newly sourced/generated larger coherent scenes, or frame existing images at their justified scale. Do not disguise resolution through upsampling. Place conceptual disclaimer discreetly and consistently.
- Mockups from the finished guide now have clean vector-origin textures and realistic materials, but should not be mechanically reused at tiny scale. Favor one hero still life per relevant turn.
- Retain all screenshot requirements through a crosswalk, including often-lost animated logo, QR, stamp, formal forms/invoices/quote, envelopes, folder, brochure/flyer, bag/cup/stickers/roll-up. If each cannot be individually legible on p12/p19, distribute across p14/p17/p18; do not solve with a microscopic contact sheet.
- One book can be both a clear executive reference and a visual artifact: detailed specs belong in a restrained technical area on the relevant page, not a repeated legal footer.

## Review protocol for final output

Review all 20 exported page images individually, then all nine physically arranged RTL spreads; verify p1/p20 independently. Check optical equality, page-pair balance, binding safety, text legibility, distinctness of image subjects, and retention of every essential identity element. Pixel-level proof revisions require re-review of the changed pages and their spread neighbors. A contact sheet supports rhythm review but does not substitute for page inspection.
