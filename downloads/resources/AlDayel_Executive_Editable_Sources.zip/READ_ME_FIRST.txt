AlDayel Residential — Executive20P editable source package.
Start with source/README-executive.ar.md.
The commercial Arabic font binaries are intentionally not redistributed. Install the licensed originals and set ALDAYEL_FONT_DIR.
Generated book/report HTML and application PDF exports are omitted from this source ZIP; editable code, SVG inputs, textures and all used assets are included. All exports are also available separately in the repository.
Build the main PDF before rebuilding its validation report. To run the full preservation validator, also download the separately delivered full PREMIUM_FINAL guide into the package root.
