# تحرير PREMIUM وإعادة بنائه

المصدر التصميمي هو Python وHTML وCSS وSVG، وليس مشروع InDesign أو Illustrator متعدد الصفحات. الشعارات والتطبيقات المسطحة تُدرج كعناصر SVG مباشرة بأبعاد متناسبة؛ المشاهد المعمارية والموك أب صور. تتوفر مشاهد Blender الخاصة بالموك أب ومصادر التطبيقات والحركة بصورة مستقلة.

## المتطلبات

- Python 3.10 أو أحدث، وبيئة تدعم Playwright وChromium. Linux أو WSL مناسب لتشغيل كامل سلسلة التطبيقات.
- حزم `source/requirements-book.txt`، وChromium مثبت أو نسخة Playwright منه.
- نسختا المستخدم المرخّصتان: `HelveticaNeueLTArabic-Roman.otf` و`HelveticaNeueLTArabic-Bold.otf`. لا تُرفق الملفات التجارية بالحزمة ولا يُستبدل الخط بخط مشابه تلقائيًا.
- PT Sans موجود في `assets/fonts` مع الترخيص.

نفّذ الأوامر من جذر مجلد التسليم الذي يحتوي ملف PDF ومجلد `source`؛ اسمه `PREMIUM_FINAL` داخل مستودع GitHub. يمكن حفظ البيئة والذاكرة المؤقتة خارج مجلد التوزيع:

```bash
python3 -m venv ../.work/premium-venv
. ../.work/premium-venv/bin/activate
python -m pip install -r source/requirements-book.txt
python -m playwright install chromium
export ALDAYEL_FONT_DIR='/path/to/your/licensed/arabic-fonts'
```

إذا كنت تستخدم Chromium مثبتًا في مسار خاص، حدده بمتغير `CHROMIUM_PATH`. عند غيابه يحاول المصدّر اكتشاف Chromium النظام، ثم نسخة Playwright. إعداد الخطوط المحلي البديل هو `.work/fonts` المجاور لمجلد التسليم؛ يفضل تعيين `ALDAYEL_FONT_DIR` صراحةً.

## أين تعدّل

| الملف | دوره وترتيبه |
|---|---|
| `build_book.py` | يبني محتوى الصفحات الأساسي ويجمع الكتاب |
| `refine_application_spreads.py` | طبقة تنظيم التطبيقات الموروثة التي تسبق طبقات PREMIUM |
| `premium_editorial.py` | الاختصار والتحسين التحريري للنصوص والعناوين |
| `premium_applications.py` | يعيد تكوين صفحات التطبيقات 36–56 |
| `premium_layouts.py` | يصقل الأغلفة والصفحات الأساسية والفواصل والرسوم؛ الطبقة الأخيرة |
| `book.css` | القواعد والخطوط الأساسية |
| `premium.css` | قواعد الإخراج الجديدة المحملة بعد CSS الأساسي |
| `premium-applications.css` | تكوينات التطبيقات، محملة بعد الملفين السابقين |

كل طبقة متأخرة يمكن أن تستبدل تركيب صفحة من طبقة سابقة؛ عدّل الوحدة التي تنتج الصفحة أخيرًا. الملف `book.html` ناتج آلي قابل للفحص، وليس موضع التعديل الدائم. الألوان والمراجع تُقرأ من `assets/design-tokens.json` و`research/` دون تنزيل أرشيف خارجي.

المساعد `inline_svg` يحافظ على التناسب ومعرّفات SVG الفريدة. لا تفرض عرضًا وارتفاعًا غير متناسبين، ولا تعِد رسم الشعار. التفاصيل المكبرة في صفحات التطبيقات مقتطفات من المصدر المتجهي نفسه. عند تغيير عدد الصفحات، راجع الفهرس وترقيم الصفحات والتحقق من العدد في المولد؛ الإصدار الحالي 62 صفحة.

## بناء الدليل والنص والمعاينات

```bash
python source/build_book.py
python source/render_book.py --output AlDayel_Residential_Brand_Guidelines_PREMIUM_FINAL.pdf
python source/export_copyable_text.py
python source/preview_book.py --pdf AlDayel_Residential_Brand_Guidelines_PREMIUM_FINAL.pdf --output previews --dpi 200
```

ينشئ التصدير خادم HTTP مؤقتًا على loopback لعرض الخطوط والأصول، ثم يغلقه. لا ينشر الملفات ولا يرفعها إلى خدمة خارجية. فتح `book.html` مباشرة عبر `file://` قد يمنع تحميل الخط العربي؛ طريقة التصدير أعلاه تستخدم الخطوط المحددة دون نسخها إلى مجلد التسليم.

النواتج: PDF العرض، و`source/book.html`، وفهرس `quality/page-manifest.json`، و`quality/browser-layout-check.json`، ونسخة النص `source/book-copyable-text.ar.txt`، ومعاينات JPG بدقة 200 DPI وغلاف PNG. تتضمن `previews/contact-*.jpg` لوحات مختصرة للتصفح؛ لا تغني عن فتح الصفحات منفردة.

## التحقق بعد التعديل

```bash
python source/validate_pdf.py AlDayel_Residential_Brand_Guidelines_PREMIUM_FINAL.pdf --output quality/premium-technical-recheck.json
```

راجع تحميل الخطوط والصور وحدود الصفحات في `quality/browser-layout-check.json`. الفحوص الآلية مساعدة؛ افتح جميع صفحات PDF المصدّر بصريًا، وكبّر الشعار والنصوص الصغيرة والتطبيقات. افحص هندسة الشعار داخل PDF باستخدام `validate_pdf_logo_affine.py`، مع تفسير أمثلة الاستخدام الخاطئ المقصودة في ص15 بصورة مستقلة.

نسخة النص الحي تحفظ Unicode بالترتيب المنطقي. قد يختلف ترتيب نسخ العربية أو التشكيل بين قارئات PDF واستخراج Chromium؛ المظهر الصحيح لا يضمن تطابق نتائج جميع مستخرجات النص. ملف TXT لا يعيد تكوين نصوص SVG المحوّلة لمسارات أو النص المرسوم داخل الصور؛ مصادر `applications/editable/` هي المرجع لتحريرها. لا توجد شهادة PDF/UA أو ضمان توافق شامل مع قارئات الشاشة.

## التقرير المختصر

ملفا التقرير هما `build_premium_review.py` و`render_premium_review.py` مع `premium-review.css`. التقرير لا يُبنى قبل اكتمال سجل `quality/premium-final-verification.json` المطابق للدليل المصدّر والمعاينات.

بعد تنفيذ المراجعات الفنية والتفصيلية ومراجعة المظهر الآلي على جميع الصفحات وتوثيق نتائجها الفعلية:

```bash
python source/build_premium_review.py
python source/render_premium_review.py --output AlDayel_Premium_Final_Review.pdf
```

يتحقق المولد من تغطية الصفحات الـ62 في المراجعات الثلاث، وعدم وجود مشكلات مفتوحة، والتحقق من الشعار وحفظ النسخة السابقة. يفحص المصدّر ارتباط HTML التقرير بسجل التحقق الحالي. لا تُملأ نتائج النجاح افتراضيًا، ولا يُعاد استخدام سجل نسخة سابقة بعد تغيير PDF. افحص صفحتي التقرير بصريًا بعد تصديرهما أيضًا.

## التطبيقات والموك أب والحركة

- تعليمات SVG وPDF للتطبيقات: [README-applications.md](README-applications.md). تتطلب إعادة توليدها Inkscape وحزم `requirements-applications.txt` والخطوط الأصلية. تعديل قوالبها يحتاج إعادة توليد النسخ الحية والمحوّلة إلى مسارات والمعاينات.
- مشاهد Blender والخامات والكاميرات: [mockups/README.md](mockups/README.md). تتضمن زاوية مستقلة لتجربة الترحيب `mockup_packaging_welcome.png` في ص56. أعد توليد HTML بعد توفير هذا الأصل لتلتقطه وحدة التطبيقات.
- فيديو الشعار ومصدره: [motion-notes.md](../motion/motion-notes.md).

## حدود الاستخدام والإنتاج

PDF الرئيسي للعرض الإداري الرقمي RGB؛ ليس ملف PDF/X أو فصل ألوان نهائيًا. تُراجع ملفات ICC والخامة والنزف والقص والثني وعينات اللون مع المطبعة. قوالب الأكياس والعلب والأكواب مفاهيم تصميمية تتكيف مع قالب المورد، ولا تمثل اعتمادًا إنشائيًا أو تصنيعًا جاهزًا. يلزم التحقق من دقة صور الرول أب واللافتات عند المقاس النهائي.

المشاهد المعمارية تصورية مولّدة، والموك أب ثلاثي الأبعاد؛ لا تُنسب إلى عقارات أو منتجات فعلية للشركة. رمز QR تجريبي معلن، وبيانات الشركة والعقار والتواصل تُستكمل من المراجع المعتمدة قبل الاستخدام. الألوان الرسمية تُؤخذ من القيم المحددة، لا من صورة مضاءة أو خامة محاكاة.
