#!/usr/bin/env python3
"""Export live book text in source Unicode order, without PDF extractor artefacts.

This intentionally does not pretend that text outlined inside application SVGs or
drawn in raster mockups is selectable book text. Those assets have their editable
SVG source files. Logo shapes are preserved as the original geometry.
"""
from pathlib import Path
from html.parser import HTMLParser
import hashlib, json, re

ROOT = Path(__file__).resolve().parent.parent


class Pages(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.pages = []; self.current = None; self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag == 'section' and 'page' in dict(attrs).get('class', '').split():
            self.current = []
        if tag in ['svg', 'script', 'style']:
            self.skip += 1
        if tag == 'br' and self.current is not None and not self.skip:
            self.current.append('\n')

    def handle_endtag(self, tag):
        if tag in ['svg', 'script', 'style']:
            self.skip = max(0, self.skip - 1)
        if self.current is not None and not self.skip:
            if tag in ['h1', 'h2', 'h3', 'p', 'div', 'header', 'footer', 'li']:
                self.current.append('\n')
            if tag == 'section':
                text = ''.join(self.current)
                text = re.sub(r'[ \t]+', ' ', text)
                text = re.sub(r' *\n *', '\n', text)
                text = re.sub(r'\n{3,}', '\n\n', text).strip()
                self.pages.append(text); self.current = None

    def handle_data(self, data):
        if self.current is not None and not self.skip:
            self.current.append(data)


if __name__ == '__main__':
    html = ROOT / 'source/book.html'
    parser = Pages(); parser.feed(html.read_text())
    text_file = ROOT / 'source/book-copyable-text.ar.txt'
    text_file.write_text('\n\n'.join(f'الصفحة {i}\n{text}' for i, text in enumerate(parser.pages, 1)))
    report = {
        'html_sha256': hashlib.sha256(html.read_bytes()).hexdigest(),
        'plain_text_file': str(text_file.relative_to(ROOT)),
        'plain_text_sha256': hashlib.sha256(text_file.read_bytes()).hexdigest(),
        'scope': 'Visible live HTML text only. Application SVGs, logo paths and raster mockups are not reconstituted. Editable application SVG sources supply their text.',
        'pages': [{'page': i, 'characters': len(text),
                   'unicode_sha256': hashlib.sha256(text.encode()).hexdigest()}
                  for i, text in enumerate(parser.pages, 1)],
    }
    final_pdf = ROOT / 'AlDayel_Residential_Brand_Guidelines_PREMIUM_FINAL.pdf'
    if final_pdf.is_file():
        report['pdf_file'] = final_pdf.name
        report['pdf_sha256'] = hashlib.sha256(final_pdf.read_bytes()).hexdigest()
    report_path = ROOT / 'quality/final-source-text-digest.json'
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(json.dumps({'pages': len(parser.pages), 'text_file': str(text_file)}))
