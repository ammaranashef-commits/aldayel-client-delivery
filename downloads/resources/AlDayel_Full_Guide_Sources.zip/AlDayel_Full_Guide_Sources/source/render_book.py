"""Render the editable HTML book to a searchable, vector-preserving PDF."""
from pathlib import Path
import argparse, asyncio, json, os, threading, shutil
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
from playwright.async_api import async_playwright
import fitz

ROOT = Path(__file__).resolve().parent.parent

async def render(destination):
    font_dir=Path(os.environ.get('ALDAYEL_FONT_DIR',ROOT.parent/'.work/fonts')).resolve()
    font_names=['HelveticaNeueLTArabic-Roman.otf','HelveticaNeueLTArabic-Bold.otf']
    for name in font_names:
        if not (font_dir/name).is_file():
            raise FileNotFoundError(f'Supply your licensed Arabic fonts via ALDAYEL_FONT_DIR: {name}')
    class Handler(SimpleHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_GET(self):
            prefix='/__aldayel_fonts/'
            if self.path.startswith(prefix):
                name=self.path[len(prefix):]
                if name not in font_names:
                    self.send_error(404); return
                data=(font_dir/name).read_bytes()
                self.send_response(200)
                self.send_header('Content-Type','font/otf')
                self.send_header('Content-Length',str(len(data)))
                self.end_headers(); self.wfile.write(data); return
            return super().do_GET()
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(Handler,directory=str(ROOT.parent)))
    worker=threading.Thread(target=server.serve_forever,daemon=True); worker.start()
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium'), headless=True,
            args=['--no-sandbox','--disable-dev-shm-usage'])
        page = await browser.new_page(viewport={'width':1600,'height':900}, device_scale_factor=1)
        errors=[]
        page.on('pageerror', lambda error: errors.append(str(error)))
        await page.goto(f'http://127.0.0.1:{server.server_address[1]}/{ROOT.name}/source/book.html',wait_until='load')
        await page.evaluate('document.fonts.ready')
        await page.emulate_media(media='print')
        await page.evaluate("Promise.all(Array.from(document.images).map(i=>i.decode().catch(()=>{})))")
        check=await page.evaluate('''() => ({
            images:[...document.images].filter(i=>!i.complete||!i.naturalWidth).map(i=>i.getAttribute('src')),
            fonts:[...document.fonts].map(f=>({family:f.family,status:f.status,weight:f.weight})),
            pages:[...document.querySelectorAll('.page')].map((p,i)=>{
                const r=p.getBoundingClientRect();
                const outside=[...p.querySelectorAll('h1,h2,h3,p,.caption,.note,.source-item,.toc-row')].filter(e=>{
                    const b=e.getBoundingClientRect();
                    return b.left<r.left-1||b.right>r.right+1||b.top<r.top-1||b.bottom>r.bottom-43;
                }).map(e=>({tag:e.tagName,text:e.textContent.slice(0,130),top:e.getBoundingClientRect().top-r.top,bottom:e.getBoundingClientRect().bottom-r.top}));
                return {number:i+1,title:p.querySelector('h1')?.textContent,width:r.width,height:r.height,outside};
            })
        })''')
        check['javascript_errors']=errors
        raw=destination.with_name(destination.stem+'-raw.pdf')
        await page.pdf(path=str(raw),print_background=True,prefer_css_page_size=True)
        await browser.close()
    server.shutdown(); server.server_close()
    doc=fitz.open(raw)
    doc.set_metadata({'title':'الدايل السكني | AlDayel Residential PREMIUM FINAL',
        'author':'AlDayel Residential','subject':'Visual and verbal identity, applications and documented color research',
        'keywords':'AlDayel Residential, الدايل السكني, brand identity, guidelines, 2026',
        'creator':'Editable HTML/CSS/SVG brand system'})
    manifest=json.loads((ROOT/'quality/page-manifest.json').read_text())
    doc.set_toc([[1,item['title'],item['page']] for item in manifest])
    doc.save(destination,garbage=4,deflate=True)
    doc.close(); raw.unlink()
    check['pdf']=str(destination)
    check['pdf_pages']=len(fitz.open(destination))
    (ROOT/'quality/browser-layout-check.json').write_text(json.dumps(check,ensure_ascii=False,indent=2))
    print(json.dumps({'pdf':str(destination),'pages':check['pdf_pages'],
        'missing_images':check['images'],
        'pages_with_overflow':[x['number'] for x in check['pages'] if x['outside']],
        'fonts':check['fonts']},ensure_ascii=False))

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',default=str(ROOT/'AlDayel_Residential_Brand_Guidelines_PREMIUM_FINAL.pdf'))
    args=parser.parse_args()
    destination=Path(args.output).resolve(); destination.parent.mkdir(parents=True,exist_ok=True)
    asyncio.run(render(destination))
