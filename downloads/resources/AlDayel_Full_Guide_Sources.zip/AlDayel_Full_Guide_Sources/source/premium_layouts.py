"""Art-directed refinements for the PREMIUM edition; original assets stay intact."""
from pathlib import Path
import json, re

ROOT = Path(__file__).resolve().parent.parent
INK, PEARL, MIST, COPPER = '#1C3549', '#F4F3EF', '#CCDDE4', '#A96B53'

def apply(pages, logo, app):
    def put(n, title, body, theme=''):
        item = pages[n-1]
        item['title'] = title
        item['html'] = f'''<section class="page premium {theme}" id="p{n}"><header class="running"><span>ALDAYEL / RESIDENTIAL</span><span class="ar">{item['section']}</span></header><h1 class="title">{title}</h1><div class="body">{body}</div><footer class="footer"><span>{n:02d} / BRAND GUIDELINES</span><span class="ar">الدايل السكني · 2026</span></footer></section>'''

    pages[0]['html'] = f'''<section class="page premium-cover" id="p1"><div class="cover-photo"><img class="photo" src="../assets/images/concept_residential_exterior.png" alt="عمارة سكنية تصورية" style="object-position:70% center"></div><div class="cover-editorial"><div class="cover-mark">{logo(width=388,branch=True)}</div><div class="cover-copy"><div class="kicker">ALDAYEL RESIDENTIAL</div><h1>دليل الهوية<br>البصرية واللفظية</h1><p class="en">Brand Identity Guidelines</p><div class="cover-fine-rule"></div><p class="cover-edition">PREMIUM EDITION / 2026</p></div><div class="cover-bottom"><span>الدايل السكني</span><span>مشهد معماري تصوري</span></div></div></section>'''

    put(2,'مساحة للحياة',f'''<div class="intro-layout"><div class="intro-copy"><div class="kicker">SPACE / LIGHT / BELONGING</div><h2 class="intro-statement">حضور هادئ.<br>تفاصيل واضحة.</h2><div class="short-rule"></div><p>لغة سكنية معاصرة تحتفظ بشعار الدايل الأصلي، وتمنح الفرع حضوره اللوني والتطبيقي المستقل.</p><p class="caption muted">عبارة افتتاحية تحريرية؛ ليست شعارًا لفظيًا معتمدًا.</p></div><div class="photo-frame intro-photo"><img class="photo" src="../assets/images/concept_residential_interior.png" alt="مشهد داخلي تصوري" style="object-position:55% center"></div></div>''')

    contents=[('01','العلامة وصوتها','04–07','الشخصية، النبرة، والاتجاه البصري'),('02','الشعار','08–16','التوقيع، قواعد الاستخدام، والحركة'),('03','اللون','17–25','البحث، المواصفات، والتباين'),('04','اللغة البصرية','26–35','الخطوط، الأيقونات، والصور'),('05','التطبيقات','36–56','القرطاسية، التغليف، والتواصل'),('06','الأصول والإنتاج','57–62','الملفات، المراجع، وحدود الاستخدام')]
    put(3,'محتويات الدليل','<div class="premium-contents">'+''.join(f'<div class="contents-item"><div class="contents-index en">{i}</div><div><h2>{title}</h2><p class="small muted">{desc}</p></div><div class="contents-range en">{ran}</div></div>' for i,title,ran,desc in contents)+'</div>')

    chapters=[(8,2,'الشعار','THE ORIGINAL MARK','أصل ثابت. استعمال دقيق.',logo(color='pearl',width=440)),(17,3,'اللون','COLOR SYSTEM','عمق الحبر. اتساع الضوء.','<div class="chapter-colors"><div style="background:#F4F3EF;flex:5"></div><div style="background:#CCDDE4;flex:3"></div><div style="background:#A96B53;flex:1"></div></div>'),(26,4,'اللغة البصرية','TYPE & VISUAL LANGUAGE','حروف واضحة. مساحات مدروسة.','<div class="chapter-type"><span>أ ب ت</span><span class="en">Aa</span></div>')]
    for n,num,title,en,sub,visual in chapters:
        pages[n-1]['title']=title
        pages[n-1]['html']=f'''<section class="page premium chapter-editorial ink" id="p{n}"><header class="running"><span>ALDAYEL / RESIDENTIAL</span><span>{en}</span></header><div class="chapter-composition"><div class="chapter-copy"><span class="chapter-index en">{num:02d}</span><h1>{title}</h1><p>{sub}</p></div><div class="chapter-visual">{visual}</div></div><footer class="footer"><span>{n:02d} / BRAND GUIDELINES</span><span class="ar">الدايل السكني · 2026</span></footer></section>'''

    # The dimension brackets follow actual ink bounds, not the SVG viewport.
    meta=next(x for x in json.loads((ROOT/'assets/logos/original/provenance.json').read_text()) if x['variant']=='primary-ar')
    view_w=meta['viewport'][2]-meta['viewport'][0]
    view_h=meta['viewport'][3]-meta['viewport'][1]
    w=440; h=w*meta['logo_height']/view_w; x=h/4; vh=w*view_h/view_w; pad=.5*w/view_w
    left,top=115,138
    body=f'''<div class="split"><div class="vcenter"><h2>وصف مستقل عن الشعار</h2><p style="margin-top:22px">يوضع «السكني» أسفل التوقيع الأصلي، بعد فراغ لا يقل عن ربع ارتفاعه. تبقى المحاذاة مركزية، ولا تُستبدل عبارة «مركز الدايل العقاري».</p><div class="rule"></div><p class="small"><bdi dir="ltr">X = H/4</bdi> · العربية: Helvetica Neue LT Arabic<br>الإنجليزية: PT Sans · الخط الفاصل اختياري.</p><p class="note">قاعدة خاصة بالفرع السكني، وليست من الدليل القديم.</p></div><div class="dimension-stage"><div style="position:absolute;left:{left}px;top:{top}px">{logo(width=w)}</div><div class="endorsement-text" style="position:absolute;left:{left}px;top:{top+vh+x+4}px;width:{w}px">السكني<span class="en">RESIDENTIAL</span></div><div class="measure-vertical" style="left:{left+w+38}px;top:{top+pad}px;height:{h}px"><b>H</b></div><div class="measure-vertical" style="left:{left+w+38}px;top:{top+vh-pad}px;height:{x+4+pad}px"><b>≥ X</b></div><div class="labels dimension-caption">X = H / 4</div></div></div>'''
    put(11,'التوقيع السكني',body)

    w=480; h=w*meta['logo_height']/view_w; x=h/4; vh=w*view_h/view_w; pad=.5*w/view_w
    left,top=104,172
    put(12,'المساحة الآمنة',f'''<div class="split"><div class="vcenter"><div class="en" style="font-size:76px;line-height:1.2">X = H / 4</div><h2 style="margin-top:22px">فراغ يحفظ حضور العلامة</h2><p style="margin-top:20px">تُترك مسافة X على الجهات الأربع، ويُقاس H على حدود الحبر الفعلية للشعار. لا تدخل النصوص أو الصور أو حدود القص هذه المساحة.</p><p class="note">هذه حدود دنيا؛ تُفضّل مساحة أوسع في الأغلفة واللافتات.</p></div><div class="dimension-stage"><div class="safe-field" style="left:{left+pad-x}px;top:{top+pad-x}px;width:{w-2*pad+2*x}px;height:{h+2*x}px"></div><div style="position:absolute;left:{left}px;top:{top}px">{logo(width=w)}</div><div class="ink-boundary" style="left:{left+pad}px;top:{top+pad}px;width:{w-2*pad}px;height:{h}px"></div><div class="measure-vertical" style="left:{left+w+x+26}px;top:{top+pad}px;height:{h}px"><b>H</b></div><div class="measure-vertical" style="left:{left+w/2}px;top:{top+pad-x}px;height:{x}px"><b>X</b></div><div class="measure-horizontal" style="left:{left+pad-x}px;top:{top+h/2}px;width:{x}px"><b>X</b></div><p class="dimension-caption small">القياس على حدود الحبر، لا على لوحة الرسم.</p></div></div>''')

    put(21,'أفق معماري',f'''<div class="horizon-palette"><div class="horizon-signature">{logo(color='pearl',width=415,branch=True)}<p class="en">INK / #1C3549</p></div><div class="horizon-tones"><div class="tone tone-pearl"><h2>أبيض لؤلؤي</h2><p class="en">PEARL / #F4F3EF</p></div><div class="tone tone-mist"><h2>ضباب أزرق</h2><p class="en">MIST / #CCDDE4</p></div><div class="tone tone-copper"><span>نحاس</span><span class="en">COPPER / #A96B53</span></div></div></div><p class="caption">حبر للحضور، لؤلؤي للمساحة، ضباب للربط، ونحاس للتفاصيل.</p>''')

    # A coherent axonometric: roof, two visible faces, recessed opening, forecourt.
    illustration=f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 760 600" role="img" aria-label="رسم معماري تصوري بكتل واضحة"><g stroke="{INK}" stroke-width="1.8" stroke-linejoin="miter"><path d="M70 405 345 267 700 445 425 582Z" fill="{PEARL}"/><path d="M70 405v14l355 177 275-137v-14L425 582Z" fill="{MIST}"/><path d="M150 210 410 340v200L150 410Z" fill="{MIST}"/><path d="M410 340 650 220v200L410 540Z" fill="{PEARL}"/><path d="M150 210 390 90 650 220 410 340Z" fill="{PEARL}"/><path d="M300 211 390 166 482 212 392 257Z" fill="{INK}"/><path d="M300 211v18l92 46 90-45v-18l-90 45Z" fill="{MIST}"/><path d="M210 289 280 324v151l-70-35Z" fill="{PEARL}"/><path d="M210 289v151l12-6V307l58 29" fill="none"/><path d="M459 345 598 275v93l-139 70Z" fill="{MIST}"/><path d="M459 345v93l12-6v-79l127-64M506 321v93M552 298v93" fill="none"/><path d="M180 458 340 538M506 512 651 440" stroke="{COPPER}" fill="none"/></g></svg>'''
    put(33,'رسم يوضّح المساحة',f'''<div class="illustration-layout"><div class="illustration-copy"><h2>كتلة. ضوء. فراغ.</h2><p>منظور محوري بسيط يشرح علاقة الكتلة بالفتحات، ضمن اللغة الخطية للهوية.</p><div class="short-rule"></div><p class="small">رسم تصوري مساعد؛ لا يمثل مخططًا هندسيًا أو أبعاد مشروع فعلي.</p></div><div class="illustration-art">{illustration}</div></div>''')

    put(34,'الصورة المعمارية','''<div class="photographic-layout"><div class="photo-frame" style="height:420px"><img class="photo" src="../assets/images/concept_residential_exterior.png" alt="عمارة سكنية تصورية" style="object-position:65% center"></div><div class="photo-frame" style="height:420px"><img class="photo" src="../assets/images/concept_residential_interior.png" alt="تفصيل من مشهد داخلي تصوري" style="object-position:23% center"></div></div><div class="photo-principles"><div><span class="en">01</span><h3>ضوء طبيعي</h3><p class="small">تعريض متزن وملمس واضح.</p></div><div><span class="en">02</span><h3>عمارة مفهومة</h3><p class="small">منظور مستقيم وعلاقات مكانية واضحة.</p></div><div><span class="en">03</span><h3>عرض صادق</h3><p class="small">تمييز المشاهد التصورية، واعتماد حقوق الصور الفعلية.</p></div></div>''')

    pages[61]['html']=f'''<section class="page premium-close ink" id="p62"><header class="running"><span>ALDAYEL / RESIDENTIAL</span><span>BRAND IDENTITY / 2026</span></header><div class="closing-mark">{logo(color='pearl',width=480,branch=True)}</div><div class="closing-copy"><div class="short-rule"></div><p>أصل ثابت. حضور سكني واضح.</p><span class="en">ALDAYEL RESIDENTIAL</span></div><footer class="footer"><span>62 / BRAND GUIDELINES</span><span>PREMIUM EDITION</span></footer></section>'''

    # Disclosures remain legible, away from the photographic focal point.
    image_pages={1,2,7,14,34,35,36,38,42,43,45,47,49,50,51,52,53,54,55,56}
    for n,item in enumerate(pages,1):
        item['html']=re.sub(r'<span class="photo-cap"[^>]*>.*?</span>','',item['html'])
        if n in image_pages and n != 1:
            item['html']=item['html'].replace('<footer class="footer">','<footer class="footer"><span class="visual-disclosure ar">صور وتطبيقات تصوّرية</span>',1)
    return pages
