"""Build the short PREMIUM review only after final verification is complete.

Required verification schema (quality/premium-final-verification.json):
{
  "page_count": 62,
  "reviews": [
    {"name": "Artistic Review", "pages_reviewed": 62, "open_major": 0},
    {"name": "Professional Detail Review", "pages_reviewed": 62, "open_major": 0},
    {"name": "AI Appearance Review", "pages_reviewed": 62, "open_major": 0}
  ],
  "logo_geometry_verified": true,
  "baseline_preserved": true
}

pages_reviewed can alternatively be the explicit list of page numbers. If
present, open_minor / open_issues must also be empty or zero. No draft report
or invented review result is generated when the verification is absent.
"""
from __future__ import annotations

import argparse
import hashlib
import html
import json
from pathlib import Path

import fitz


ROOT = Path(__file__).resolve().parent.parent
VERIFICATION = ROOT / 'quality/premium-final-verification.json'
MAIN_PDF = ROOT / 'AlDayel_Residential_Brand_Guidelines_PREMIUM_FINAL.pdf'
REVIEW_NAMES = (
    'Artistic Review',
    'Professional Detail Review',
    'AI Appearance Review',
)


def _no_open_items(value):
    if isinstance(value, (list, tuple, dict)):
        return len(value) == 0
    return type(value) is int and value == 0


def verified_results(path=VERIFICATION):
    """Load completed verification, failing closed on incomplete review data."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f'Final verification is required before the review report: {path}')
    payload = path.read_bytes()
    data = json.loads(payload)
    count = data.get('page_count')
    if type(count) is not int or count != 62:
        raise ValueError('Final verification must cover the complete 62-page guide')
    if data.get('logo_geometry_verified') is not True:
        raise ValueError('Original logo geometry has not been verified')
    if data.get('baseline_preserved') is not True:
        raise ValueError('The previous FINAL delivery has not been confirmed preserved')
    reviews = data.get('reviews')
    if not isinstance(reviews, list) or len(reviews) != 3:
        raise ValueError('Exactly three completed review records are required')
    by_name = {entry.get('name'): entry for entry in reviews}
    if set(by_name) != set(REVIEW_NAMES):
        raise ValueError(f'Review names must be: {", ".join(REVIEW_NAMES)}')
    for name in REVIEW_NAMES:
        item = by_name[name]
        reviewed = item.get('pages_reviewed')
        if isinstance(reviewed, list):
            complete = len(reviewed) == count and all(type(n) is int for n in reviewed) and sorted(reviewed) == list(range(1, count + 1))
        else:
            complete = type(reviewed) is int and reviewed == count
        if not complete:
            raise ValueError(f'{name} has not reviewed all {count} pages')
        if not _no_open_items(item.get('open_major')):
            raise ValueError(f'{name} has unresolved major issues or no recorded result')
        for key in ('open_minor', 'open_issues'):
            if key in item and not _no_open_items(item[key]):
                raise ValueError(f'{name} has unresolved {key}')
    for key in ('open_major', 'open_minor', 'open_issues'):
        if key in data and not _no_open_items(data[key]):
            raise ValueError(f'Final verification has unresolved {key}')
    if not MAIN_PDF.is_file():
        raise FileNotFoundError(f'The exported PREMIUM guide is required: {MAIN_PDF}')
    with fitz.open(MAIN_PDF) as document:
        if len(document) != count:
            raise ValueError('Verification page count differs from the exported PREMIUM PDF')
    recorded_hash = data.get('main_pdf_sha256') or data.get('pdf_sha256')
    if recorded_hash and hashlib.sha256(MAIN_PDF.read_bytes()).hexdigest() != recorded_hash:
        raise ValueError('Verification checksum differs from the exported PREMIUM PDF')
    return data, hashlib.sha256(payload).hexdigest()


def build(verification=VERIFICATION, output=None):
    result, verification_hash = verified_results(verification)
    cover = ROOT / 'previews/page-01.jpg'
    if not cover.is_file():
        raise FileNotFoundError(f'Render the final cover preview before the review: {cover}')
    count = result['page_count']
    changes = [
        ('الغلاف وإيقاع الكتاب', 'غلاف وفواصل أوضح، وتناوب مدروس بين الصفحات الهادئة والتطبيقات.'),
        ('نص أقل. حضور أقوى.', 'عناوين أقصر وشرح أكثر مباشرة، مع حفظ القواعد والمواصفات التقنية.'),
        ('قواعد أوضح بصريًا', 'مخططات أدق للمساحة الحرة، ورسوم توضيحية متسقة مع اللغة المعمارية.'),
        ('تطبيقات أكثر اتزانًا', 'تنويع التكوينات وتحسين أحجام العرض والمحاذاة والمساحات المحيطة.'),
        ('موك أب أكثر تماسكًا', 'تحسين الإضاءة والخامات في المشاهد الثلاثية الأبعاد بالشعار الأصلي.'),
    ]
    change_html = ''.join(
        f'<div class="change"><h2>{html.escape(title)}</h2><p>{html.escape(body)}</p></div>'
        for title, body in changes
    )
    review_labels = [
        ('المراجعة الفنية', 'Artistic Review'),
        ('مراجعة التفاصيل', 'Professional Detail Review'),
        ('مراجعة المظهر الآلي', 'AI Appearance Review'),
    ]
    cards = ''.join(
        f'<article class="review-card"><div class="review-name" lang="en" dir="ltr">{name}</div>'
        f'<h2>{label}</h2><div class="count" lang="en" dir="ltr">{count}<span> / {count}</span></div>'
        '<p>صفحة مفحوصة · دون مشكلات جوهرية مفتوحة</p></article>'
        for label, name in review_labels
    )
    document = f'''<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="verification-sha256" content="{verification_hash}">
<title>الدايل السكني — مراجعة التسليم الاحترافية</title>
<link rel="stylesheet" href="premium-review.css"></head><body>
<section class="review-page" id="review-1">
  <header class="running"><span lang="en" dir="ltr">ALDAYEL / RESIDENTIAL</span><span>مراجعة التسليم الاحترافية</span></header>
  <div class="heading"><div class="eyebrow" lang="en" dir="ltr">PREMIUM FINAL REVIEW</div><h1>صقل الهوية. حفظ الأصل.</h1></div>
  <main class="changes-layout">
    <div class="change-list">{change_html}</div>
    <div class="visual-summary">
      <figure><img src="../previews/page-01.jpg" alt="الغلاف النهائي المحسّن لدليل الدايل السكني"><figcaption>الغلاف من نسخة PREMIUM FINAL</figcaption></figure>
      <div class="editorial-metric"><div class="percentage" lang="en" dir="ltr">62</div><p>صفحة راجعتها ثلاثة مسارات مستقلة.<br><span>أُعيد فحص الصفحات المعدّلة بعد التصدير، مع توثيق تطابق بقية الصفحات بصريًا.</span></p></div>
    </div>
  </main>
  <footer><span lang="en" dir="ltr">01 / 02</span><span>الدايل السكني · ملخص التحسينات</span></footer>
</section>
<section class="review-page" id="review-2">
  <header class="running"><span lang="en" dir="ltr">ALDAYEL / RESIDENTIAL</span><span>نتائج المراجعة وحدود التسليم</span></header>
  <div class="heading"><div class="eyebrow" lang="en" dir="ltr">VERIFIED DELIVERY</div><h1>ثلاث مراجعات. تغطية كاملة.</h1></div>
  <main>
    <div class="review-grid">{cards}</div>
    <div class="preservation"><p><b>هندسة الشعار الأصلي محفوظة.</b> أُبقي التسليم السابق دون تعديل، وتُسلَّم النسخة المحسّنة وأصولها مستقلّة.</p></div>
    <div class="limits">
      <h2>قبل النشر والإنتاج</h2>
      <div class="limits-grid">
        <div><h3>نسخة عرض رقمية</h3><p>الدليل RGB وليس PDF/X. للطباعة: اعتماد ICC والخامة وعينة اللون وقوالب المورد.</p></div>
        <div><h3>مشاهد تصورية</h3><p>العمارة تصورية مولّدة والموك أب محاكاة ثلاثية الأبعاد؛ لا يمثّلان عقارات الشركة أو منتجاتها الفعلية.</p></div>
        <div><h3>البيانات والمراجع</h3><p>تُعتمد بيانات الشركة ووجهة QR. مرجع ألوان الفرع الخدمي والحرفي غير متاح لاستكمال المقارنة.</p></div>
        <div><h3>التحرير والخطوط</h3><p>المصادر قابلة للتعديل. الخط العربي التجاري غير معاد توزيعه؛ يلزم توفير نسخته المرخّصة.</p></div>
      </div>
    </div>
  </main>
  <footer><span lang="en" dir="ltr">02 / 02</span><span>النتائج مستندة إلى سجل التحقق النهائي المرفق</span></footer>
</section>
</body></html>'''
    destination = Path(output) if output else ROOT / 'source/premium-review.html'
    destination.write_text(document, encoding='utf-8')
    return destination


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verification', type=Path, default=VERIFICATION)
    parser.add_argument('--output', type=Path, default=ROOT / 'source/premium-review.html')
    args = parser.parse_args()
    print(build(args.verification, args.output))
