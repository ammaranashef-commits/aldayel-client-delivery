from pathlib import Path
import json, html, re, shutil, base64, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent
RESEARCH = ROOT / 'research'
PAGES = []
INK, PEARL, MIST, COPPER = '#1C3549', '#F4F3EF', '#CCDDE4', '#A96B53'
TOKENS = json.loads((ROOT/'assets/design-tokens.json').read_text())
PALETTES = json.loads((RESEARCH/'provisional-palettes.json').read_text())
SOURCES = json.loads((RESEARCH/'color-sources-2026.json').read_text())

ET.register_namespace('', 'http://www.w3.org/2000/svg')
ET.register_namespace('xlink', 'http://www.w3.org/1999/xlink')
_SVG_INSTANCE = 0

def inline_svg(source, *, width=None, height=None, css_class='standalone', label=''):
    """Keep SVG paths in the document instead of Chromium's rounded image viewport.

    Each embedded SVG has its own ID namespace. Explicit, proportional CSS
    dimensions and SVG's meet rule preserve geometry even if a parent applies
    max-width/max-height constraints. This does not modify any source asset.
    """
    global _SVG_INSTANCE
    tree = ET.fromstring(ET.tostring(source)) if isinstance(source, ET.Element) else ET.parse(source).getroot()
    values = [float(v) for v in re.split(r'[\s,]+', tree.attrib['viewBox'].strip())]
    view_width, view_height = values[2:]
    if view_width <= 0 or view_height <= 0:
        raise ValueError('SVG viewBox must have positive dimensions')
    if width is None and height is None:
        raise ValueError('Specify an SVG width or height')
    if width is None:
        width = height * view_width / view_height
    elif height is None:
        height = width * view_height / view_width
    else:
        # Fit a requested bounding box; never scale the axes independently.
        scale = min(width / view_width, height / view_height)
        width, height = view_width * scale, view_height * scale

    _SVG_INSTANCE += 1
    prefix = f'book-svg-{_SVG_INSTANCE:04d}-'
    ids = {element.attrib['id']: prefix + element.attrib['id']
           for element in tree.iter() if element.get('id')}
    url_pattern = re.compile(r'''url\(\s*(['"]?)#([^)'"\s]+)\1\s*\)''')

    def rewrite_urls(value):
        return url_pattern.sub(lambda match: 'url(#' + ids.get(match.group(2), match.group(2)) + ')', value)

    for element in tree.iter():
        if element.get('id'):
            element.set('id', ids[element.attrib['id']])
        for key, value in list(element.attrib.items()):
            if key.rsplit('}', 1)[-1] == 'href' and value.startswith('#'):
                value = '#' + ids.get(value[1:], value[1:])
            elif key in ('aria-labelledby', 'aria-describedby'):
                value = ' '.join(ids.get(part, part) for part in value.split())
            element.set(key, rewrite_urls(value))
        if element.tag.rsplit('}', 1)[-1] == 'style' and element.text:
            style = rewrite_urls(element.text)
            for original, replacement in sorted(ids.items(), key=lambda item: -len(item[0])):
                style = re.sub(r'#' + re.escape(original) + r'(?![\w-])', '#' + replacement, style)
            element.text = style

    tree.set('class', css_class)
    tree.set('width', f'{width:.8f}')
    tree.set('height', f'{height:.8f}')
    existing_style = tree.get('style', '').rstrip(';')
    tree.set('style', (existing_style + ';' if existing_style else '') + f'width:{width:.8f}px;height:{height:.8f}px')
    tree.set('preserveAspectRatio', 'xMidYMid meet')
    tree.set('role', 'img')
    tree.set('focusable', 'false')
    if label:
        tree.set('aria-label', label)
    return ET.tostring(tree, encoding='unicode')

def logo(variant='primary-ar', color='ink', width=420, branch=False):
    image=inline_svg(ROOT/f'assets/logos/residential/aldayel-{variant}-{color}.svg', width=width,
                     label='شعار الدايل الأصلي؛ تغيير اللون فقط')
    if branch:
        return f'<div class="lockup" style="width:{width}px;gap:{width * 287.84 / 763.47 / 4:.2f}px">{image}<div class="branch">السكني<span class="en">RESIDENTIAL</span></div></div>'
    return image

def logo_at_mm(mm, variant='primary-ar'):
    # Native page width is 1600 CSS px = 1200 pt. Use real ink bounds, not SVG padding.
    meta=next(x for x in json.loads((ROOT/'assets/logos/original/provenance.json').read_text()) if x['variant']==variant)
    tree=ET.parse(ROOT/f'assets/logos/original/aldayel-{variant}-original.svg').getroot()
    view_width=float(tree.attrib['viewBox'].split()[2])
    width=mm*96/25.4*view_width/meta['logo_width']
    return logo(variant=variant,width=width)

def study_logo(color,width=270):
    tree=ET.fromstring((ROOT/'assets/logos/original/aldayel-primary-ar-original.svg').read_text())
    for element in tree.iter():
        if element.get('class')=='original-logo-ink': element.set('fill',color)
    return inline_svg(tree, width=width, label='دراسة لونية للشعار الأصلي')

def photo(which='exterior', height=480, position='center'):
    return f'<div class="photo-frame" style="height:{height}px"><img class="photo" style="object-position:{position}" src="../assets/images/concept_residential_{which}.png" alt="مشهد سكني تصوري"><span class="photo-cap">مشهد تصوري مولّد؛ لا يمثّل عقارًا معروضًا من الدايل.</span></div>'

def app(name, height=470, width=None):
    return inline_svg(ROOT/f'applications/{name}.svg', height=height, width=width,
                      css_class='app', label=f'تطبيق {name}')

def motif(color=INK,opacity=.14):
    return f'<div class="architecture"><svg viewBox="0 0 1600 900" fill="none"><g stroke="{color}" stroke-width="1.2" opacity="{opacity}"><path vector-effect="non-scaling-stroke" d="M200 900V340H540V100H880V900M300 900V440H640V200H980V900M400 900V540H740V300H1080V900M500 900V640H840V400H1180V900M600 900V740H940V500H1280V900"/></g></svg></div>'

def page(title, section, body, cls=''):
    body=re.sub(r'\[S\d+(?:[–—-]S?\d+)?\]',lambda m:f'<bdi dir="ltr" style="display:inline-block;white-space:nowrap">{m.group(0)}</bdi>',body)
    n=len(PAGES)+1
    PAGES.append({'title':title,'section':section,'html':f'<section class="page {cls}" id="p{n}"><header class="running"><span>ALDAYEL / RESIDENTIAL</span><span class="ar">{section}</span></header><h1 class="title"{(' lang="en" dir="ltr"' if section=='ENGLISH TYPOGRAPHY' else '')}>{title}</h1><div class="body">{body}</div><footer class="footer"><span>{n:02d} / BRAND GUIDELINES</span><span class="ar">الدايل السكني · 2026</span></footer></section>'})

def chapter(n,title,english,paragraph,photo_name=None):
    visual=photo(photo_name,530) if photo_name else motif(PEARL,.2)
    page(title,english,f'<div class="chapter-no">{n:02d}</div><div class="split"><div class="vcenter" style="z-index:1"><div class="kicker">CHAPTER {n:02d}</div><div class="display">{title}</div><div class="rule"></div><p>{paragraph}</p><div class="kicker" style="margin-top:30px">{english}</div></div><div style="position:relative">{visual}</div></div>','ink')

def line_icon(name):
    paths={
      'home':'<path d="M12 34 40 12l28 22v34H48V48H32v20H12Z"/>',
      'location':'<path d="M40 72s24-25 24-43a24 24 0 1 0-48 0c0 18 24 43 24 43Z"/><circle cx="40" cy="29" r="8"/>',
      'key':'<circle cx="26" cy="28" r="16"/><path d="m38 40 29 29m-9-9 8-8m-17-1 8-8"/>',
      'area':'<rect x="13" y="13" width="54" height="54"/><path d="M24 56 56 24M42 24h14v14M24 42v14h14"/>',
      'light':'<circle cx="40" cy="40" r="16"/><path d="M40 4v9m0 54v9M4 40h9m54 0h9M14 14l7 7m38 38 7 7M14 66l7-7m38-38 7-7"/>',
      'community':'<path d="M7 67V36l16-13 17 13v31M40 67V20l16-12 17 12v47M18 67V51h11v16M51 67V45h11v22M49 28h14"/>'
    }
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="square" stroke-linejoin="miter">{paths[name]}</svg>'

# 01 / Opening. Architectural photography is kept separate from the original vector logo.
PAGES.append({'title':'الغلاف','section':'Opening','html':f'''<section class="page cover" id="p1"><div class="photo-frame"><img class="photo" src="../assets/images/concept_residential_exterior.png" style="object-position:65% center" alt="عمارة سكنية تصورية"><span class="photo-cap">مشهد معماري تصوري</span></div><div class="brand-panel">{logo(width=475,color='pearl',branch=True)}<div class="titlebox"><h1>دليل الهوية<br>البصرية واللفظية</h1><div class="en-title">Brand Identity Guidelines<br>AlDayel Residential</div></div><div class="space"><span class="edition">2026 / EDITION 01</span><span class="review-badge">نسخة مدقّقة</span></div></div><div class="copper-bar"></div></section>'''})

page('السكن… تجربة أقرب إلى الحياة','INTRODUCTION',f'''<div class="split"><div class="vcenter"><div class="kicker">A DISTINCT RESIDENTIAL EXPRESSION</div><div class="quote">حضور هادئ.<br>تفاصيل واضحة.<br>وعلاقة تدوم.</div><div class="rule"></div><p>هوية فرعية تُعبّر عن السكن المعاصر، وتحتفظ بثقة اسم الدايل وشعاره الأصلي. تتغيّر اللغة اللونية والتطبيقات، وتبقى العلاقة مع العلامة الأم واضحة.</p><p class="example" style="margin-top:20px">عبارات افتتاحية تحريرية مقترحة للدليل، وليست شعارًا لفظيًا رسميًا للشركة.</p></div>{photo('interior',610)}</div>''')

page('خريطة الدليل','CONTENTS','''<div class="split"><div><div class="toc-row"><span>العلامة وصوتها</span><span>04—07</span></div><div class="toc-row"><span>نظام الشعار</span><span>08—16</span></div><div class="toc-row"><span>النظام اللوني</span><span>17—25</span></div><div class="toc-row"><span>الخطوط واللغة البصرية</span><span>26—35</span></div><div class="toc-row"><span>التطبيقات</span><span>36—56</span></div><div class="toc-row"><span>الأصول والإنتاج والمصادر</span><span>57—62</span></div></div><div class="plate ink" style="height:610px;position:relative">'''+f'''<div style="z-index:1;background:var(--ink);padding:45px">{logo(color='pearl',width=430,branch=True)}</div></div></div>''')

page('اسم واحد. اختصاص سكني واضح.','BRAND ARCHITECTURE',f'''<div class="split"><div class="vcenter"><h2>امتداد تعريفي مستقل</h2><p style="margin-top:20px">يبقى تركيب شعار «مركز الدايل العقاري» بجميع عناصره الأصلية كما هو. تظهر كلمة «السكني» خارج حدود الشعار كتعريف للاختصاص، ولا تستبدل أي كلمة من التوقيع الأصلي.</p><div class="rule"></div><div class="pill-row"><span class="pill">الشعار الأصلي</span><span class="pill">النظام الطباعي</span><span class="pill">نظام لوني جديد</span></div><p class="note">التوقيع التعريفي السكني وقواعد استخدامه نظام مقترح في هذه النسخة، ويصبح مرجعًا رسميًا بعد الاعتماد.</p></div><div class="stack"><div class="plate" style="height:220px">{logo(width=370)}</div><div style="text-align:center;font-size:22px">العلامة الأم</div><div class="plate ink" style="height:285px">{logo(color='pearl',width=275,branch=True)}</div></div></div>''')

page('شخصية تبعث على الاطمئنان','BRAND CHARACTER','''<p class="lede">نترجم الثقة والراحة إلى قرارات بصرية عملية: مساحات تتنفس، نصوص مقروءة، وصور توضّح المكان بواقعية.</p><div class="grid3" style="margin-top:44px"><div class="panel"><div class="feature-number">01</div><h2>ثقة</h2><p style="margin-top:18px">معلومات محددة، تسلسل واضح، ومظهر ثابت في كل نقطة تواصل.</p><div class="rule"></div><p class="small">حبر أزرق · تباين مرتفع · هندسة منتظمة</p></div><div class="panel"><div class="feature-number">02</div><h2>راحة</h2><p style="margin-top:18px">لغة ودية، ضوء طبيعي، ومساحات هادئة تعطي التفاصيل وقتها.</p><div class="rule"></div><p class="small">لؤلؤي · ضباب أزرق · إيقاع مريح</p></div><div class="panel"><div class="feature-number">03</div><h2>رقيّ معاصر</h2><p style="margin-top:18px">مواد ملموسة، تفاصيل قليلة ومحسوبة، وحضور متوازن للشعار.</p><div class="rule"></div><p class="small">نحاس محدود · طباعة دقيقة · صور معمارية</p></div></div>''')

page('لغة ودية… واحترافية عقارية','TONE OF VOICE','''<div class="grid2"><div class="stack"><h2>نقولها بوضوح</h2><p>نشرح المعلومة قبل الوعد، ونسأل عن احتياج السكن قبل تقديم الخيار. نستخدم عربية سهلة ومباشرة، ويمكن توظيف لهجة محلية مناسبة في المحتوى الاجتماعي.</p><div class="panel"><h3>نبرة مقترحة</h3><p style="margin-top:16px">«لنبدأ بما تحتاجه في منزلك القادم: الموقع، المساحة، وطريقة حياتك اليومية.»</p></div><p class="small">العبارة مثال تحريري قابل للتعديل؛ لا تتضمن ضمانًا استثماريًا أو وعدًا بتوافر عقار.</p></div><div><div class="panel" style="background:var(--mist);margin-bottom:24px"><div class="kicker">DO</div><h3>«اطّلع على المساحة والتوزيع<br>وحدّد موعدًا مناسبًا للمعاينة.»</h3><p class="small" style="margin-top:20px">دعوة محددة، بصياغة هادئة وغير ضاغطة.</p></div><div class="panel"><div class="kicker">AVOID</div><h3>«أفضل فرصة مضمونة<br>وربح لا يُفوَّت!»</h3><p class="small" style="margin-top:20px">تجنّب الوعود المطلقة، الاستعجال المصطنع، والصفات التي لا يمكن إثباتها.</p></div></div></div>''')

page('أفق معماري','CREATIVE DIRECTION',f'''<div style="display:grid;grid-template-columns:1.25fr .7fr .6fr;gap:24px;height:510px">{photo('exterior',510)}<div>{photo('interior',310)}<div style="height:176px;background:var(--mist);margin-top:24px;padding:28px"><h2>ضوء. فراغ. اتزان.</h2><p class="small">المكان هو البطل.</p></div></div><div class="stack"><div style="background:var(--ink);height:260px;color:var(--pearl);display:flex;justify-content:center;align-items:center">{logo('icon','pearl',120)}</div><div class="hatch" style="height:160px;border:1px solid var(--hair)"></div><div style="height:42px;background:var(--copper)"></div></div></div><p class="caption">المزاج البصري: عمارة سكنية معاصرة، خامات هادئة، محايدات مضيئة، وأزرق يحفظ الوضوح. الصور تصورية للاستخدام الإرشادي.</p>''')

chapter(1,'الشعار','THE ORIGINAL MARK','الهوية الجديدة تبدأ من أصل ثابت: لا إعادة رسم، لا تغيير في النسب، ولا استبدال لأي جزء من التوقيع الأصلي.')

page('الأصل كما هو','PRIMARY SIGNATURE',f'''<div class="plate ink" style="height:460px">{logo(width=800,color='pearl')}</div><div class="grid2" style="margin-top:27px"><p>نُقلت المسارات من ملف Illustrator الأصلي دون تغيير هندسي. التعديل المسموح في نسخ هذه الحزمة هو لون التعبئة فقط.</p><p class="small">النسخة العربية الأساسية تحتفظ بعبارة «مركز الدايل العقاري» داخل الشعار. يُضاف «السكني» خارجه، ولا يحل محلها.</p></div>''')

page('عائلة الشعار الأصلية','SIGNATURE VARIANTS',f'''<div class="grid2"><div><div class="plate" style="height:230px">{logo('primary-ar',width=400)}</div><div class="caption">الأساسي العربي · الاستخدام الافتراضي</div></div><div><div class="plate" style="height:230px">{logo('primary-en',width=400)}</div><div class="caption">الأساسي مع التوقيع الإنجليزي الأصلي</div></div><div><div class="plate mist" style="height:230px">{logo('secondary-ar',width=220)}</div><div class="caption">الثانوي العربي · من ملفات المصدر</div></div><div><div class="plate mist" style="height:230px;gap:90px">{logo('icon',width=125)}{logo('wordmark',width=230)}</div><div class="caption">الرمز والاسم منفردين · للمساحات الصغيرة والسياق الواضح</div></div></div>''')

page('إضافة «السكني» دون تغيير الشعار','RESIDENTIAL ENDORSEMENT',f'''<div class="split"><div class="vcenter"><h2>التعريف يأتي بعد المساحة الحرة</h2><p style="margin-top:20px">يوضع الوصف السكني في كتلة منفصلة، وتفصله مسافة لا تقل عن X عن أقرب نقطة في الشعار. تُحفظ المحاذاة المركزية والعلاقة بين العربية والإنجليزية.</p><div class="rule"></div><p class="small">X = ربع ارتفاع الشعار الأصلي. الكلمة العربية بخط Helvetica Neue LT Arabic، والإنجليزية بخط PT Sans. الخط الفاصل اختياري ضمن التطبيقات.</p><p class="note">هذه قاعدة جديدة للفرع السكني؛ لا تُنسب إلى الدليل القديم.</p></div><div class="plate mist" style="height:610px"><div style="position:relative;padding:45px;border:1px dashed var(--ink)">{logo(width=450,branch=True)}<span class="labels" style="position:absolute;top:15px;left:18px">X = H / 4</span></div></div></div>''')

page('مساحة تمنح الشعار حضوره','CLEAR SPACE',f'''<div class="split"><div class="vcenter"><div class="num">X = H/4</div><h2 style="margin-top:30px">مسافة حرة من الجهات الأربع</h2><p style="margin-top:20px">نقيس H من أعلى نقطة إلى أدنى نقطة في الشعار الكامل. نترك X على كل جانب، ونمنع دخول نص أو صورة أو حافة قص إلى هذه المساحة.</p><p class="note">المساحة الآمنة حد أدنى. تُفضّل مساحات أوسع في الأغلفة واللافتات والواجهات البسيطة.</p></div><div class="vcenter"><div style="align-self:center;width:max-content;padding:44.3px;border:1px solid var(--ink);position:relative;background:linear-gradient(90deg,#ccdde480,#f4f3ef)"><div style="border:1px dashed var(--ink);padding:0">{logo(width=470)}</div><span class="labels" style="position:absolute;left:17px;top:50%">X</span><span class="labels" style="position:absolute;top:11px;left:50%">X</span><span class="labels" style="position:absolute;bottom:11px;left:50%">X</span><span class="labels" style="position:absolute;right:17px;top:50%">X</span></div><p class="caption">القياس على حدود الحبر الفعلية؛ لا على أبعاد لوحة Illustrator.</p></div></div>''')

page('من 20 إلى 200 مم','SIZE & LEGIBILITY',f'''<div class="space"><div><div class="labels">200 mm — ORIGINAL PRIMARY</div><div style="margin:20px 0;width:758px">{logo_at_mm(200)}</div></div><div class="panel" style="width:535px"><h3>حدود استخدام مقترحة</h3><p class="small" style="margin-top:14px">الشعار الكامل: 45 مم للطباعة / 240 بكسل للشاشة.<br>الاسم الأصلي منفردًا: 20 مم / 110 بكسل.<br>الرمز الأصلي: 8 مم / 32 بكسل.</p><p class="small" style="margin-top:18px">تُراجع عينة مطبوعة بحجمها الحقيقي؛ عند فقدان وضوح التوقيع الصغير نستخدم نسخة أصلية أبسط.</p></div></div><div style="display:flex;justify-content:space-between;align-items:flex-end;gap:45px;margin-top:45px"><div>{logo_at_mm(100)}<div class="app-label">100 mm</div></div><div>{logo_at_mm(60)}<div class="app-label">60 mm</div></div><div>{logo_at_mm(45.3)}<div class="app-label">≥45 mm — MIN. PRIMARY</div></div><div>{logo_at_mm(20,'wordmark')}<div class="app-label">20 mm — WORDMARK</div></div></div><p class="caption">مقاسات العرض عند طباعة صفحة الدليل بنسبة 100%. لا يُنصح بتصغير الشعار الكامل إلى 20 مم بسبب التوقيع الموروث.</p>''')

page('وضوح على كل خلفية','BACKGROUND APPLICATIONS',f'''<div class="grid2"><div class="plate pearl" style="height:265px;border:1px solid var(--hair)">{logo(width=360)}</div><div class="plate ink" style="height:265px">{logo(width=360,color='pearl')}</div><div class="plate mist" style="height:265px">{logo(width=360)}</div><div class="photo-frame" style="height:265px"><img class="photo" src="../assets/images/concept_residential_exterior.png"><div style="position:absolute;inset:30px 80px;background:var(--pearl);display:flex;align-items:center;justify-content:center">{logo(width=300)}</div></div></div><p class="caption">على الصور المزدحمة يُستخدم حقل لوني صريح. لا تُحل مشكلة التباين بإضافة حدود أو ظل أو تأثير على الشعار.</p>''')

bad_examples=[('التمديد أو الضغط','transform:scaleX(1.4)',''),('الدوران','transform:rotate(-12deg)',''),('الظلال والمؤثرات','filter:drop-shadow(6px 7px 2px #0005)',''),('ضعف التباين','','pearl'),('تزاحم العناصر','',''),('تغيير توزيع المكونات','','')]
cells=[]
for i,(label,style,color) in enumerate(bad_examples):
    graphic=logo(width=240,color=color or 'ink')
    extra='<div style="position:absolute;top:95px;font-size:30px">نص يزاحم الشعار</div>' if i==4 else ''
    if i==5: graphic=f'<div style="display:flex;align-items:center;gap:35px">{logo("wordmark",width=140)}{logo("icon",width=65)}</div>'
    cells.append(f'<div><div class="plate" style="height:205px;border:1px solid var(--hair);background:{MIST if i==3 else PEARL}"><div style="{style}">{graphic}</div>{extra}<span class="cross">×</span></div><p class="caption">{label}</p></div>')
page('حدود الاستخدام','INCORRECT USE','<div class="grid3">'+''.join(cells)+'</div><p class="caption">الأمثلة أعلاه توضيح للممارسات الممنوعة، وليست ملفات شعار معتمدة أو بدائل قابلة للاستخدام.</p>')

page('حركة هادئة… وشعار ثابت','MOTION PRINCIPLE',f'''<div class="grid3">{''.join(f'<div><div class="plate ink" style="height:270px"><div style="opacity:{opacity};transform:translateY({dy}px)">{logo(color="pearl",width=310)}</div></div><p class="app-label">{label}</p></div>' for opacity,dy,label in [(0.15,18,'00:00 — FADE IN'),(.7,6,'00:01 — SETTLE'),(1,0,'00:02–06 — HOLD')])}</div><div class="grid2" style="margin-top:40px"><div><h2>ظهور. استقرار. حضور.</h2><p class="small" style="margin-top:12px">تتحرك الكتلة كاملة بانزياح خفيف وظهور تدريجي. لا تتبدّل المسارات ولا تتمدد الحروف أو تتفكك عناصر الشعار.</p></div><div class="panel"><p class="en" style="font-size:26px">1920 × 1080 · 24 fps · 6 sec · H.264</p><p class="small" style="margin-top:12px">نسخة صامتة للفيديو، ومصدر HTML للحركة الرقمية مع بديل ثابت عند تفعيل تقليل الحركة.</p></div></div>''')

chapter(2,'اللون','COLOR SYSTEM','مجموعة واحدة تجمع عمق الحبر الأزرق وخفة اللؤلؤي والضباب، مع أثر نحاسي محسوب. اختيار مبني على بحث، ثم مكيَّف لاحتياجات العلامة.')

page('قراءة الاتجاه… ثم اتخاذ القرار','COLOR RESEARCH / 2026','''<div class="grid2"><div class="panel" style="background:var(--mist)"><div class="kicker">PINTEREST / 2026</div><div class="word-en">Cool Blue</div><p style="margin-top:25px">تضع لوحة Pinterest لعام 2026 الأزرق البارد ضمن خمسة اتجاهات، اعتمادًا على إشارات سلوك المستخدمين والبحث البصري والتحرير المتخصص.</p><div class="rule"></div><p class="small">إشارة عامة إلى الاتجاه، وليست دراسة لعملاء العقار السكني المحليين. [S1–S3]</p></div><div class="panel"><div class="kicker">DULUX / AKZONOBEL / 2026</div><h2>عائلة زرقاء لمساحات المعيشة</h2><p style="margin-top:25px">يتكرر الأزرق في توقع مستقل مرتبط بالعمارة والتصميم الداخلي، بدرجات داكنة وهادئة وفاتحة. يدعم ذلك ملاءمة الاتجاه للمشهد السكني.</p><div class="rule"></div><p class="small">ألوان الهوية هنا مصممة للدايل؛ ليست نسخًا أو مكافئات رسمية لألوان الدهانات. [S9–S10]</p></div></div><p class="note">تدعم Adobe الطابع الإنساني المرحّب؛ ويؤكد إعلان شريك Pantone اتجاه الهدوء والمحايدات. الروابط والتواريخ ومنهجية التقييم في نهاية الدليل والملف البحثي.</p>''')

palette_cards=[]
for idx,p in enumerate(PALETTES):
    strips=''.join(f'<span style="background:{c["hex"]};width:{c["ratio_pct"]}%"></span>' for c in p['colors'])
    desc=['الأوضح في فصل السكني عن الزيتوني والبني، مع مساحة واسعة للصور المعمارية وتباين قوي.','حضور فندقي راقٍ ومتميز؛ لكنه أكثر تعبيرية وقد يحدّ من حياد بعض التطبيقات العقارية.','أجواء طبيعية هادئة؛ تبقى أقرب إلى العائلة الخضراء الموجودة في هوية العلامة الأم.'][idx]
    palette_cards.append(f'<div class="panel"><div class="kicker">OPTION {p["id"]}'+(' / SELECTED' if idx==0 else '')+f'</div><div class="palette-strip">{strips}</div><div class="palette-title">{p["name_ar"]}</div><p class="en small">{p["name_en"]}</p><div style="height:135px;display:flex;align-items:center;justify-content:center;color:{p["colors"][0]["hex"]}">{study_logo(p["colors"][0]["hex"])}</div><p class="small">{desc}</p><p class="en tiny" style="margin-top:18px">'+ ' / '.join(c['hex'] for c in p['colors'])+'</p></div>')
page('ثلاث قراءات للهوية السكنية','PALETTE EXPLORATION','<div class="grid3">'+''.join(palette_cards)+'</div><p class="caption">كل مجموعة اقتراح تصميمي مشتق من البحث؛ لا تمثل نسب الألوان أو الدرجات الدقيقة نتيجة بحث سوقي.</p>')

page('لماذا «أفق معماري»؟','DESIGN EVALUATION','''<div class="split"><div class="vcenter"><div class="kicker">THE CHOSEN DIRECTION</div><h2>التميّز مع الحفاظ على الهدوء</h2><p style="margin-top:22px">يتقدم الخيار الأزرق بوضوح النصوص، واتساع تطبيقاته، وقدرته على فصل الفرع السكني عن المحايدات الزيتونية والبنية في الأصول الأصلية.</p><p class="note">المقارنة تقييم تصميمي نوعي من 5 نقاط لكل معيار، وليست استبيان عملاء أو إثباتًا لتفضيل السوق.</p><p class="small" style="margin-top:20px">معاصرة اللون لا تكفي وحدها؛ قابلية الاستخدام والاستمرار أهم من تقليد موجة موسمية.</p></div><div><table class="score-table"><tr><th>المعيار</th><th>A</th><th>B</th><th>C</th></tr><tr><td>المعاصرة</td><td>4</td><td>4</td><td>4</td></tr><tr><td>الرقيّ الهادئ</td><td>5</td><td>5</td><td>4</td></tr><tr><td>الوضوح</td><td>5</td><td>5</td><td>4</td></tr><tr><td>قابلية الاستخدام</td><td>5</td><td>4</td><td>4</td></tr><tr><td>التميّز عن الأصل</td><td>5</td><td>5</td><td>2</td></tr><tr class="selected"><td>المجموع / 25</td><td>24</td><td>23</td><td>18</td></tr></table><p class="caption">A أفق معماري · B إقامة مخملية · C ملاذ مائي</p></div></div>''')

page('لون يحمل الثقة… ويترك للضوء مساحة','ARCHITECTURAL HORIZON',f'''<div style="display:grid;grid-template-columns:1.5fr 1fr;gap:0;height:505px"><div class="plate ink">{logo(color='pearl',width=500,branch=True)}</div><div style="display:grid;grid-template-rows:2fr 1fr .5fr"><div style="background:var(--pearl);padding:32px;border:1px solid var(--hair)"><h2>أبيض لؤلؤي</h2><p class="en">#F4F3EF</p></div><div style="background:var(--mist);padding:25px"><h3>ضباب أزرق</h3></div><div style="background:var(--copper)"></div></div></div><p class="caption">الحبر هو الحضور. اللؤلؤي هو المساحة. الضباب هو الرابط. النحاس هو اللمسة الأخيرة.</p>''')

swatches=[]
for c in TOKENS['colors']:
    textcolor=PEARL if c['hex']==INK else INK
    if c['hex']==COPPER: textcolor='#FFFFFF'
    swatches.append(f'<div><div class="swatch" style="background:{c["hex"]};color:{textcolor}"><span class="arabic">{c["name_ar"]}</span><span class="hex">{c["hex"]}</span></div><div class="spec"><b>{c["name_en"]}</b><br>RGB {" / ".join(map(str,c["rgb"]))}<br>CMYK {" / ".join(map(str,c["cmyk"]))}<br><span class="ar" style="display:block">{c["role_ar"]} · <bdi dir="ltr">{c["ratio_pct"]}%</bdi></span></div></div>')
page('المواصفات اللونية','COLOR SPECIFICATIONS','<div class="grid4">'+''.join(swatches)+'</div><p class="note">HEX وRGB للاستخدام الرقمي. قيم CMYK حُسبت بإدارة ألوان وفق Artifex CMYK SWOP Profile، وهي مرجع مبدئي يحتاج عينة طباعة ومراجعة ملف المطبعة. لا تمثل تحويلات Pantone رسمية.</p>')

page('نسب تضبط الإيقاع','COLOR PROPORTIONS',f'''<div style="height:310px;display:flex;direction:ltr"><div style="width:50%;background:var(--pearl);border:1px solid var(--hair);padding:35px"><div class="giant">50<span style="font-size:50px">%</span></div><p>الأبيض اللؤلؤي</p></div><div style="width:30%;background:var(--ink);color:var(--pearl);padding:35px"><div class="num">30%</div><p style="margin-top:45px">الحبر الأزرق</p></div><div style="width:15%;background:var(--mist);padding:25px"><div class="num" style="font-size:65px">15%</div><p style="margin-top:60px;font-size:20px">الضباب</p></div><div style="width:5%;background:var(--copper);position:relative"><span class="labels" style="position:absolute;bottom:25px;left:13px;color:#fff;font-size:27px;transform:rotate(-90deg)">5%</span></div></div><div class="grid2" style="margin-top:35px"><div><h2>توازن المجموعة، لا قالب إلزامي</h2><p class="small" style="margin-top:15px">النسب متوسط استرشادي عبر مجموعة التطبيقات. يمكن أن يكون الغلاف داكنًا بالكامل، فيما تعتمد صفحات الشرح والمراسلات على اللؤلؤي.</p></div><div><h2>النحاس للتفاصيل</h2><p class="small" style="margin-top:15px">يظهر في خط فاصل أو حافة أو لمسة إنتاجية؛ لا يتحول إلى خلفية مهيمنة أو نصوص صغيرة منخفضة التباين.</p></div></div>''')

page('التباين جزء من الهوية','ACCESSIBLE COLOR','''<div class="grid2"><div class="contrast" style="background:var(--pearl);border:1px solid var(--hair)"><div><div class="sample">مساحة واضحة</div><div class="detail">حبر على لؤلؤي · مناسب للنصوص</div></div><div class="ratio">11.43:1</div></div><div class="contrast" style="background:var(--mist)"><div><div class="sample">مساحة واضحة</div><div class="detail">حبر على ضباب · مناسب للنصوص</div></div><div class="ratio">9.08:1</div></div><div class="contrast" style="background:var(--ink);color:var(--pearl)"><div><div class="sample">مساحة واضحة</div><div class="detail">لؤلؤي على حبر · مناسب للنصوص</div></div><div class="ratio">11.43:1</div></div><div class="contrast" style="background:var(--pearl);border:1px solid var(--hair)"><div><div class="sample" style="color:var(--copper)">تفصيل لوني</div><div class="detail">نحاس على لؤلؤي · للكبير والزخرفة فقط</div></div><div class="ratio">3.85:1</div></div></div><div class="grid2" style="margin-top:32px"><p class="small">مرجع WCAG 2.2: الحد الأدنى للنص الرقمي العادي 4.5:1، وللنص الكبير 3:1. الحساب على قيم sRGB المعتمدة.</p><p class="small">الحبر فوق النحاس 2.97:1: نتجنبه للنصوص. لا تُستبدل الكلمات أو التسميات بإشارة لونية وحدها.</p></div>''')

page('من الشاشة إلى الورق','COLOR IN PRODUCTION','''<div class="grid3"><div class="panel"><div class="feature-number">RGB</div><h2>النسخة الرقمية</h2><p class="small" style="margin-top:20px">تعتمد قيم HEX وRGB مع ملف sRGB، وتحافظ على الحبر واللؤلؤي كزوج القراءة الأساسي. ملف الدليل الرئيسي معدّ للعرض الرقمي.</p></div><div class="panel"><div class="feature-number">CMYK</div><h2>نسخة المطبعة</h2><p class="small" style="margin-top:20px">تُحوّل الألوان إلى ملف ICC الخاص بالمطبعة والورق. يُراجع الحبر المركب والنحاس بعينة فعلية قبل اعتماد الكمية.</p></div><div class="panel"><div class="feature-number">K</div><h2>التفاصيل الدقيقة</h2><p class="small" style="margin-top:20px">يمكن استخدام الأسود الأحادي في الختم والنصوص الدقيقة بالنماذج لتجنب أخطاء تطابق الألواح. لا نستخدم خليط الحبر الغني للأحرف الصغيرة جدًا.</p></div></div><p class="note">تطبيقات الأكواب والأكياس والعلب نماذج تصميمية. تُطابق قوالب القص والثني والنزف مع المورد قبل الإنتاج، ولا تُعامل كمخططات تصنيع معتمدة.</p>''')

chapter(3,'لغة بصرية متكاملة','TYPE & VISUAL LANGUAGE','خط عربي من أصول الدايل، وخط إنجليزي متوافق معه؛ يربطهما نظام مسافات وإطارات يستلهم انتظام العمارة.')

page('العربية… بوضوحها الأصلي','ARABIC TYPOGRAPHY','''<div class="split"><div><div class="bigword">مساحة<br>تشبه حياتك.</div><div class="rule"></div><p class="en" style="font-size:30px">Helvetica Neue LT Arabic</p><p class="small" style="margin-top:15px">Roman للنصوص، وBold للعناوين والتأكيدات. الخط من الملفات الأصلية المرفقة؛ لا استبدال بخط مشابه.</p></div><div class="vcenter"><div style="font-size:44px;line-height:2">أ ب ت ث ج ح خ د ذ ر ز<br>س ش ص ض ط ظ ع غ<br>ف ق ك ل م ن هـ و ي</div><div class="rule"></div><div style="font-size:42px">0123456789 · ٠١٢٣٤٥٦٧٨٩</div><p class="small" style="margin-top:25px">نحافظ على اتصال الحروف واتجاه القراءة. لا نزيد تباعد الحروف العربية اصطناعيًا، ولا نصنع وزنًا مائلًا غير متاح.</p><p class="example" style="margin-top:15px">«مساحة تشبه حياتك» عنوان تحريري مقترح للتطبيقات، وليس شعارًا لفظيًا معتمدًا.</p></div></div>''')

page('English, in the same rhythm','ENGLISH TYPOGRAPHY','''<div class="split" style="direction:ltr"><div><div class="word-en" style="font-size:105px;line-height:1.15">Space.<br>Light.<br>Belonging.</div><div class="rule"></div><p class="en" style="font-size:28px">PT Sans / The original companion family</p></div><div class="vcenter"><div class="en" style="font-size:40px;line-height:1.8">ABCDEFGHIJKLMNOPQRSTUVWXYZ<br>abcdefghijklmnopqrstuvwxyz<br>0123456789 & / @</div><div class="rule"></div><p class="en" style="font-size:31px">Regular · <b>Bold</b> · <i>Italic</i></p><p class="ar small" style="margin-top:30px">المائل مخصص للإنجليزية عند الحاجة إلى اقتباس قصير أو تسمية تحريرية. تُكتب الوحدات والأرقام اللاتينية باتجاه مستقل لتجنب انعكاس ترتيبها.</p></div></div>''')

page('تسلسل يسهّل القراءة','TYPE HIERARCHY','''<div style="display:grid;grid-template-columns:1.1fr .9fr;gap:65px"><div><div class="labels">H1 / 44–60 pt / BOLD OR ROMAN</div><div style="font-size:68px;margin-top:12px">مساحة للحياة</div><div class="rule"></div><div class="labels">H2 / 24–32 pt / BOLD</div><h2 style="margin-top:12px;font-weight:700">تفاصيل تساعدك على الاختيار</h2><div class="rule"></div><div class="labels">BODY / 11–14 pt PRINT · 18–24 px DIGITAL</div><p style="margin-top:12px">الموقع والتوزيع والضوء عناصر نعرضها بوضوح. نختصر النص، ونترك مسافة مريحة بين السطور، ونستخدم المحاذاة اليمنى للعربية.</p></div><div class="panel" style="background:var(--mist)"><div class="kicker">EDITORIAL EXAMPLE</div><h2 style="font-size:45px">قبل أن تختار،<br>تعرّف على المكان.</h2><p style="margin-top:30px">كيف يدخل الضوء؟<br>كيف تتوزع المساحات؟<br>وكيف يتصل المنزل بيومك؟</p><div class="rule"></div><p class="small">تباعد الأسطر للنصوص: <bdi dir="ltr">1.5–1.8</bdi>.<br>نستخدم وزنَين أساسيين، ونحصر التوكيد في المعلومات المهمة.</p></div></div>''')

page('إيقاع مستلهم من العمارة','GRAPHIC LANGUAGE',f'''<div class="split"><div class="vcenter"><h2>خطوط تبني مساحة</h2><p style="margin-top:20px">إطارات مستقيمة، تعاقب رأسي، ومسارات مفتوحة توحي بواجهات وفراغات معمارية. هذه رسومات مساندة مستقلة؛ لا تُستخرج بتشويه الشعار أو تجزئته.</p><div class="rule"></div><p class="small">سماكة الخط الرقمي <bdi dir="ltr">1–2</bdi> بكسل في المساحات الكبيرة؛ في الطباعة لا تقل الخطوط الدقيقة عن 0.25 مم. نترك فراغًا واضحًا حول النصوص والشعار.</p></div><div class="plate mist" style="height:610px">{motif(INK,.6)}<div style="position:absolute;bottom:45px;right:45px">{logo('icon',width=80)}</div></div></div>''')

icons=[('home','المنزل','HOME'),('location','الموقع','LOCATION'),('key','الاستلام','HANDOVER'),('area','المساحة','AREA'),('light','الضوء','DAYLIGHT'),('community','المحيط','NEIGHBOURHOOD')]
page('أيقونات دقيقة وقابلة للتوسع','ICONOGRAPHY','<div class="icon-grid">'+''.join(f'<div class="icon-cell">{line_icon(i)}<div><h3>{ar}</h3><div class="en">{en}</div></div></div>' for i,ar,en in icons)+'</div><div class="grid2" style="margin-top:50px"><p>مجموعة خطية مخصصة للتطبيقات السكنية: سماكة ثابتة، نهايات مستقيمة، وزوايا معمارية واضحة. تُستخدم مع تسمية نصية حيث يمكن أن يلتبس المعنى.</p><p class="small">تبدأ الأيقونات الرقمية من 24 بكسل. لا تحل أيقونة المنزل محل رمز الدايل الأصلي، ولا تُضاف أيقونات داخل تركيب الشعار.</p></div>')

page('أنماط وخلفيات وإطارات','PATTERNS & FRAMES',f'''<div class="grid3"><div><div class="plate mist" style="height:420px">{motif(INK,.6)}</div><p class="caption">تعاقب معماري · للخلفيات الهادئة</p></div><div><div class="plate ink" style="height:420px"><div style="position:absolute;inset:45px;border:1px solid var(--mist)"></div><div style="position:absolute;inset:80px;border:1px solid var(--mist)"></div>{logo('icon','pearl',125)}</div><p class="caption">إطار مزدوج · للأغلفة والبطاقات</p></div><div><div class="plate pearl hatch" style="height:420px;border:1px solid var(--hair)"><div style="height:180px;width:65%;background:var(--pearl);display:flex;align-items:center;justify-content:center">{logo(width=240)}</div></div><p class="caption">نسيج خطي · مع حقل هادئ للشعار</p></div></div><p class="note">لا يُستخدم النمط خلف النصوص الطويلة. نُبقي التباين منخفضًا في النمط، ونرفع التباين في المعلومات.</p>''')

page('رسم توضيحي يشرح… ولا يزاحم','ILLUSTRATION',f'''<div class="split"><div class="vcenter"><h2>من المخطط إلى الحكاية</h2><p style="margin-top:22px">تستخدم الرسومات المساندة اللغة الخطية نفسها لشرح مفهوم المساحة والضوء والاتصال بالخارج، دون تقديمها كمخطط هندسي لعقار فعلي.</p><p class="note">الرسم المقابل تصوري؛ لا يمثل أبعادًا أو مواصفات مشروع تابع للدايل.</p></div><div class="plate mist" style="height:590px"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 550" style="width:100%;height:100%"><g fill="none" stroke="{INK}" stroke-width="2"><path d="M65 400 300 505 640 330 405 225Z"/><path d="M125 365V190L350 80 550 165V375M125 190 325 280 550 165M325 280V455M350 80V255M175 388V278L245 310V420M375 429V315L460 270V384M492 365V252L525 233V349M65 400V430L300 535 640 360V330M300 505V535"/><path d="M170 211 219 188 290 220 241 244ZM376 165 420 142 489 174 444 198Z" fill="{PEARL}"/><path d="M575 185V330M575 185l25-40M575 185l-25-40M575 210l35-32M575 210l-35-32"/><circle cx="575" cy="140" r="55" fill="none"/><path d="M80 455 260 535M330 540 645 380" stroke="{COPPER}"/></g></svg></div></div>''')

page('صور تسكنها التفاصيل','PHOTOGRAPHIC DIRECTION',f'''<div class="grid2">{photo('exterior',405)}{photo('interior',405)}</div><div class="grid3" style="margin-top:26px"><div><h3>ضوء طبيعي</h3><p class="small">تعريض متوازن وملمس واضح؛ لا مرشحات تغيّر واقع العقار.</p></div><div><h3>عمارة قابلة للفهم</h3><p class="small">خطوط مستقيمة وزوايا تُظهر التوزيع والاتصال بين الفراغات.</p></div><div><h3>صدق في العرض</h3><p class="small">نميّز الصور التصورية، ونستخدم صور العقارات الفعلية بموافقة أصحابها.</p></div></div>''')

page('نظام واحد… وتكوينات متعددة','LAYOUT GRID',f'''<div class="grid3"><div><div class="plate" style="height:360px;padding:25px"><div style="width:100%;height:100%;display:grid;grid-template-columns:repeat(6,1fr);gap:10px">{''.join('<div style="background:#ccdde4;border:1px solid #1c354930"></div>' for _ in range(6))}</div></div><p class="caption">شبكة تحريرية · 6 أعمدة</p></div><div><div class="plate ink" style="height:360px;display:grid;grid-template-columns:1fr 1fr"><div style="padding:28px">{logo('icon','pearl',80)}<p style="margin-top:45px">عنوان<br>ومساحة</p></div><div style="height:100%"><img class="photo" src="../assets/images/concept_residential_exterior.png"></div></div><p class="caption">تكوين منقسم · صورة وهوية</p></div><div><div class="plate mist" style="height:360px"><div style="position:absolute;inset:25px;border:1px solid var(--ink)"></div>{logo(width=240,branch=True)}</div><p class="caption">تكوين مركزي · حضور العلامة</p></div></div><p class="lede" style="margin-top:30px">نعتمد محاذاة ثابتة وهوامش كريمة، ثم نغيّر حجم الصورة وحقل اللون والإيقاع بين الصفحات. الثبات في القواعد لا يعني تكرار قالب واحد.</p>''')

# Applications and production pages follow in the same reproducible builder.
page('الهوية في الحياة اليومية','APPLICATIONS',f'''<div class="photo-frame" style="height:510px"><img class="photo" src="../assets/images/mockup_stationery.png" alt="موك أب قرطاسية الدايل السكني"><span class="photo-cap">تصوّر تطبيقي ثلاثي الأبعاد؛ لا يمثّل منتجًا مطبوعًا فعليًا.</span></div><p class="caption">من بطاقة العمل إلى ملف العرض، تحافظ التطبيقات على الأصل وتعبّر عن الفرع السكني بلغته الجديدة.</p>''')

page('بطاقة تترك أثرًا واضحًا','BUSINESS CARD & QR',f'''<div class="split"><div class="vcenter"><h2>تفاصيل قليلة… وأولوية للاسم</h2><p style="margin-top:20px">وجه يحمل العلامة وامتدادها السكني، ووجه للمعلومات الشخصية المعتمدة. يُحفظ رمز QR على خلفية فاتحة، مع هامش أبيض يعادل أربع وحدات على الأقل.</p><div class="rule"></div><p class="en">90 × 55 mm / FRONT & BACK</p><p class="note">رمز QR في هذه النسخة تجريبي: يفك إلى نص يعلن أنه نموذج تصميم، ولا يفتح موقعًا رسميًا. يُستبدل بالرابط المعتمد قبل الطباعة.</p></div><div class="stack" style="align-items:center;justify-content:center">{app('business-card-front',245)}{app('business-card-back',245)}</div></div>''')

page('المراسلات الرسمية','LETTERHEAD',f'''<div class="split"><div class="vcenter"><h2>هوية حاضرة… ومساحة للعمل</h2><p style="margin-top:20px">يتصدر الشعار الورقة، بينما تبقى مساحة النص الرئيسية خفيفة ومقروءة. تُنقل بيانات التواصل والعنوان المعتمدة إلى التذييل بعد تزويدها.</p><div class="rule"></div><p class="en">A4 / 210 × 297 mm</p><p class="small" style="margin-top:18px">نترك حدودًا مريحة للنص ونراعي مساحة التوقيع والختم. لا نملأ الحقول بأرقام أو عناوين تخمينية.</p></div><div class="plate" style="height:610px;background:var(--mist)">{app('letterhead',555)}</div></div>''')

page('مقاسات متعددة… توقيع واحد','ENVELOPE SYSTEM',f'''<div class="grid3" style="align-items:end"><div><div class="plate mist" style="height:430px;padding:24px">{app('envelope-dl',215)}</div><p class="app-label">DL / 220 × 110 mm</p></div><div><div class="plate mist" style="height:430px;padding:24px">{app('envelope-c5',280)}</div><p class="app-label">C5 / 229 × 162 mm</p></div><div><div class="plate mist" style="height:430px;padding:24px">{app('envelope-c4',295)}</div><p class="app-label">C4 / 324 × 229 mm</p></div></div><p class="lede" style="margin-top:35px">تعتمد الأظرف موضعًا ثابتًا للعلامة وحقلًا واضحًا للعنوان. قوالب القص ومواضع اللصق تُراجع مع مورد الظرف المختار.</p>''')

page('نماذج للعمل اليومي','BUSINESS FORMS',f'''<div class="grid3"><div><div class="plate mist" style="height:435px;padding:20px">{app('payment-voucher',285)}</div><h3 style="margin-top:17px">سند</h3><p class="small">نموذج مالي توضيحي · A5 أفقي</p></div><div><div class="plate mist" style="height:435px;padding:20px">{app('receipt',285)}</div><h3 style="margin-top:17px">إيصال</h3><p class="small">حقول واضحة وتوقيع مستقل · A5 أفقي</p></div><div><div class="plate mist" style="height:435px;padding:20px">{app('quotation',395)}</div><h3 style="margin-top:17px">عرض سعر</h3><p class="small">وصف وبنود وقيم معتمدة · A4</p></div></div><p class="caption">النماذج لا تتضمن شروطًا قانونية أو مالية معتمدة؛ يُراجع محتواها الإداري قبل الاستخدام الفعلي.</p>''')

page('ملف يجمع تفاصيل العرض','PRESENTATION FOLDER',f'''<div class="split"><div class="vcenter"><h2>من أول انطباع إلى آخر مستند</h2><p style="margin-top:20px">غلاف هادئ بلون الحبر وإطار معماري، مع جيب داخلي للمطبوعات وبطاقة العمل. يظهر «السكني» كتوقيع تعريفي منفصل.</p><div class="rule"></div><p class="en">A4 CONTENT / FOLDER FACE & POCKET</p><p class="small" style="margin-top:20px">يُضبط عرض الكعب وعمق الجيب حسب عدد الأوراق وقالب المورد؛ الواجهات هنا مرجع للتصميم.</p></div><div style="display:flex;align-items:center;justify-content:center;gap:20px;background:var(--mist);padding:30px">{app('folder',510)}{app('folder-pocket',340)}</div></div>''')

page('بروشور يحكي بترتيب','BROCHURE',f'''<div class="split"><div class="vcenter"><h2>من المشهد إلى المعلومة</h2><p style="margin-top:20px">نبدأ بصورة سكنية هادئة، ثم نعرض الأفكار بتتابع قصير. تُستخدم المساحات المضيئة للنصوص، والحبر للغلاف والانتقالات.</p><div class="rule"></div><p class="en">A4 LANDSCAPE / TRI-FOLD CONCEPT</p><p class="small" style="margin-top:18px">يُراجع تعويض عرض الطية الداخلية مع المطبعة. الصور الحالية تصورية؛ والمحتوى يُستبدل ببيانات العرض المعتمدة.</p></div><div class="stack" style="gap:18px"><div>{app('brochure-outside',265)}<div class="app-label">OUTSIDE</div></div><div>{app('brochure-inside',265)}<div class="app-label">INSIDE</div></div></div></div>''')

page('الفلاير: فكرة واحدة قوية','FLYER',f'''<div class="split"><div class="vcenter"><div class="kicker">ONE MESSAGE / ONE ACTION</div><h2>صورة واضحة.<br>عنوان مباشر.<br>تفاصيل كافية.</h2><p style="margin-top:30px">نحافظ على تدرّج بصري بسيط، ونتجنب تكديس المميزات أو الأختام التسويقية. كل بيانات العقار تُراجع قبل النشر.</p><div class="rule"></div><p class="en">A5 / 148 × 210 mm</p></div><div class="plate mist" style="height:610px">{app('flyer',555)}</div></div>''')

page('الختم','STAMP',f'''<div class="split"><div class="vcenter"><h2>نسخة أحادية واضحة</h2><p style="margin-top:22px">تُستخدم نسخة الاسم الأصلية باللون الأحادي داخل مساحة متزنة. لا تضاف تراخيص أو أرقام تسجيل أو عناوين دون مرجع معتمد.</p><div class="rule"></div><p class="en">55 × 30 mm / SINGLE-COLOR SAMPLE</p><p class="small" style="margin-top:20px">تُفحص سماكة التفاصيل والفراغات مع صانع الختم، وتُعتمد عينة فعلية قبل التصنيع.</p></div><div class="plate mist" style="height:560px"><div style="width:490px;height:310px;background:white;transform:rotate(-5deg);display:flex;align-items:center;justify-content:center;box-shadow:15px 20px 30px #1c35491a">{app('stamp',190)}</div></div></div>''')

page('كيس يحمل الهوية','PAPER BAG',f'''<div class="split"><div class="vcenter"><h2>حقل لون واسع… وتفصيل محسوب</h2><p style="margin-top:20px">يبقى الشعار في مساحة آمنة، بعيدًا عن الثنيات والثقوب والمقابض. الإطار المعماري يحفظ حضور الواجهة دون ازدحام.</p><div class="rule"></div><p class="en">FACE CONCEPT / 250 × 320 mm</p><p class="small" style="margin-top:20px">واجهة إرشادية لكيس ورقي دعائي؛ تُركّب على قالب المورد بعد تحديد العمق والخامة والمقبض.</p></div><div class="plate mist" style="height:610px">{app('shopping-bag',540)}</div></div>''')

page('علبة تقدم التجربة','PRESENTATION BOX',f'''<div class="split"><div class="vcenter"><h2>نموذج علبة ترحيبية</h2><p style="margin-top:20px">تُستخدم كحاوية أنيقة للمطبوعات أو عناصر تجربة العميل. التكوين يحتفظ بهدوء اللؤلؤي أو عمق الحبر، مع تفصيل نحاسي محدود.</p><div class="rule"></div><p class="en">LID CONCEPT / 240 × 160 mm</p><p class="note">المقاس والارتفاع وآلية الإغلاق مقترحات تصميمية قابلة للتعديل؛ لا تُعد هذه الواجهة قالب قص هندسيًا نهائيًا.</p></div><div class="plate mist" style="height:610px;perspective:1200px"><div style="transform:rotateX(25deg) rotateZ(-8deg)">{app('presentation-box',370)}</div></div></div>''')

page('الأكواب الورقية','PAPER CUP',f'''<div class="split"><div class="vcenter"><h2>الوضوح على سطح منحني</h2><p style="margin-top:20px">نضع الشعار في منطقة مركزية واسعة، ونترك مساحة مستقلة للحواف ومناطق التراكب. يُختبر حجم العلامة على الكوب الفعلي.</p><div class="rule"></div><p class="small">القالب المعروض تخطيط مسطح أولي؛ يُكيَّف مع قياس الكوب ومخروطه وقالب الطباعة الذي يقدمه المصنع.</p><p class="note">لا تُفترض أبعاد تصنيع من العرض المسطح وحده.</p></div><div class="plate mist" style="height:610px"><div style="position:absolute;top:65px;width:260px;height:355px;background:var(--pearl);border-radius:18px 18px 60px 60px;box-shadow:18px 25px 30px #1c354926;display:flex;flex-direction:column;align-items:center;justify-content:center;border-top:13px solid #fff">{logo(width=190,branch=True)}</div><div style="position:absolute;bottom:25px;left:30px;right:30px">{app('cup',130)}</div></div></div>''')

page('ملصقات صغيرة… حضور متكامل','STICKERS',f'''<div class="split"><div class="vcenter"><h2>ختم بصري للتغليف والمطبوعات</h2><p style="margin-top:20px">ثلاث معالجات ضمن اللغة نفسها: رمز مستقل، توقيع كامل، وواجهة مستطيلة. تُختار النسخة حسب مساحة الطباعة ووضوح التفاصيل.</p><div class="rule"></div><p class="small">لا نُصغّر التوقيع الكامل إلى حد فقدان القراءة. نستخدم الرمز الأصلي في الملصقات الصغيرة، ونراجع مسار القص والنزف مع المورد.</p></div><div class="plate mist" style="height:610px;padding:30px">{app('stickers',500)}</div></div>''')

page('رول أب يستقبل الزائر','ROLL-UP',f'''<div class="split"><div class="vcenter"><h2>حضور يُقرأ من مسافة</h2><p style="margin-top:20px">الشعار والعنوان في الثلث العلوي، ثم المشهد السكني. تُترك منطقة آمنة في الأسفل لقاعدة الحامل، ويقتصر النص على الرسالة الرئيسية.</p><div class="rule"></div><p class="en">850 × 2000 mm / DISPLAY CONCEPT</p><p class="note">للطباعة بالحجم الكامل تُستبدل الصورة التصورية بصورة إنتاج عالية الدقة مناسبة لمسافة المشاهدة، ويُراجع قالب الحامل.</p></div><div class="plate mist" style="height:610px;flex-direction:column;padding:20px">{app('rollup',540)}<div style="width:270px;height:17px;background:linear-gradient(#b9c1c6,#6b7b85);border-radius:5px"></div></div></div>''')

page('اللافتات العقارية','PROPERTY SIGNAGE',f'''<div class="plate mist" style="height:415px;padding:35px">{app('signage',345)}</div><div class="grid2" style="margin-top:30px"><div><h2>العلامة أولًا</h2><p class="small" style="margin-top:10px">يُقرأ الشعار من مسافة، وتبقى المعلومات مختصرة. يُترك فاصل واضح بين الهوية وبيانات العرض المعتمدة.</p></div><div><p class="en">2000 × 1000 mm / SAMPLE LAYOUT</p><p class="small" style="margin-top:10px">التطبيق نموذج بصري. الصورة الحالية لا تصلح وحدها كملف إنتاج نهائي للافتة كبيرة؛ يلزم أصل فوتوغرافي أعلى دقة ومراجعة المطبعة.</p></div></div>''')

page('حضور متّسق في المنشورات','SOCIAL POSTS',f'''<div class="split"><div class="vcenter"><h2>صورة تتحدث… وعنوان يوجّه</h2><p style="margin-top:20px">نمنح المشهد السكني المساحة الأكبر. تُستخدم كتلة الحبر لتثبيت العلامة، بينما يحمل العنوان فكرة واحدة قابلة للفهم سريعًا.</p><div class="rule"></div><p class="en">1080 × 1350 px / PORTRAIT POST</p><p class="small" style="margin-top:20px">نصوص النموذج ومشهده توضيحية. عند نشر عقار فعلي تُستخدم بياناته وصوره المعتمدة ويُزال وصف النموذج فقط بعد التحقق.</p></div><div class="plate mist" style="height:610px">{app('social-post',560)}</div></div>''')

page('القصص العمودية','STORIES',f'''<div class="split"><div class="vcenter"><h2>المحتوى داخل المنطقة الآمنة</h2><p style="margin-top:20px">نترك فراغًا أعلى وأسفل التصميم لعناصر واجهة المنصة، ونضع المعلومة الأساسية في مركز القصة. تُضاف الروابط وملصقات التفاعل من أدوات المنصة.</p><div class="rule"></div><p class="en">1080 × 1920 px / STORY</p><p class="small" style="margin-top:20px">مرجع أولي للهوامش: نحو 250 بكسل أعلى وأسفل، مع مراجعة واجهة النشر الفعلية قبل الاستخدام.</p></div><div class="plate mist" style="height:610px"><div style="padding:9px;background:#172630;border-radius:24px;box-shadow:15px 20px 35px #1c354930">{app('social-story',555)}</div></div></div>''')

page('إعلان سكني يحترم التفاصيل','RESIDENTIAL ADVERTISING',f'''<div class="split"><div class="vcenter"><div class="kicker">EDITORIAL CAMPAIGN SAMPLE</div><div class="display" style="font-size:66px">مساحة<br>تشبه حياتك.</div><p style="margin-top:25px">عنوان مقترح يفتح الحديث عن تجربة السكن. يتبعه وصف محدد للمكان ودعوة واضحة للتواصل، دون وعود مطلقة أو بيانات غير مثبتة.</p><p class="note">هذا عنوان إعلاني تجريبي، وليس شعارًا رسميًا معتمدًا للعلامة.</p></div><div class="plate" style="height:610px;background:var(--ink);padding:25px;gap:25px">{app('flyer',410)}{app('social-post',410)}</div></div>''')

page('بطاقة عرض العقار','PROPERTY CARD',f'''<div class="split"><div class="vcenter"><h2>تفاصيل تساعد على المقارنة</h2><p style="margin-top:20px">صورة رئيسية، عنوان، وحقول معتمدة للموقع والمساحة ونوع العقار. تُقدّم المعلومات بتسلسل ثابت يسهل استخدامه عبر عروض متعددة.</p><div class="rule"></div><p class="en">A5 / EDITABLE LISTING TEMPLATE</p><p class="small" style="margin-top:20px">حقول البيانات في النموذج مخصصة للاستبدال. لا تُنشر أي مساحة أو سعر أو ميزة قبل مطابقتها مع ملف العقار.</p></div><div class="plate mist" style="height:610px">{app('property-card',555)}</div></div>''')

page('العروض التسويقية','PRESENTATION SYSTEM',f'''<div class="split"><div class="vcenter"><h2>من الغلاف إلى التفاصيل</h2><p style="margin-top:20px">غلاف واسع يعرّف العرض، وشريحة داخلية توزّع النص والصورة والمعلومات. يحافظ النظام على الإيقاع نفسه دون تكرار الغلاف في كل صفحة.</p><div class="rule"></div><p class="en">1600 × 900 px / 16:9</p><p class="small" style="margin-top:20px">العنوان والبيانات قابلة للتعديل. تبقى الهوامش والمحاذاة وألوان القراءة ثابتة.</p></div><div class="stack" style="gap:25px">{app('presentation-cover',277)}{app('presentation-detail',277)}</div></div>''')

page('حضور ملموس للهوية','WELCOME EXPERIENCE','''<div class="photo-frame" style="height:520px"><img class="photo" src="../assets/images/mockup_packaging.png" alt="تصور تغليف الدايل السكني"><span class="photo-cap">موك أب ثلاثي الأبعاد باستخدام الشعار الأصلي؛ الألوان تتأثر بمحاكاة الضوء والخامة.</span></div><p class="caption">الكيس والعلبة والمطبوعات عناصر متصلة في تجربة واحدة. المرجع اللوني هو القيم المحددة في الدليل، لا عينة مأخوذة من صورة الموك أب.</p>''')

page('حزمة جاهزة للتطوير والتطبيق','ASSET LIBRARY','''<div class="grid3"><div class="index-item"><h3>الشعارات</h3><p class="small">نسخ أصلية ومتجهية مع إعادة تلوين فقط. العربية والإنجليزية والرمز والاسم، مع سجل يثبت تطابق الهندسة.</p><p class="en tiny" style="margin-top:15px">assets/logos/</p></div><div class="index-item"><h3>التطبيقات</h3><p class="small">SVG قابلة للتعديل، ونسخ عرض بخطوط محولة إلى مسارات، وPDF بأبعاد التطبيقات المحددة.</p><p class="en tiny" style="margin-top:15px">applications/ · applications/editable/</p></div><div class="index-item"><h3>الحركة</h3><p class="small">فيديو قصير صامت ومصدر للحركة الرقمية وبديل ثابت، دون تغيير هندسة الشعار.</p><p class="en tiny" style="margin-top:15px">motion/</p></div><div class="index-item"><h3>مصدر الدليل</h3><p class="small">صفحات HTML/CSS ومولد قابل للتعديل، مع نصوص عربية حيّة وشعارات متجهية داخل PDF.</p><p class="en tiny" style="margin-top:15px">source/build_book.py · source/book.css</p></div><div class="index-item"><h3>البحث اللوني</h3><p class="small">المجموعات الثلاث، مبررات الاختيار، قيم التباين، وروابط المصادر وتواريخ الاطلاع.</p><p class="en tiny" style="margin-top:15px">research/ · assets/design-tokens.json</p></div><div class="index-item"><h3>المعاينات والتدقيق</h3><p class="small">معاينات الصفحات، فحص جودة PDF، ومطابقة قائمة المتطلبات مع مواضعها في الدليل.</p><p class="en tiny" style="margin-top:15px">previews/ · quality/</p></div></div>''')

page('قبل النشر أو الإنتاج','PRODUCTION CHECKLIST','''<div class="grid2"><div class="panel"><div class="kicker">DIGITAL</div><h2>جاهزية المحتوى</h2><div class="rule"></div><p class="small">01 · اعتماد النصوص والبيانات والصور الفعلية.<br>02 · استبدال رمز QR التجريبي واختباره.<br>03 · مراجعة التباين والهوامش وواجهة المنصة.<br>04 · حفظ نسخة sRGB بالمقاس المطلوب.<br>05 · عدم نسبة المشاهد التصورية إلى عقارات فعلية.</p></div><div class="panel"><div class="kicker">PRINT</div><h2>جاهزية التصنيع</h2><div class="rule"></div><p class="small">01 · استلام قالب المورد والقص والثني.<br>02 · ضبط النزف والهوامش والصورة بالحجم النهائي.<br>03 · اعتماد ملف ICC وعينة اللون والخامة.<br>04 · مراجعة الخطوط والمسارات ووضوح التوقيع.<br>05 · اعتماد عينة قبل طباعة الكميات.</p></div></div><p class="note">الدليل مرجع تصميمي للهوية. قوالب التطبيقات ملفات مراجعة وإعداد؛ لا يُستنتج منها اعتماد بيانات الشركة أو جاهزية تصنيع جميع المقاسات دون فحص المورد.</p>''')

def source_card(s):
    dates=f'Retrieved 19 Oct 2026'+(f' · Published {s["published"]}' if s.get('published') else '')
    arabic={
      'S1':'إعلان لوحة Pinterest 2026 ومنهجيتها: إشارات المستخدمين، البحث البصري، والتحرير المتخصص.',
      'S2':'اللوحة الرسمية: <bdi dir="ltr">Cool Blue</bdi>، <bdi dir="ltr">Jade</bdi>، <bdi dir="ltr">Plum Noir</bdi>، <bdi dir="ltr">Wasabi</bdi>، <bdi dir="ltr">Persimmon</bdi>؛ استُخدمت لفهم الاتجاهات.',
      'S3':'اتجاه الأزرق البارد؛ بيانات بحث عالمية باللغة الإنجليزية، وليست دراسة سوق عقاري محلي.',
      'S4':'اتجاهات الإبداع: الإحساس، الاتصال العاطفي، والهوية الثقافية. مرجع للتوجه البصري العام.',
      'S5':'اتجاهات تصميم 2026 ونبرة مرئية إنسانية مرحبة؛ لا يحدد درجات HEX لهذه العلامة.',
      'S6':'شريك Pantone الرسمي يؤكد Cloud Dancer واتجاه الهدوء. تعذر الوصول مباشرة إلى Pantone؛ يوجد تعارض في تاريخ المتن موضح بالبحث.',
      'S7':'استمرار المحايدات الدافئة في البيئة السكنية. مرجع للمعيشة والخامات، وليس استطلاعًا للهويات التجارية.',
      'S8':'معيار تباين النصوص الرقمي: 4.5:1 للنص العادي و3:1 للنص الكبير.',
      'S9':'عائلة درجات الأزرق لعام 2026 في المساحات السكنية؛ دعم مستقل لتكرار الاتجاه خارج Pinterest.',
      'S10':'تأكيد الاتجاه من الشركة الأم، في سياق بحث يضم العمارة والتصميم الداخلي.'}
    return f'<div class="source-item"><h3>{html.escape(s["publisher"])} / {s["id"]}</h3><p>{arabic.get(s["id"],"مرجع داعم لبحث الاتجاهات اللونية.")}</p><a href="{html.escape(s["url"])}">{html.escape(s["url"])}</a><div class="date">{dates}</div></div>'

page('مصادر البحث اللوني — 1','RESEARCH SOURCES','<div class="source-list">'+''.join(source_card(s) for s in SOURCES[:5])+'</div>')
page('مصادر البحث اللوني — 2','RESEARCH SOURCES','<div class="source-list">'+''.join(source_card(s) for s in SOURCES[5:])+'</div>')

page('المصادر والحقوق وحدود النسخة','PROVENANCE & STATUS','''<div class="grid2"><div class="stack"><div><h3>الأصول الأصلية</h3><p class="small" style="margin-top:12px">الشعار والخطوط من حزمة Branding Assets – AlDayel Real Estate التي قدّمها المستخدم. حُفظت مسارات الشعار الأصلية دون إعادة رسم. القواعد الجديدة للفرع السكني مقترحة للاعتماد.</p></div><div><h3>الخطوط</h3><p class="small" style="margin-top:12px">Helvetica Neue LT Arabic يسمح بتضمين المعاينة والطباعة وفق بيانات ملف الخط. ملفات الخط التجاري الأصلية لا تُعاد توزيعها في الحزمة؛ مصدر التحرير يحتاج نسختها المرخّصة. PT Sans مرفق وفق ترخيصه.</p></div><div><h3>المشاهد والموك أب</h3><p class="small" style="margin-top:12px">المشاهد السكنية تصورية مولّدة؛ الموك أب رندرات ثلاثية الأبعاد بأصول الشعار الأصلي. لا يُنسب أي منها إلى عقار أو منتج فعلي للشركة.</p></div></div><div class="stack"><div><h3>مرجعا الإخراج الخارجيان</h3><p class="small" style="margin-top:12px">تمت معاينة «مثال مرجعي للملف المطلوب إخراجه» كلوحة طويلة كاملة، و«مثال مرجعي 2» بصفحاته الثلاث والثلاثين. استُخدما لتنظيم العرض وحجم الموك أب والإيقاع البصري فقط؛ لم تُنقل شعاراتهما أو ألوانهما أو نصوصهما.</p></div><div><h3>حدود البحث</h3><p class="small" style="margin-top:12px">تعذر الوصول المباشر إلى بعض صفحات Pantone وWGSN/Coloro. لم تُنسب إليها نتائج غير متاحة؛ استُخدمت المصادر المؤكدة والمذكورة بروابطها.</p></div><div><h3>الاعتماد</h3><p class="small" style="margin-top:12px">هذه نسخة مدقّقة من ناحية التصميم للعرض والاعتماد، وتصبح مرجعًا رسميًا بعد اعتماد العلامة والبيانات ومواصفات الإنتاج. لا تتضمن ادعاءً باعتماد جهة خارجية.</p></div></div></div>''')

page('الدايل السكني','A NEW RESIDENTIAL EXPRESSION',f'''<div style="position:absolute;inset:-20px 0 0">{motif(PEARL,.2)}</div><div style="position:relative;display:flex;height:100%;flex-direction:column;align-items:center;justify-content:center;gap:40px"><div style="background:var(--ink);box-shadow:0 0 0 60px var(--ink);z-index:1">{logo(color='pearl',width=500,branch=True)}</div><div class="rule" style="width:620px"></div><div class="kicker">SPACE / LIGHT / BELONGING</div><p class="small">أصل ثابت. لغة سكنية معاصرة.</p></div>''','ink')

from refine_application_spreads import apply as refine_spreads
refine_spreads(PAGES, logo, app)
from premium_editorial import apply as refine_copy
refine_copy(PAGES)
from premium_applications import apply as refine_applications
refine_applications(PAGES, logo, app)
from premium_layouts import apply as refine_layouts
refine_layouts(PAGES, logo, app)

assert len(PAGES)==62, len(PAGES)
document='<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>AlDayel Residential — Premium Brand Identity Guidelines</title><link rel="stylesheet" href="book.css"><link rel="stylesheet" href="premium.css"><link rel="stylesheet" href="premium-applications.css"></head><body>'+''.join(p['html'] for p in PAGES)+'</body></html>'
(ROOT/'source/book.html').write_text(document)
(ROOT/'quality/page-manifest.json').write_text(json.dumps([{'page':i+1,'title':p['title'],'section':p['section']} for i,p in enumerate(PAGES)],ensure_ascii=False,indent=2))
for i,_,_ in icons:
    (ROOT/'assets/graphics'/f'icon-{i}.svg').write_text(line_icon(i).replace('currentColor',INK))
(ROOT/'assets/graphics/architectural-pattern.svg').write_text(motif(INK,.5).split('<svg',1)[1].split('</svg>')[0].join(['<svg','</svg>']).replace('viewBox','xmlns="http://www.w3.org/2000/svg" viewBox',1))
# Export the same editable illustration displayed on page 33.
illustration = re.search(r'<svg.*?</svg>', PAGES[32]['html']).group(0)
(ROOT/'assets/graphics/residential-illustration.svg').write_text(illustration)
print(f'Built {len(PAGES)} pages: {ROOT / "source/book.html"}')
