#!/usr/bin/env python3
"""Render every exported PDF page and record reproducible pixel fingerprints.

Optional comparison identifies pages whose 200 DPI pixels are unchanged from
an earlier reviewed export. Changed pages require a fresh visual inspection.
"""
import argparse
import hashlib
import json
from pathlib import Path

import fitz


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pdf', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--dpi', type=int, default=200)
    parser.add_argument('--compare-manifest', type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    record = {'pdf_sha256': hashlib.sha256(args.pdf.read_bytes()).hexdigest(),
              'dpi': args.dpi, 'pages': []}
    with fitz.open(args.pdf) as doc:
        for n, page in enumerate(doc, 1):
            pix = page.get_pixmap(dpi=args.dpi, alpha=False)
            name = f'page-{n:02d}.png'
            pix.save(args.output / name)
            record['pages'].append({'page': n, 'preview': name,
                'pixel_sha256': hashlib.sha256(pix.samples).hexdigest()})
    (args.output / 'manifest.json').write_text(json.dumps(record, indent=2))
    if args.compare_manifest:
        prior = json.loads(args.compare_manifest.read_text())
        if prior['dpi'] != args.dpi or len(prior['pages']) != len(record['pages']):
            raise ValueError('Comparison requires identical DPI and page count')
        hashes = {x['page']: x['pixel_sha256'] for x in prior['pages']}
        identical = [x['page'] for x in record['pages'] if x['pixel_sha256'] == hashes[x['page']]]
        changed = [x['page'] for x in record['pages'] if x['page'] not in identical]
        result = {'previous_pdf_sha256': prior['pdf_sha256'],
                  'final_pdf_sha256': record['pdf_sha256'], 'dpi': args.dpi,
                  'identical_pages': identical, 'changed_pages': changed,
                  'method': 'SHA256 of uncompressed RGB pixels from PyMuPDF at identical DPI; visual reinspection required for every changed page.'}
        (args.output / 'comparison.json').write_text(json.dumps(result, indent=2))
        print(json.dumps(result))
    else:
        print(json.dumps({'pages': len(record['pages']), 'pdf_sha256': record['pdf_sha256']}))


if __name__ == '__main__':
    main()
