"""Premium application spreads 36–56; original artwork stays unmodified.

All applications use the existing proportional inline-SVG helper. Detail views
are crops of the same artwork, never redrawn logos or distorted paper mockups.
"""
from pathlib import Path


def apply(pages, logo, app):
    def replace(n, title, body, extra=''):
        extra = (extra + ' ' + {46: 'mist', 53: 'ink'}.get(n, '')).strip()
        item = pages[n - 1]
        item['title'] = title
        item['html'] = f'''<section class="page premium-app pa-page {extra}" id="p{n}"><header class="running"><span>ALDAYEL / RESIDENTIAL</span><span class="ar">{item['section']}</span></header><h1 class="title">{title}</h1><div class="body">{body}</div><footer class="footer"><span>{n:02d} / BRAND GUIDELINES</span><span class="ar">الدايل السكني · 2026</span></footer></section>'''

    def sheet(name, height, label='', cls=''):
        return f'<div class="pa-specimen {cls}"><div class="pa-sheet">{app(name, height)}</div>' + (f'<div class="pa-label">{label}</div>' if label else '') + '</div>'

    def image(name, alt):
        return f'<img class="pa-image" src="../assets/images/{name}.png" alt="{alt}">'

    def bottom(text, meta=''):
        return f'<div class="pa-bottom"><p>{text}</p>' + (f'<span class="pa-meta">{meta}</span>' if meta else '') + '</div>'

    def detail(name, fullheight, cropheight, top=0, label=''):
        return f'<div class="pa-detail"><div class="pa-crop" style="height:{cropheight}px"><div style="position:absolute;top:-{top}px;left:50%;transform:translateX(-50%)">{app(name, fullheight)}</div></div><div class="pa-label">{label}</div></div>'

    replace(36, 'الهوية في الاستخدام', f'''<div class="pa-layout pa-material"><div class="pa-essay"><span class="pa-overline">MATERIAL / SIGNATURE / SPACE</span><h2>حضور واحد.<br>خامات متعددة.</h2><div class="pa-rule"></div><p>العلامة الأصلية، وفراغ مريح،<br>وتفصيل نحاسي محسوب.</p><p class="pa-small">القيم اللونية هي مرجع الإنتاج؛<br>تتأثر ألوان المشهد بالإضاءة والخامة.</p></div><div class="pa-material-image">{image('mockup_stationery','تصور ثلاثي الأبعاد للقرطاسية؛ الشعار الأصلي دون تعديل')}</div></div>''' + bottom('تصوّر ثلاثي الأبعاد للقرطاسية؛ ليس تصويرًا لمنتج فعلي.', 'STATIONERY / MATERIAL STUDY'))

    replace(37, 'بطاقات العمل', f'''<div class="pa-layout pa-card-pair"><div class="pa-card-front">{sheet('business-card-front', 350, '01 / FRONT')}</div><div class="pa-card-back">{sheet('business-card-back', 350, '02 / BACK')}</div><span class="pa-floating-meta">90 × 55 mm</span></div>''' + bottom('بيانات شخصية معتمدة فقط. رمز QR تجريبي؛ يُستبدل بالرابط المعتمد ويُختبر قبل الطباعة، مع هامش حر من أربع وحدات.', 'FRONT & BACK'))

    replace(38, 'ورق المراسلات', f'''<div class="pa-layout pa-detail-spread"><div class="pa-primary">{sheet('letterhead', 540, 'A4 / 210 × 297 mm')}</div><div class="pa-detail-column"><span class="pa-overline">DETAIL / ORIGINAL ARTWORK</span>{detail('letterhead', 1180, 250, 0, 'تفصيل الترويسة')}<div class="pa-rule"></div><h2>التوقيع في المقدمة.<br>والمساحة للمراسلة.</h2><p class="pa-small">هوامش مريحة للنص والتوقيع؛ تُستكمل بيانات العنوان والتواصل من مرجع الشركة المعتمد.</p></div></div>''')

    replace(39, 'الأظرف', f'''<div class="pa-layout pa-envelopes"><div class="pa-envelope dl">{sheet('envelope-dl', 176, 'DL / 220 × 110 mm')}</div><div class="pa-envelope c5">{sheet('envelope-c5', 259.2, 'C5 / 229 × 162 mm')}</div><div class="pa-envelope c4">{sheet('envelope-c4', 366.4, 'C4 / 324 × 229 mm')}</div></div>''' + bottom('ثلاثة مقاسات بنسبة عرض موحّدة. تُضبط مساحة العنوان والثنيات واللصق على قالب المورد.', 'DL / C5 / C4'))

    replace(40, 'النماذج الرسمية', f'''<div class="pa-layout pa-forms"><div class="pa-form">{sheet('payment-voucher', 284, 'A5 LANDSCAPE / 210 × 148 mm')}<h3>سند قبض</h3><p>رقم وبيانات وتوقيعات مستقلة.</p></div><div class="pa-form">{sheet('receipt', 284, 'A5 LANDSCAPE / 210 × 148 mm')}<h3>إيصال</h3><p>حقول واضحة وتسلسل ثابت.</p></div><div class="pa-form quote">{sheet('quotation', 440, 'A4 / 210 × 297 mm')}<h3>عرض سعر</h3></div></div>''' + bottom('نماذج قابلة للتحرير؛ يُراجع محتواها الإداري والمالي والشروط قبل الاستخدام الفعلي.'))

    replace(41, 'ملف العرض', f'''<div class="pa-layout pa-folder"><div class="pa-folder-copy"><span class="pa-overline">A4 CONTENT</span><h2>واجهة هادئة.<br>وتفاصيل محفوظة.</h2><p class="pa-small">غلاف وجيب داخلي للمطبوعات وبطاقة العمل.</p></div><div class="pa-folder-face">{sheet('folder', 522, '01 / COVER')}</div><div class="pa-folder-pocket">{sheet('folder-pocket', 425, '02 / POCKET FACE')}</div></div>''' + bottom('واجهات مرجعية للتصميم؛ يُراجع الكعب وعمق الجيب وقالب القص مع المورد وفق عدد الأوراق.'))

    replace(42, 'البروشور', f'''<div class="pa-layout pa-brochures"><div>{sheet('brochure-outside', 470, '01 / OUTSIDE')}</div><div>{sheet('brochure-inside', 470, '02 / INSIDE')}</div></div>''' + bottom('يُراجع تعويض عرض الطية الداخلية مع المطبعة. الصور تصورية، ويُستبدل المحتوى ببيانات العرض المعتمدة.', 'A4 LANDSCAPE / TRI-FOLD CONCEPT'))

    replace(43, 'الفلاير', f'''<div class="pa-layout pa-flyer"><div class="pa-flyer-art">{sheet('flyer', 548, 'A5 / 148 × 210 mm')}</div><div class="pa-flyer-copy"><span class="pa-overline">ONE MESSAGE</span><h2>فكرة واحدة.<br>وحيّز يتّسع لها.</h2><div class="pa-three-lines"><div><span>01</span><p>صورة تقود المشهد</p></div><div><span>02</span><p>عنوان قصير وواضح</p></div><div><span>03</span><p>تفاصيل معتمدة للتواصل</p></div></div><p class="pa-small">الصورة والمحتوى توضيحيان؛ يُستبدلان بمواد العقار المعتمدة قبل النشر.</p></div></div>''')

    replace(44, 'الختم', f'''<div class="pa-layout pa-stamp"><div class="pa-stamp-art">{sheet('stamp', 285, '55 × 30 mm / SINGLE-COLOR SAMPLE')}</div><div class="pa-stamp-copy"><span class="pa-overline">SINGLE COLOR</span><h2>وضوح في<br>أصغر التفاصيل.</h2><p>نسخة الاسم الأصلية بلون واحد.</p><div class="pa-rule"></div><p class="pa-small">لا تُضاف تراخيص أو أرقام تسجيل أو عناوين دون مرجع معتمد.</p></div></div>''' + bottom('تُفحص سماكة التفاصيل والفراغات مع صانع الختم، وتُعتمد عينة فعلية قبل التصنيع.'))

    replace(45, 'الأكياس الورقية', f'''<div class="pa-layout pa-bag"><div class="pa-bag-art">{sheet('shopping-bag', 435, 'PEARL / 250 × 320 mm')}<p class="pa-small">واجهة لؤلؤية بديلة</p></div><div class="pa-bag-photo">{image('mockup_packaging','تصور تغليف ثلاثي الأبعاد بالكيس ذي اللون الحبري')}<div class="pa-label">INK / MATERIAL STUDY</div></div></div>''' + bottom('نموذج حبري وتصميم لؤلؤي بديل. يُبعد الشعار عن المقابض والثنيات؛ تُراجع الخامة والعمق وقالب المورد.'))

    replace(46, 'علبة التقديم', f'''<div class="pa-layout pa-box"><div class="pa-box-art">{sheet('presentation-box', 475, 'LID / 240 × 160 mm')}</div><div class="pa-box-copy"><span class="pa-overline">LID DESIGN</span><h2>وجه واضح.<br>وخامة تكمله.</h2><p>واجهة مسطحة لعلبة ترحيبية،<br>لعرض المطبوعات وعناصر الاستقبال.</p><div class="pa-rule"></div><p class="pa-small">المقاس والارتفاع وآلية الإغلاق قابلة للتعديل. تعتمد الخامة وقالب القص النهائي مع المورد.</p></div></div>''' + bottom('واجهة الغطاء مرجع تصميمي؛ ليست قالب قص أو مخطط تصنيع معتمدًا.'))

    replace(47, 'الأكواب الورقية', f'''<div class="pa-layout pa-cups"><div class="pa-cup-notes"><span class="pa-overline">CURVED SURFACE</span><h2>مساحة مركزية<br>للعلامة.</h2>{sheet('cup', 155, 'ALTERNATE FLAT LAYOUT / 260 × 110 mm')}<p class="pa-small">تخطيط مسطح بديل أولي؛<br>ليس قالب تصنيع للكوب.</p></div><div class="pa-cup-photo">{image('mockup_cups','تصور أكواب ورقية ثلاثي الأبعاد؛ نصوص وشعارات أصلية')}</div></div>''' + bottom('يُختبر الحجم على الكوب الفعلي، ويُكيّف التصميم مع المخروط والحواف ومناطق التراكب التي يحددها المصنع.'))

    replace(48, 'الملصقات', f'''<div class="pa-layout pa-stickers"><div class="pa-sticker-art">{sheet('stickers', 500, 'ICON / WORDMARK / SEAL')}</div><div class="pa-sticker-copy"><span class="pa-overline">THREE FORMATS</span><h2>تفاصيل صغيرة،<br>بتوقيع واضح.</h2><div class="pa-three-lines"><div><span>01</span><p>الرمز للمساحات الصغيرة</p></div><div><span>02</span><p>الاسم على الخامة اللؤلؤية</p></div><div><span>03</span><p>شريط لإغلاق التغليف</p></div></div></div></div>''' + bottom('نحافظ على وضوح الاسم أو الرمز الأصلي؛ يُراجع مسار القص والنزف مع المورد.'))

    replace(49, 'رول أب', f'''<div class="pa-layout pa-rollup"><div class="pa-rollup-art">{sheet('rollup', 548, '850 × 2000 mm')}</div><div class="pa-rollup-copy"><span class="pa-overline">DISPLAY ARTWORK</span><h2>رسالة تُقرأ<br>من مسافة.</h2><div class="pa-three-lines"><div><span>01</span><p>الشعار والعنوان في الثلث العلوي</p></div><div><span>02</span><p>صورة رئيسية ورسالة مختصرة</p></div><div><span>03</span><p>مساحة سفلية آمنة لقاعدة الحامل</p></div></div><p class="pa-small">للإنتاج بالحجم الكامل تُستخدم صورة عالية الدقة مناسبة لمسافة المشاهدة، ويُراجع قالب الحامل.</p></div></div>''')

    replace(50, 'اللافتات العقارية', f'''<div class="pa-layout pa-signage"><div class="pa-signage-copy"><span class="pa-overline">2000 × 1000 mm</span><h2>العلامة<br>أولًا.</h2><p class="pa-small">رسالة واحدة وفاصل واضح<br>بين الصورة والمعلومات.</p></div><div class="pa-signage-art">{sheet('signage', 518, 'FRONT VIEW / SAMPLE LAYOUT')}</div></div>''' + bottom('التطبيق تصوّر بصري. للإنتاج بالحجم الكامل يُستخدم أصل أعلى دقة وتُراجع مواصفات المطبعة والبيانات المعتمدة.'))

    replace(51, 'المنشورات', f'''<div class="pa-layout pa-social"><div class="pa-social-art">{sheet('social-post', 548, '1080 × 1350 px')}</div><div class="pa-social-detail"><span class="pa-overline">TYPOGRAPHY / DETAIL</span>{detail('social-post', 1080, 190, 170, 'تفصيل العنوان')}<div class="pa-rule"></div><h2>المكان هو البطل.</h2><p>صورة واحدة، وتوقيع ثابت،<br>ومعلومات قليلة تهمّ المشاهد.</p><p class="pa-small">الصور والنصوص توضيحية؛ تُستخدم مواد كل عقار المعتمدة قبل النشر.</p></div></div>''')

    safe_height = 536
    safe_band = safe_height * 250 / 1920
    replace(52, 'القصص العمودية', f'''<div class="pa-layout pa-stories"><div class="pa-story-copy"><span class="pa-overline">1080 × 1920 px</span><h2>مساحة آمنة<br>للمحتوى.</h2><p class="pa-small">نحو 250 بكسل أعلى وأسفل لعناصر واجهة المنصة. توضع المعلومات الرئيسية في المركز.</p><div class="pa-rule"></div><p class="pa-small">تُراجع واجهة النشر الفعلية، وتُضاف الروابط وملصقات التفاعل من أدوات المنصة.</p></div><div class="pa-story-diagram"><div class="pa-safe-map" style="width:{safe_height * 1080 / 1920}px;height:{safe_height}px"><div class="pa-safe-band top" style="height:{safe_band}px"><span>250 px</span></div><div class="pa-safe-center"><span>المحتوى الأساسي</span><span class="en">1420 px</span></div><div class="pa-safe-band bottom" style="height:{safe_band}px"><span>250 px</span></div></div><div class="pa-label">SAFE AREA / GUIDANCE</div></div><div>{sheet('social-story', safe_height, 'STORY / ORIGINAL ARTWORK')}</div></div>''')

    replace(53, 'لغة الحملة', f'''<div class="pa-layout pa-campaign"><div class="pa-campaign-note"><span class="pa-overline">EDITORIAL CAMPAIGN</span><h2>فكرة متّصلة.<br>بمقاسين.</h2><p>وصف محدد للمكان،<br>ودعوة واضحة للتواصل.</p><div class="pa-rule"></div><p class="pa-small">العبارة الإعلانية مقترحة، وليست شعارًا لفظيًا معتمدًا. تُراجع البيانات قبل النشر دون وعود غير مثبتة.</p></div><div class="pa-campaign-art">{sheet('flyer', 508, 'A5 / FLYER')}{sheet('social-post', 508, '1080 × 1350 px / POST')}</div></div>''')

    replace(54, 'بطاقة العقار', f'''<div class="pa-layout pa-property"><div class="pa-property-art">{sheet('property-card', 548, 'A5 / EDITABLE LISTING')}</div><div class="pa-property-detail"><span class="pa-overline">INFORMATION / DETAIL</span>{detail('property-card', 1170, 280, 790, 'حقول البيانات: النوع، المساحة، الموقع')}<div class="pa-rule"></div><h2>تفاصيل تُسهّل المقارنة.</h2><p class="pa-small">صورة وعنوان للمشروع، ثم بيانات الوحدة بتسلسل ثابت. تبقى الحقول خالية حتى اعتمادها.</p><p class="pa-small">لا تُنشر مساحة أو سعر أو ميزة قبل مطابقتها مع ملف العقار.</p></div></div>''')

    replace(55, 'العروض التسويقية', f'''<div class="pa-layout pa-presentations"><div class="pa-slide-cover">{sheet('presentation-cover', 382.5, '01 / COVER')}</div><div class="pa-slide-detail">{sheet('presentation-detail', 382.5, '02 / CONTENT')}</div></div>''' + bottom('غلاف ثم شريحة داخلية. تبقى الهوامش والمحاذاة وألوان القراءة ثابتة؛ العنوان والبيانات قابلان للتعديل.', '1600 × 900 px / 16:9'))

    welcome_file = 'mockup_packaging_welcome' if (Path(__file__).resolve().parent.parent / 'assets/images/mockup_packaging_welcome.png').exists() else 'mockup_packaging'
    replace(56, 'تجربة الترحيب', f'''<div class="pa-layout pa-welcome"><div class="pa-welcome-copy"><span class="pa-overline">A COHERENT EXPERIENCE</span><h2>من أول<br>انطباع.</h2><p class="pa-small">الكيس والعلبة والمطبوعات<br>ضمن لغة واحدة.</p><div class="pa-rule"></div><p class="pa-small">تُراجع الخامة والطباعة بعينة فعلية قبل إنتاج الكميات.</p></div><div class="pa-welcome-image">{image(welcome_file,'تصور ترحيبي ثلاثي الأبعاد للعلبة والكيس والمطبوعات')}</div></div>''' + bottom('تصوّر تطبيقي باستخدام الشعار الأصلي؛ المرجع اللوني هو القيم المحددة في الدليل.', 'WELCOME / MATERIAL STUDY'))

    return list(range(36, 57))
