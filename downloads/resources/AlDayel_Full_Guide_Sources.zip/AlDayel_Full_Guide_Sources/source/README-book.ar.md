# إعادة بناء دليل PREMIUM

انتقلت تعليمات الدليل إلى [README-premium.ar.md](README-premium.ar.md). هذه هي التعليمات المعتمدة لوحدات PREMIUM وترتيب CSS وتصدير الدليل والتقرير المختصر والنص المنطقي والمعاينات.

للتطبيقات المنفصلة راجع [README-applications.md](README-applications.md)، وللموك أب راجع [mockups/README.md](mockups/README.md). ملفات الخط العربي التجارية غير معاد توزيعها؛ يلزم توفير نسخ المستخدم المرخّصة عند إعادة التصدير.
