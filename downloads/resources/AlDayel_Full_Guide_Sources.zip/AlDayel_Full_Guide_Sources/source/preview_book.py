"""Generate readable page previews and a compact contact sheet from the PDF."""
from pathlib import Path
import argparse, fitz
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser()
parser.add_argument('--pdf',type=Path,default=ROOT/'AlDayel_Residential_Brand_Guidelines_PREMIUM_FINAL.pdf')
parser.add_argument('--output',type=Path,default=ROOT/'previews')
parser.add_argument('--dpi',type=int,default=200)
args=parser.parse_args()
args.output.mkdir(parents=True,exist_ok=True)
doc=fitz.open(args.pdf)
font=ImageFont.truetype(str(ROOT/'assets/fonts/PTSans-Regular.ttf'),18)
thumbs=[]
for i,page in enumerate(doc):
    pix=page.get_pixmap(dpi=args.dpi,alpha=False)
    im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
    im.save(args.output/f'page-{i+1:02d}.jpg',quality=94,subsampling=0,dpi=(args.dpi,args.dpi))
    thumb=im.resize((400,225))
    thumbs.append(thumb)
for start in range(0,len(thumbs),12):
    batch=thumbs[start:start+12]
    canvas=Image.new('RGB',(1200,260*((len(batch)+2)//3)), '#dedfdb')
    draw=ImageDraw.Draw(canvas)
    for j,im in enumerate(batch):
        x=(j%3)*400; y=(j//3)*260
        canvas.paste(im,(x,y)); draw.text((x+12,y+230),f'{start+j+1:02d}',font=font,fill='#1C3549')
    canvas.save(args.output/f'contact-{start+1:02d}.jpg',quality=92)
doc[0].get_pixmap(dpi=args.dpi,alpha=False).save(args.output/'cover.png')
print(f'Rendered {len(doc)} pages to {args.output}')
