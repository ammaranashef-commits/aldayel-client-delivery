"""Render the verified two-page review using the licensed Arabic font server."""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import shutil
import threading
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import fitz
from playwright.async_api import async_playwright

from build_premium_review import ROOT, VERIFICATION, verified_results


async def render(destination, verification=VERIFICATION):
    _, current_hash = verified_results(verification)
    source = ROOT / 'source/premium-review.html'
    if not source.is_file():
        raise FileNotFoundError('Run source/build_premium_review.py after completing verification')
    match = re.search(r'<meta name="verification-sha256" content="([a-f0-9]{64})">', source.read_text())
    if not match or match.group(1) != current_hash:
        raise ValueError('Review HTML is stale; rebuild it from the current final verification')
    font_dir = Path(os.environ.get('ALDAYEL_FONT_DIR', ROOT.parent / '.work/fonts')).resolve()
    names = ['HelveticaNeueLTArabic-Roman.otf', 'HelveticaNeueLTArabic-Bold.otf']
    for name in names:
        if not (font_dir / name).is_file():
            raise FileNotFoundError(f'Supply licensed Arabic fonts via ALDAYEL_FONT_DIR: {name}')

    class Handler(SimpleHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_GET(self):
            prefix = '/__aldayel_fonts/'
            if self.path.startswith(prefix):
                name = self.path[len(prefix):]
                if name not in names:
                    self.send_error(404)
                    return
                content = (font_dir / name).read_bytes()
                self.send_response(200)
                self.send_header('Content-Type', 'font/otf')
                self.send_header('Content-Length', str(len(content)))
                self.end_headers()
                self.wfile.write(content)
                return
            return super().do_GET()

    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(Handler, directory=str(ROOT.parent)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    raw = destination.with_name(destination.stem + '-raw.pdf')
    try:
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(
                executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium'),
                headless=True, args=['--no-sandbox', '--disable-dev-shm-usage'])
            try:
                page = await browser.new_page(viewport={'width': 1600, 'height': 900}, device_scale_factor=1)
                errors = []
                page.on('pageerror', lambda error: errors.append(str(error)))
                await page.goto(f'http://127.0.0.1:{server.server_address[1]}/{ROOT.name}/source/premium-review.html', wait_until='load')
                await page.emulate_media(media='print')
                await page.evaluate('Promise.all([...document.images].map(i=>i.decode().catch(()=>{})))')
                await page.evaluate('''async () => {
                    await new Promise(requestAnimationFrame);
                    await Promise.all([...document.fonts].map(font=>font.load()));
                    await document.fonts.ready;
                    await new Promise(requestAnimationFrame);
                }''')
                check = await page.evaluate('''() => ({
                    images:[...document.images].filter(i=>!i.complete||!i.naturalWidth).map(i=>i.getAttribute('src')),
                    fonts:[...document.fonts].map(f=>({family:f.family,status:f.status,weight:f.weight})),
                    pages:[...document.querySelectorAll('.review-page')].map((p,i)=>{
                        const r=p.getBoundingClientRect();
                        const outside=[...p.querySelectorAll('h1,h2,h3,p,figure,figcaption,.review-card,.count')].filter(e=>{
                            const b=e.getBoundingClientRect();
                            return b.left<r.left+30||b.right>r.right-30||b.top<r.top+25||b.bottom>r.bottom-65;
                        }).map(e=>({tag:e.tagName,text:e.textContent.slice(0,100)}));
                        return {page:i+1,outside};
                    })
                })''')
                check['javascript_errors'] = errors
                check['verification_sha256'] = current_hash
                if len(check['pages']) != 2 or check['images'] or errors or any(p['outside'] for p in check['pages']):
                    raise ValueError('Review layout check failed: ' + json.dumps(check, ensure_ascii=False))
                if any(font['status'] != 'loaded' for font in check['fonts']):
                    raise ValueError('Review font load failed: ' + json.dumps(check['fonts']))
                await page.pdf(path=str(raw), print_background=True, prefer_css_page_size=True)
            finally:
                await browser.close()
    finally:
        server.shutdown()
        server.server_close()
    try:
        with fitz.open(raw) as document:
            if len(document) != 2:
                raise ValueError(f'Review must have exactly two pages; got {len(document)}')
            document.set_metadata({
                'title': 'الدايل السكني | Premium Final Review',
                'author': 'AlDayel Residential',
                'subject': 'Concise summary of identity refinements and verified final reviews',
                'keywords': 'AlDayel Residential, Premium Final Review, الدايل السكني',
                'creator': 'Editable HTML/CSS review report',
            })
            document.set_toc([[1, 'ملخص التحسينات', 1], [1, 'المراجعات وحدود التسليم', 2]])
            document.save(destination, garbage=4, deflate=True)
    finally:
        raw.unlink(missing_ok=True)
    check['pdf'] = str(destination)
    check['pdf_pages'] = 2
    (ROOT / 'quality/premium-review-layout-check.json').write_text(json.dumps(check, ensure_ascii=False, indent=2))
    print(json.dumps({'pdf': str(destination), 'pages': 2, 'layout_checks': 'passed'}, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verification', type=Path, default=VERIFICATION)
    parser.add_argument('--output', type=Path, default=ROOT / 'AlDayel_Premium_Final_Review.pdf')
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    asyncio.run(render(args.output.resolve(), args.verification))
