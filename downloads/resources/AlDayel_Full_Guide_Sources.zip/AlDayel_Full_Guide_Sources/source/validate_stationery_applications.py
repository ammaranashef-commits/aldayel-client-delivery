"""Audit logo geometry, real ink widths, descriptor gaps, page sizes, and sample QR."""
from pathlib import Path
import json,sys,fitz,subprocess,os,xml.etree.ElementTree as ET,math
from PIL import Image,ImageDraw,ImageFont
from application_environment import ROOT,WORK,configure_fonts
OUT=ROOT/'applications'
import zxingcpp
ENV=configure_fonts('applications-validation')
for directory in (ROOT/'quality',OUT/'previews'):directory.mkdir(parents=True,exist_ok=True)
m=json.loads((OUT/'stationery-packaging-manifest.json').read_text());checks=[]
for x in m:
 doc=fitz.open(OUT/x['pdf']);p=doc[0];actual=[p.rect.width*25.4/72,p.rect.height*25.4/72];expected=[x['width'],x['height']]
 root=ET.parse(OUT/'editable'/(x['name']+'.svg')).getroot();render=ET.parse(OUT/x['svg']).getroot();records=[]
 q=subprocess.run(['inkscape',str(OUT/'editable'/(x['name']+'.svg')),'--query-all'],env=ENV,capture_output=True,text=True,check=True)
 bounds={}
 for ln in q.stdout.splitlines():
  vs=ln.split(',')
  if len(vs)==5:
   try:bounds[vs[0]]=[float(t)*25.4/96 for t in vs[1:]]
   except ValueError:pass
 for el in root.iter():
  if el.tag.endswith('}svg') and 'AlDayel original' in el.attrib.get('aria-label',''):
   label=el.attrib['aria-label'];kind=label.split('original ')[1].split(' logo')[0];source=ET.parse(ROOT/f'assets/logos/residential/aldayel-{kind}-ink.svg').getroot()
   geometry=lambda o:[(n.attrib.get('d'),n.attrib.get('transform')) for n in o.iter() if n.tag.endswith('}path')]
   i=el.attrib['id'];bb=bounds[i];mn=45 if 'primary' in kind else 20 if kind=='wordmark' else 8 if kind=='icon' else None
   rec=dict(id=i,kind=kind,viewport_width_mm=float(el.attrib['width']),ink_bounds_mm=[round(t,6) for t in bb],actual_ink_width_mm=round(bb[2],6),minimum_width_mm=mn,minimum_width_pass=bb[2]>=mn if mn else None,original_geometry_unchanged=geometry(el)==geometry(source))
   X=bb[3]/4;di='descriptor-'+i.split('-')[-1]
   rec['required_clear_space_mm']=round(X,6)
   rec['page_edge_clear_space_pass']=min(bb[0],bb[1],x['width']-bb[0]-bb[2],x['height']-bb[1]-bb[3])>=X
   if di in bounds:
    gap=bounds[di][1]-(bb[1]+bb[3]);rec.update(descriptor_gap_mm=round(gap,6),descriptor_H_over_4_pass=gap>=X)
   records.append(rec)
 row=dict(name=x['name'],pdf_pages=len(doc),expected_mm=expected,actual_mm=[round(v,4) for v in actual],size_pass=max(abs(a-b) for a,b in zip(actual,expected))<.02,logos=records,original_logo_geometry_unchanged=all(v['original_geometry_unchanged'] for v in records),minimum_logo_widths_pass=all(v['minimum_width_pass'] for v in records),clearspace_measurements_pass=all(v['page_edge_clear_space_pass'] and v.get('descriptor_H_over_4_pass',True) for v in records),outlined_svg_live_text_count=sum(1 for el in render.iter() if el.tag.endswith('}text')),pdf_images=len(p.get_images()),pdf_vector_drawing_count=len(p.get_drawings()))
 if x['name'] in ['business-card-back','brochure-outside']:
  pix=p.get_pixmap(matrix=fitz.Matrix(3,3),alpha=False);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);codes=zxingcpp.read_barcodes(im);row['qr_decoded']=[c.text for c in codes];row['qr_pass']=len(codes)==1 and codes[0].text=='ALDAYEL RESIDENTIAL - DESIGN SAMPLE - NOT A LIVE LINK'
 checks.append(row)
(ROOT/'quality/applications-stationery-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
font=ImageFont.truetype(str(ROOT/'assets/fonts/PTSans-Regular.ttf'),16)
for start in range(0,len(m),8):
 items=m[start:start+8];sheet=Image.new('RGB',(1440,math.ceil(len(items)/2)*480),(225,225,225));draw=ImageDraw.Draw(sheet)
 for k,x in enumerate(items):
  doc=fitz.open(OUT/x['pdf']);p=doc[0];z=min(680/p.rect.width,430/p.rect.height);pix=p.get_pixmap(matrix=fitz.Matrix(z,z),alpha=False);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.save(OUT/'previews'/(x['name']+'.png'));xx=(k%2)*720+20;yy=(k//2)*480+20;sheet.paste(im,(xx+(680-im.width)//2,yy+(430-im.height)//2));draw.text((xx,yy+438),x['name'],font=font,fill='black')
 sheet.save(OUT/'previews'/f'stationery-contact-{start+1:02}.jpg',quality=93)
fail=[v for v in checks if not all([v['size_pass'],v['original_logo_geometry_unchanged'],v['minimum_logo_widths_pass'],v['clearspace_measurements_pass'],v.get('qr_pass',True),v['outlined_svg_live_text_count']==0])]
print(json.dumps(dict(total=len(checks),failed=fail),ensure_ascii=False,indent=2))
if fail:sys.exit(1)
