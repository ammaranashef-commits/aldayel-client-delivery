"""Refresh the 73-entry requirements index after PREMIUM verification is frozen.

This is an index operation, not a new visual or technical review. All referenced
evidence must already exist. The script keeps the requirement text, acceptance
criteria and honest limitations, refreshes page titles/PDF identity, and replaces
obsolete review references with the actual PREMIUM records. It refuses to write
if any referenced file or HTML anchor is missing.

Run only after the final PDF, all 62 previews, final quality records, review
closure logs and delivery README exist. --check-only validates without writing.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
from urllib.parse import quote, unquote

import fitz


ROOT = Path(__file__).resolve().parent.parent
MATRIX = 'research/requirements-matrix.json'
MARKDOWN = 'research/requirements-matrix.ar.md'
FINAL_PDF = 'AlDayel_Residential_Brand_Guidelines_PREMIUM_FINAL.pdf'
OLD_PDF = 'AlDayel_Residential_Brand_Guidelines_FINAL.pdf'
REVIEW_LOGS = [
    'quality/reviews/artistic-final-review.json',
    'quality/reviews/professional-final-review.json',
    'quality/reviews/ai-appearance-final-review.json',
]
REQUIRED_RECORDS = [
    'quality/page-manifest.json',
    'quality/final-identity-assets.json',
    'quality/final-logo-affine.json',
    'quality/premium-requirements-check.json',
    'quality/final-technical.json',
    'quality/premium-final-verification.json',
    'quality/baseline-preservation.json',
    'quality/final-preview-manifest.json',
    'quality/final-pixel-comparison.json',
    'quality/final-source-text-digest.json',
    *REVIEW_LOGS,
]


# These substitutions change the cited evidence, not the original requirement.
# Source-stage checks remain source-stage evidence. They are always accompanied
# by final review/export evidence where final appearance is the subject.
REPLACEMENTS = {
    OLD_PDF: [FINAL_PDF],
    'quality/final-logo-color-assets.json': [
        'quality/final-identity-assets.json', 'quality/final-logo-affine.json'],
    'quality/applications-stationery-checks.json': [
        'quality/final-identity-assets.json', 'quality/premium-requirements-check.json'],
    'quality/screenshot-requirements-checklist.json': [
        'quality/premium-requirements-check.json'],
    'quality/final-verification.json': ['quality/premium-final-verification.json'],
    'quality/final-preview-provenance.json': ['quality/final-preview-manifest.json'],
}
for _round in ('round1', 'round2'):
    for _range in ('01-21', '22-42', '43-62'):
        REPLACEMENTS[f'quality/{_round}-pages-{_range}.json'] = REVIEW_LOGS
for _range in ('01-21', '22-42', '43-62'):
    REPLACEMENTS[f'quality/final-followup-pages-{_range}.json'] = [
        *REVIEW_LOGS, 'quality/final-pixel-comparison.json']


ADDITIONAL_EVIDENCE = {
    'S01': ['quality/baseline-preservation.json'],
    'S07': ['quality/final-identity-assets.json'],
    'S08': ['quality/final-identity-assets.json'],
    'S11': ['source/premium.css'],
    'B02': ['quality/baseline-preservation.json', 'quality/final-logo-affine.json'],
    'B14': ['previews/page-01.jpg', REVIEW_LOGS[0]],
    'B16': ['previews/page-62.jpg', REVIEW_LOGS[0]],
    'B25': ['quality/final-identity-assets.json', REVIEW_LOGS[2]],
    'B27': ['source/premium.css', REVIEW_LOGS[1]],
    'B28': ['source/premium.css', *REVIEW_LOGS],
    'B29': ['quality/final-source-text-digest.json', REVIEW_LOGS[1]],
    'B31': ['source/premium.css', 'quality/final-source-text-digest.json'],
    'B33': [
        *REVIEW_LOGS, 'quality/premium-final-verification.json',
        'quality/final-preview-manifest.json', 'quality/final-pixel-comparison.json'],
    'B35': ['quality/premium-final-verification.json'],
    'B36': ['quality/baseline-preservation.json'],
    'B37': [
        'source/premium.css', 'source/premium_editorial.py',
        'source/premium_layouts.py', 'quality/final-source-text-digest.json'],
    'B39': ['quality/premium-final-verification.json'],
    'B40': [
        *REQUIRED_RECORDS,
    ],
}


class AnchorIndex(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.anchors = set()

    def handle_starttag(self, tag, attrs):
        for name, value in attrs:
            if name == 'id' and value:
                self.anchors.add(value)

    handle_startendtag = handle_starttag


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_json(path):
    if not path.is_file() or not path.stat().st_size:
        raise FileNotFoundError(f'Required record is missing or empty: {path}')
    return json.loads(path.read_text(encoding='utf-8'))


def check_reference(root, relative, anchor_cache):
    path_part, marker, fragment = relative.partition('#')
    if Path(path_part).is_absolute() or '..' in Path(path_part).parts:
        raise ValueError(f'Evidence must stay within the delivery: {relative}')
    path = root / path_part
    if not path.exists():
        raise FileNotFoundError(f'Missing evidence: {relative}')
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError(f'Evidence resolves outside the delivery: {relative}')
    nonempty = any(path.iterdir()) if path.is_dir() else path.stat().st_size > 0
    if not nonempty:
        raise ValueError(f'Empty evidence: {relative}')
    anchor_verified = None
    if marker:
        if not path.is_file() or path.suffix.lower() not in ('.html', '.htm'):
            raise ValueError(f'Unsupported anchor evidence: {relative}')
        if path not in anchor_cache:
            parser = AnchorIndex()
            parser.feed(path.read_text(encoding='utf-8'))
            anchor_cache[path] = parser.anchors
        anchor_verified = unquote(fragment) in anchor_cache[path]
        if not anchor_verified:
            raise ValueError(f'Missing HTML anchor: {relative}')
    return {
        'path': relative,
        'exists': True,
        'nonempty': True,
        'anchor_requested': bool(marker),
        'anchor_verified': anchor_verified,
        'check_scope': 'path/anchor existence only; not a new visual review',
    }


def check_mockup_record(root):
    """Retain the real render review only if its image hashes are still current."""
    record = root / 'source/mockups/render-review.json'
    data = load_json(record)
    rows = data.get('review', [])
    for item in rows:
        if not isinstance(item, dict):
            continue
        relative, expected = item.get('image'), item.get('sha256')
        if relative and expected:
            path = root / relative
            if not path.is_file() or sha256(path) != expected:
                raise ValueError(f'Mockup render review is stale for {relative}; refresh the actual render review first')


def ensure_final_pdf_identity(records, actual_hash):
    """Check recorded final PDF hashes when present, leaving baseline hashes alone."""
    for relative in ('quality/premium-final-verification.json', 'quality/final-technical.json'):
        data = records[relative]
        if not isinstance(data, dict):
            raise ValueError(f'Expected a JSON object: {relative}')
        for key in ('main_pdf_sha256', 'pdf_sha256', 'final_pdf_sha256'):
            recorded = data.get(key)
            if recorded and recorded != actual_hash:
                raise ValueError(f'{relative}: {key} does not match the current PREMIUM PDF')


def _cell(value):
    return str(value).replace('|', '\\|').replace('\n', '<br>')


def _link(relative, label=None):
    # The Markdown matrix lives under research/, so evidence links are one level up.
    target = '../' + quote(relative, safe='/#._-')
    return f'[{_cell(label or relative)}]({target})'


def _page_summary(numbers):
    if numbers == list(range(1, 63)):
        return '01–62'
    return '، '.join(f'{number:02d}' for number in numbers)


def render_markdown(rows, actual_hash, generated):
    lines = [
        '# مصفوفة متطلبات هوية الدايل السكني — PREMIUM FINAL', '',
        f'{generated} · **73 بندًا**: 33 من الصورتين المرجعيتين و40 من التكليف الأصلي.', '',
        'الأرقام والعناوين مرتبطة بالنسخة المحسّنة ذات 62 صفحة. تعني حالة «منفذ» توافر المحتوى أو الأصل التصميمي؛ ولا تعني اعتماد بيانات الشركة أو جاهزية التصنيع.', '',
        f'PDF: {_link(FINAL_PDF)}  ',
        f'SHA-256: `{actual_hash}`', '',
        'جميع الروابط أدناه نسبية إلى مجلد التسليم. فُحص وجود الملفات والمجلدات وعدم فراغها، وطُوبقت مرابط صفحات HTML. هذا تحديث لفهرس الأدلة، وليس جولة مراجعة بصرية جديدة.', '',
        'سجل فحص المتطلبات يوثّق مرحلة المصدر؛ نتائج المخرج النهائي وتغطية المراجعات الثلاث وإقفال الملاحظات في السجلات النهائية المرتبطة. تبقى حدود الفرع الخدمي والحرفي في B10 معلنة.', '',
    ]
    for prefix, heading in [('S', 'متطلبات الصورتين المرجعيتين'), ('B', 'متطلبات التكليف النصي الأصلي')]:
        lines += [f'## {heading}', '',
                  '| ID | المتطلب | صفحات PREMIUM FINAL | الأدلة الحالية | الحالة والحدود |',
                  '|---|---|---|---|---|']
        for row in rows:
            if not row['id'].startswith(prefix):
                continue
            evidence = row['evidence']
            # Page anchors are retained and checked in JSON; compact all-page
            # requirements to one linked HTML entry in this human-readable index.
            if row['pages'] == list(range(1, 63)):
                shown = [p for p in evidence if not re.fullmatch(r'source/book\.html#p\d+', p)]
                if 'source/book.html' not in shown:
                    shown.insert(0, 'source/book.html')
            else:
                shown = evidence
            links = '<br>'.join(_link(p) for p in shown)
            detail = row['status'] + (('؛ ' + row['delivery_notes']) if row.get('delivery_notes') else '')
            lines.append(f'| {row["id"]} | {_cell(row["requirement"])} | {_page_summary(row["pages"])} | {links} | {_cell(detail)} |')
        lines.append('')
    return '\n'.join(lines)


def refresh(root=ROOT, *, check_only=False):
    root = Path(root).resolve()
    original = load_json(root / MATRIX)
    expected_ids = {f'S{i:02d}' for i in range(1, 34)} | {f'B{i:02d}' for i in range(1, 41)}
    if not isinstance(original, list) or len(original) != 73 or {x.get('id') for x in original} != expected_ids:
        raise ValueError('The requirements matrix must retain exactly S01–S33 and B01–B40')
    records = {name: load_json(root / name) for name in REQUIRED_RECORDS}
    page_records = records['quality/page-manifest.json']
    titles = {int(item['page']): item['title'] for item in page_records}
    if set(titles) != set(range(1, 63)) or len(page_records) != 62:
        raise ValueError('The current page manifest must contain exactly pages 1–62')
    pdf = root / FINAL_PDF
    if not pdf.is_file():
        raise FileNotFoundError(f'The frozen PREMIUM PDF is required: {pdf}')
    with fitz.open(pdf) as document:
        if len(document) != 62:
            raise ValueError('The PREMIUM guide must have exactly 62 pages')
    actual_hash = sha256(pdf)
    ensure_final_pdf_identity(records, actual_hash)
    check_mockup_record(root)
    # Every page preview must exist before the preview requirement is refreshed.
    for number in range(1, 63):
        preview = root / f'previews/page-{number:02d}.jpg'
        if not preview.is_file() or not preview.stat().st_size:
            raise FileNotFoundError(f'Missing final page preview: {preview}')
    generated = datetime.now(timezone.utc).isoformat(timespec='seconds')
    anchor_cache = {}
    rows = []
    for old in original:
        row = dict(old)
        evidence = []
        for relative in old['evidence']:
            if relative == 'quality/applications-stationery-checks.json' and (root / relative).is_file():
                # A fresh run of the unchanged application validator may have
                # recreated this useful record before the final index refresh.
                evidence.append(relative)
            evidence.extend(REPLACEMENTS.get(relative, [relative]))
        evidence.extend(ADDITIONAL_EVIDENCE.get(row['id'], []))
        row['evidence'] = list(dict.fromkeys(evidence))
        numbers = row.get('pages') or sorted({
            int(match.group(1)) for path in row['evidence']
            if (match := re.fullmatch(r'source/book\.html#p(\d+)', path))
        })
        if any(type(number) is not int or number not in titles for number in numbers):
            raise ValueError(f'{row["id"]}: invalid page references')
        row['pages'] = numbers
        row['page_titles'] = [titles[number] for number in numbers]
        row['final_pdf'] = FINAL_PDF
        row['final_pdf_sha256'] = actual_hash
        row['evidence_scope'] = (
            f'مسارات نسبية إلى {root.name}؛ الصفحات والعناوين من quality/page-manifest.json. '
            'فحص المصدر دليل لمرحلة المصدر؛ فحوص المخرج والمراجعات البصرية مرتبطة بسجلات PREMIUM النهائية.')
        row['evidence_index_refreshed_utc'] = generated
        row['current_evidence_checks'] = [check_reference(root, relative, anchor_cache) for relative in row['evidence']]
        if row['id'] == 'B33':
            row['status'] = 'موثق — سجلات المراجعات الثلاث والإقفال النهائي مرفقة'
            row['notes'] = row['delivery_notes'] = (
                'تفاصيل تغطية الصفحات، وإقفال الملاحظات، وإعادة فحص الصفحات المعدلة، '
                'والتطابق البكسلي للصفحات الثابتة في سجلات المراجعات الثلاث والتحقق النهائي. '
                'تحديث هذا الفهرس لا يمثل جولة بصرية إضافية.')
        elif row['id'] == 'B35':
            row['status'] = 'منفذ — ملف PREMIUM FINAL موجود؛ فُتح تقنيًا وثُبتت بصمته الحالية'
            row['acceptance'] = FINAL_PDF + ' كملف واحد متكامل للنسخة المحسّنة، وفق اسم التسليم المطلوب في مراجعة التسليم الاحترافية.'
        elif row['id'] == 'B36':
            row['acceptance'] = 'المخرجات المحسّنة في مجلد PREMIUM_FINAL مستقل ومنظّم، مع حفظ التسليم السابق دون تعديل.'
        elif row['id'] == 'B39':
            row['status'] = 'موثق — معاينات صفحات PREMIUM FINAL والغلاف متاحة'
            row['notes'] = row['delivery_notes'] = (
                'تتوفر معاينات الصفحات الـ62 والغلاف. معلومات الرندر ونسبتها إلى المخرج '
                'موثقة في فهرس المعاينات والتحقق النهائي؛ وجود الملفات وحده ليس فحصًا بصريًا.')
        elif row['id'] == 'B40':
            row['status'] = 'موثق — 73 بندًا مع بيان حدود B10 وروابط الأدلة الحالية'
            row['notes'] = row['delivery_notes'] = (
                'تغطية بنود الصورتين في فحص المتطلبات؛ جودة المخرج وتغطية المراجعات '
                'في سجلات PREMIUM النهائية. يبقى B10 جزئيًا لغياب مرجع مستقل للفرع الخدمي والحرفي.')
        rows.append(row)
    serialized = json.dumps(rows, ensure_ascii=False, indent=2) + '\n'
    if OLD_PDF in serialized or 'AlDayel_Residential_Final_Delivery' in serialized:
        raise ValueError('An obsolete delivery reference remains in the updated matrix')
    markdown = render_markdown(rows, actual_hash, generated)
    if not check_only:
        # Build and validate both outputs completely before replacing either file.
        for relative, content in ((MATRIX, serialized), (MARKDOWN, markdown)):
            destination = root / relative
            temporary = destination.with_name(destination.name + '.tmp')
            temporary.write_text(content, encoding='utf-8')
            temporary.replace(destination)
    return {
        'mode': 'check-only' if check_only else 'updated',
        'requirements': len(rows),
        'reference_image_requirements': sum(row['id'].startswith('S') for row in rows),
        'text_brief_requirements': sum(row['id'].startswith('B') for row in rows),
        'pdf': FINAL_PDF,
        'pdf_sha256': actual_hash,
        'unique_evidence_paths': len({path for row in rows for path in row['evidence']}),
        'all_evidence_paths_and_html_anchors_exist': True,
        'new_visual_review_performed_by_this_script': False,
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    print(json.dumps(refresh(args.root, check_only=args.check_only), ensure_ascii=False, indent=2))
