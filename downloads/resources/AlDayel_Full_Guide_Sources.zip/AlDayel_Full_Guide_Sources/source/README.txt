AlDayel Residential — PREMIUM editable sources

Main reproduction guide: README-premium.ar.md
Source index: README.md
Applications: README-applications.md
Blender mockups: mockups/README.md
Animated logo: ../motion/motion-notes.md

Supply your licensed original Arabic fonts via ALDAYEL_FONT_DIR. Commercial font files are not redistributed. PT Sans is bundled with license information under ../assets/fonts/.

Main output: AlDayel_Residential_Brand_Guidelines_PREMIUM_FINAL.pdf
Short review: AlDayel_Premium_Final_Review.pdf
Re-exported files require fresh verification; prior review records do not certify new output.
